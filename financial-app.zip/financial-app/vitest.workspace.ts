// See ch07-testing-vitest.md.
import { defineWorkspace } from 'vitest/config';

export default defineWorkspace([
  'apps/*/vitest.config.ts',
  'libs/*/*/vitest.config.ts',
]);
