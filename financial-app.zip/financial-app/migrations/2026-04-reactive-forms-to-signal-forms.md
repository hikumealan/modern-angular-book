<!-- See ch50-migrations.md -->

# Reactive Forms to Signal Forms -- Transaction Entry

**Status:** Completed 2026-04-12

## Scope

- `apps/financial-app/src/app/features/transactions/transaction-entry/transaction-entry.component.ts`

Remaining Reactive Forms usage in the legacy settings module is tracked in
[`ch56-appendix-c-reactive-forms.md`](../../ch56-appendix-c-reactive-forms.md)
and stays on the old API by design.

## Motivation

The transaction entry form is the most-exercised form in the app and already
drove derived state (currency symbol, running balance, disabled "submit"
button) through `valueChanges` subscriptions. Signal Forms collapse that
plumbing into `computed()` reads and give the template a single reactive
source of truth, matching the rest of the signal-first stack introduced in
[Chapter 6](../../ch06-signal-forms.md).

## Before / After

```typescript
// BEFORE
@Component({ imports: [ReactiveFormsModule] })
export class TransactionEntryComponent {
  private readonly fb = inject(FormBuilder);
  readonly form = this.fb.group({
    description: ['', Validators.required],
    amount: [0, [Validators.required, Validators.min(0.01)]],
    date: ['', Validators.required],
  });
}

// AFTER
@Component({ imports: [SignalFormDirective] })
export class TransactionEntryComponent {
  readonly form = withSchema(transactionDraftSchema, {
    description: formField(''),
    amount: formField(0),
    date: formField(new Date().toISOString().slice(0, 10)),
  });
}
```

## Validation

- Ported the existing `transaction-entry.component.spec.ts` suite. All 14
  cases pass against the Signal Forms implementation.
- Manual smoke: entered a valid draft, an empty draft, and an over-limit
  amount on Chrome and Safari to confirm validators fire identically.
- Contract E2E (`CONTRACT=1 nx e2e financial-app-e2e`) still green.

## Rollout notes

- `ReactiveFormsModule` stays in the app providers because the legacy
  settings form (see appendix C companion) is not being migrated.
- No feature flag. The change is a drop-in replacement for a single
  component; rollback is a one-commit revert.

## Follow-ups

- Migrate `features/portfolio/rebalance-form.component.ts` next quarter.
- Revisit the legacy settings form when it lands on the deprecation list.
