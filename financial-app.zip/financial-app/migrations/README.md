<!-- See ch50-migrations.md -->

# Migration Log

This directory is the durable record of every material migration applied to
FinancialApp. Each entry captures **why** the change happened, **what** moved,
and the **before/after** diff that a future maintainer (or auditor) can read
without reconstructing the git history.

The log complements -- it does not replace -- commit messages, PR
descriptions, or the automated `migrations.json` produced by `nx migrate`.
Those are per-change records; this directory is the narrative index.

## File naming

```
YYYY-MM-<slug>.md
```

- `YYYY-MM` -- the calendar month the migration was merged.
- `<slug>`  -- lowercase, hyphenated, specific. Prefer
  `reactive-forms-to-signal-forms` over `forms-update`.

## Entry format

Every migration file follows the same outline so the index stays
grep-friendly and diff-friendly:

1. **Title** -- `# <short human title>` on the first line.
2. **Status** -- `In progress`, `Completed YYYY-MM-DD`, or `Rolled back`.
3. **Scope** -- files, libraries, or features touched.
4. **Motivation** -- why now; what risk or capability it unlocks.
5. **Before / After** -- minimal code diff showing the old and new shape.
6. **Validation** -- the tests or manual checks that proved parity.
7. **Rollout notes** -- staging plan, feature flags, deprecation window.
8. **Follow-ups** -- links to issues or sibling migrations still pending.

See `2026-04-reactive-forms-to-signal-forms.md` for the canonical example.

## When to open a new entry

- Any change that alters a public API surface shared across libraries.
- Any framework upgrade that required running `nx migrate` or a
  `ng generate @angular/core:*-migration` schematic.
- Any architectural shift (module boundaries, DI topology, build pipeline)
  that a future engineer would want to understand without re-reading
  five PRs.

Small refactors, dependency bumps, and bug fixes do not belong here -- the
changelog and git log already cover them.
