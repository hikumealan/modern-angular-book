// See ch41-capacitor-mobile.md -- "Biometric Authentication"
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class BiometricAuthService {
  async isAvailable(): Promise<boolean> {
    return false;
  }

  async authenticate(reason: string): Promise<boolean> {
    void reason;
    return false;
  }
}
