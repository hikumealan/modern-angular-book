<!-- See ch41-capacitor-mobile.md -->
# FinancialApp Mobile Shell

Capacitor shell that wraps the built `financial-app` web bundle inside a native
iOS / Android container. See [Chapter 36](../../../ch41-capacitor-mobile.md) for
the architecture and the full biometric / push / camera integrations.

## Prerequisites

- Xcode (for iOS builds) on macOS
- Android Studio with an SDK installed (for Android builds)
- Node dependencies installed at the workspace root (`npm ci` from `financial-app/`)

## One-time setup

Add the native projects the first time the mobile shell is cloned:

```sh
# From financial-app/apps/financial-app-mobile/
npx cap add ios
npx cap add android
```

## Build + sync workflow

Every time the Angular app changes, rebuild the web bundle and copy it into
the native projects:

```sh
# From financial-app/ (workspace root)
npx nx run financial-app-mobile:build:mobile
```

This runs the `financial-app` production build first, then invokes
`npx cap sync` inside this directory -- which copies `dist/apps/financial-app`
into the iOS and Android projects and refreshes any installed plugins.

## Opening the native IDEs

```sh
npx cap open ios        # or: npx nx run financial-app-mobile:open:ios
npx cap open android    # or: npx nx run financial-app-mobile:open:android
```

From there, build and run onto a simulator / emulator / device using the
native IDE workflow.

## Biometric auth stub

`src/biometric-auth.service.ts` is a placeholder that matches the production
signature but returns `false` for both `isAvailable()` and
`authenticate(reason)`. Replace the stubs with calls into
`@capacitor-community/biometric-auth` as shown in the chapter.
