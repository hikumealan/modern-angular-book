// See ch41-capacitor-mobile.md -- "Capacitor Configuration"
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.example.financialapp',
  appName: 'FinancialApp',
  webDir: '../../dist/apps/financial-app',
  server: {
    androidScheme: 'https',
  },
  plugins: {
    SplashScreen: { launchShowDuration: 2000 },
    PushNotifications: { presentationOptions: ['badge', 'sound', 'alert'] },
  },
};

export default config;
