// See ch39-angular-elements.md -- "Shadow DOM and Theming"
import {
  ChangeDetectionStrategy,
  Component,
  ViewEncapsulation,
  input,
} from '@angular/core';

@Component({
  selector: 'fin-account-summary',
  standalone: true,
  templateUrl: './fin-account-summary.component.html',
  encapsulation: ViewEncapsulation.ShadowDom,
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [
    `
      :host {
        display: block;
        font-family: var(--fin-font, system-ui, sans-serif);
        color: var(--fin-color, #1a1a1a);
        background: var(--fin-bg, #ffffff);
        border: 1px solid var(--fin-border, #e2e8f0);
        border-radius: 8px;
        padding: 1rem 1.25rem;
        max-width: 28rem;
      }
      .account-id {
        font-size: 0.875rem;
        color: var(--fin-muted, #64748b);
      }
      .balance {
        font-size: 1.5rem;
        font-weight: 600;
        margin-top: 0.25rem;
      }
    `,
  ],
})
export class FinAccountSummaryComponent {
  readonly accountId = input<string>('');
  readonly balance = input<number>(0);
}
