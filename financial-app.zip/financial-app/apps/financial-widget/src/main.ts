// See ch39-angular-elements.md -- "Bootstrapping for Element-Only Builds"
import { createApplication } from '@angular/platform-browser';
import { createCustomElement } from '@angular/elements';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withFetch } from '@angular/common/http';
import { FinAccountSummaryComponent } from './fin-account-summary.component';

async function bootstrap(): Promise<void> {
  const app = await createApplication({
    providers: [
      provideZonelessChangeDetection(),
      provideHttpClient(withFetch()),
    ],
  });

  const SummaryElement = createCustomElement(FinAccountSummaryComponent, {
    injector: app.injector,
  });

  if (!customElements.get('fin-account-summary')) {
    customElements.define('fin-account-summary', SummaryElement);
  }
}

bootstrap().catch((err) =>
  console.error('[fin-widget] bootstrap failed', err),
);
