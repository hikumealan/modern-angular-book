// See ch52-appendix-b0-backend-fastapi.md -- "API-level round-trip suite"
//
// Hits every live GET endpoint on the running FastAPI backend and
// validates each response with the Strategy A generated Zod schema.
// This is the catch-all gate that detects backend drift slipping past
// CI's regeneration-diff step (middleware or serializer bugs, for
// example, can produce on-the-wire shapes that differ from the spec).
//
// Only runs in CONTRACT mode (CONTRACT=1 or the `contract` Nx
// configuration); the default fast path targets json-server, which
// deliberately does not enforce the contract.
import { test, expect } from '@playwright/test';
import {
  Account,
  Client,
  Portfolio,
  Transaction,
} from '@financial-app/shared/api-client/generated/generated-zodios';

const backend = 'http://localhost:8000';
const runContractTests = process.env['CONTRACT'] === '1';

test.skip(!runContractTests, 'contract round-trip requires CONTRACT=1 (FastAPI backend)');

test('GET /api/accounts conforms to Account[] schema', async ({ request }) => {
  const response = await request.get(`${backend}/api/accounts`);
  expect(response.ok()).toBe(true);
  const body = await response.json();
  expect(Array.isArray(body)).toBe(true);
  const parsed = Account.array().safeParse(body);
  if (!parsed.success) {
    throw new Error(`Account[] schema mismatch:\n${JSON.stringify(parsed.error.issues, null, 2)}`);
  }
});

test('GET /api/accounts/1 conforms to Account schema', async ({ request }) => {
  const response = await request.get(`${backend}/api/accounts/1`);
  expect(response.ok()).toBe(true);
  const parsed = Account.safeParse(await response.json());
  if (!parsed.success) {
    throw new Error(`Account schema mismatch:\n${JSON.stringify(parsed.error.issues, null, 2)}`);
  }
});

test('POST /api/transactions accepts a valid draft and returns a Transaction', async ({ request }) => {
  const draft = {
    accountId: 1,
    amount: 99.95,
    type: 'debit',
    category: 'groceries',
    date: '2026-04-15',
    description: 'E2E round-trip fixture',
  };
  const response = await request.post(`${backend}/api/transactions`, { data: draft });
  expect(response.status()).toBe(201);
  const parsed = Transaction.safeParse(await response.json());
  if (!parsed.success) {
    throw new Error(`Transaction schema mismatch:\n${JSON.stringify(parsed.error.issues, null, 2)}`);
  }
});

test('POST /api/transactions rejects amount below minimum with 422', async ({ request }) => {
  const response = await request.post(`${backend}/api/transactions`, {
    data: { accountId: 1, amount: 0, type: 'debit', category: 'test', date: '2026-04-15' },
  });
  expect(response.status()).toBe(422);
});

test('GET /api/clients/10 conforms to Client schema', async ({ request }) => {
  const response = await request.get(`${backend}/api/clients/10`);
  expect(response.ok()).toBe(true);
  const parsed = Client.safeParse(await response.json());
  if (!parsed.success) {
    throw new Error(`Client schema mismatch:\n${JSON.stringify(parsed.error.issues, null, 2)}`);
  }
});

test('GET /api/portfolios conforms to Portfolio[] schema', async ({ request }) => {
  const response = await request.get(`${backend}/api/portfolios`);
  expect(response.ok()).toBe(true);
  const parsed = Portfolio.array().safeParse(await response.json());
  if (!parsed.success) {
    throw new Error(`Portfolio[] schema mismatch:\n${JSON.stringify(parsed.error.issues, null, 2)}`);
  }
});
