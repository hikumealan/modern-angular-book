// See ch24-accessibility.md -- "Playwright a11y Fixture for Regression"
//
// Smoke suite that runs @axe-core/playwright against the pages most
// likely to regress (public landing + transaction-search filter bar,
// which has the highest density of form controls in the app).
//
// The import below is illustrative: the book's companion workflow
// installs `@axe-core/playwright` only in environments where the
// accessibility sweep runs (CI, or locally when an engineer is
// actively triaging a11y findings). The spec compiles unconditionally
// so that the test file remains discoverable in the Playwright
// project; individual tests skip themselves if the package is absent.
import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

// WCAG 2.1 AA is FinancialApp's declared baseline. Starting strict and
// relaxing is easier than the reverse; the sweep fails the build on
// any violation so the default budget is "zero".
const WCAG_TAGS = ['wcag2a', 'wcag2aa', 'wcag21aa'];

test.describe('a11y smoke', () => {
  test('homepage has no detectable WCAG 2.1 AA violations', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    const results = await new AxeBuilder({ page }).withTags(WCAG_TAGS).analyze();

    expect(results.violations).toEqual([]);
  });

  test('transaction-search page has no detectable WCAG 2.1 AA violations', async ({
    page,
  }) => {
    await page.goto('/transactions');
    await page.waitForLoadState('networkidle');
    await expect(
      page.getByRole('heading', { name: /transactions/i }).or(
        page.locator('app-transaction-search'),
      ),
    ).toBeVisible();

    const results = await new AxeBuilder({ page })
      .withTags(WCAG_TAGS)
      // Date pickers inject third-party DOM we cannot reshape; exclude
      // them here, not globally -- most pages should exercise the full
      // ruleset against the full DOM.
      .exclude('input[type="date"]')
      .analyze();

    expect(results.violations).toEqual([]);
  });
});
