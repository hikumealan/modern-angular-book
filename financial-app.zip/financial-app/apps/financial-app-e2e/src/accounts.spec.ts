import { test, expect } from '@playwright/test';

test.describe('Accounts page', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/accounts');
  });

  test('should display the accounts heading', async ({ page }) => {
    await expect(page.getByRole('heading', { name: /accounts/i })).toBeVisible();
  });

  test('should render account cards', async ({ page }) => {
    const cards = page.locator('app-account-card');
    await expect(cards.first()).toBeVisible();
    expect(await cards.count()).toBeGreaterThan(0);
  });

  test('should navigate to account detail on card click', async ({ page }) => {
    await page.locator('app-account-card').first().click();
    await expect(page).toHaveURL(/\/accounts\/\w+/);
  });
});
