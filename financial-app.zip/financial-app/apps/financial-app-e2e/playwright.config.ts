import { defineConfig, devices } from '@playwright/test';

// See appendix-b-e2e-workflow.md -- "Playwright patterns"
//
// In `contract` configuration the FastAPI backend is spawned alongside
// the Angular dev server so the E2E round-trip tests hit a real
// Pydantic-validated API. In the default configuration only the
// Angular dev server runs -- tests rely on the json-server mock for
// fast UI-only iteration.
const isContractMode = process.env['CONTRACT'] === '1';

const webServer = isContractMode
  ? [
      {
        command: 'npx nx serve financial-app',
        url: 'http://localhost:4200',
        reuseExistingServer: !process.env['CI'],
      },
      {
        command: 'uv run uvicorn backend.main:app --port 8000',
        url: 'http://localhost:8000/api/health',
        cwd: '../../backend',
        reuseExistingServer: !process.env['CI'],
      },
    ]
  : {
      command: 'npx nx serve financial-app',
      url: 'http://localhost:4200',
      reuseExistingServer: !process.env['CI'],
    };

export default defineConfig({
  testDir: './src',
  fullyParallel: true,
  forbidOnly: !!process.env['CI'],
  retries: process.env['CI'] ? 2 : 0,
  workers: process.env['CI'] ? 1 : undefined,
  reporter: 'html',

  use: {
    baseURL: 'http://localhost:4200',
    trace: 'on-first-retry',
  },

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],

  webServer,
});
