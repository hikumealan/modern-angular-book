// See ch36-cicd-deployment.md.
export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000',
};
