// See ch41-cicd-deployment.md
export const environment = {
  production: true,
  apiUrl: 'https://staging-api.financialapp.example.com',
  sentryDsn: null,
};
