// See ch36-cicd-deployment.md.
export const environment = {
  production: true,
  apiUrl: '/api',
};
