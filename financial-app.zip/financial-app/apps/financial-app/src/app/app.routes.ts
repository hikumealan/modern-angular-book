// See ch04-router.md.
import { Routes } from '@angular/router';

export const appRoutes: Routes = [];
