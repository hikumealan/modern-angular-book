// See ch06-signal-forms.md -- "Large and Nested Forms"
// formField is experimental in Angular v21 -- API may change in future releases
import { Component, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import {
  formField,
  formGroup,
  Validators,
  type SignalFormGroup,
} from '@angular/forms';

import type { Client } from '@financial-app/shared/models';

function emailAvailableValidator(http: HttpClient) {
  return async (value: string): Promise<{ emailTaken: true } | null> => {
    if (!value) return null;
    const taken = await fetch(`/api/clients/check-email?email=${encodeURIComponent(value)}`)
      .then((r) => r.json())
      .then((body: { exists: boolean }) => body.exists);
    return taken ? { emailTaken: true } : null;
  };
}

@Component({
  selector: 'app-client-onboarding',
  standalone: true,
  templateUrl: './client-onboarding.component.html',
  styleUrl: './client-onboarding.component.scss',
})
export class ClientOnboardingComponent {
  private readonly router = inject(Router);
  private readonly http = inject(HttpClient);

  readonly submitting = signal(false);

  readonly form = formGroup({
    firstName: formField('', { validators: [Validators.required, Validators.minLength(2)] }),
    lastName: formField('', { validators: [Validators.required, Validators.minLength(2)] }),
    email: formField('', {
      validators: [Validators.required, Validators.email],
      asyncValidators: [emailAvailableValidator(this.http)],
    }),
    riskProfile: formField<Client['riskProfile']>('moderate', {
      validators: [Validators.required],
    }),
  });

  async onSubmit(): Promise<void> {
    if (!this.form.valid()) return;

    this.submitting.set(true);
    try {
      const created = await this.http
        .post<Client>('/api/clients', this.form.value())
        .toPromise();
      await this.router.navigate(['/clients', created!.id]);
    } finally {
      this.submitting.set(false);
    }
  }
}
