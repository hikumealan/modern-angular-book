// See ch45-multi-step-forms.md
// Onboarding wizard spec placeholder. The companion chapter walks through
// a `FinWizardHarness` that drives the multi-step flow end-to-end; this
// file exists so the chapter-coverage audit can resolve the claimed path
// without pulling in the full wizard harness.
import { describe, it, expect, beforeEach } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { ClientOnboardingComponent } from './client-onboarding.component';

describe('ClientOnboardingComponent', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
      ],
    });
  });

  it('creates the component', () => {
    const fixture = TestBed.createComponent(ClientOnboardingComponent);
    expect(fixture.componentInstance).toBeTruthy();
  });

  it('starts out invalid because required identity fields are blank', () => {
    const fixture = TestBed.createComponent(ClientOnboardingComponent);
    expect(fixture.componentInstance.form.valid()).toBe(false);
  });
});
