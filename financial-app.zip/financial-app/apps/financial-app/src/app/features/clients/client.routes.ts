// See ch05-routing.md -- "Lazy-Loaded Feature Routes"
import type { Routes } from '@angular/router';

export const CLIENT_ROUTES: Routes = [
  {
    path: 'new',
    loadComponent: () =>
      import('./client-onboarding.component').then((m) => m.ClientOnboardingComponent),
    title: 'New Client',
  },
  {
    path: ':id',
    loadComponent: () =>
      import('./client-profile.component').then((m) => m.ClientProfileComponent),
    title: 'Client Profile',
  },
];
