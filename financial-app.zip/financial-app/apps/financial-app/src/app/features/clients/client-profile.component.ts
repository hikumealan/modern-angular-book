// See ch04-components.md -- "Signal-Based Inputs from the Router"
// See ch06-http.md -- "Loading Data with httpResource"
// httpResource is experimental in Angular v21 -- API may change in future releases
import { Component, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { httpResource } from '@angular/common/http';

import type { Client, Portfolio } from '@financial-app/shared/models';

@Component({
  selector: 'app-client-profile',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './client-profile.component.html',
  styleUrl: './client-profile.component.scss',
})
export class ClientProfileComponent {
  /** Bound from route param :id via withComponentInputBinding() */
  id = input.required<string>();

  clientResource = httpResource<Client>({
    url: () => `/api/clients/${this.id()}`,
  });

  portfoliosResource = httpResource<Portfolio[]>({
    url: () => `/api/clients/${this.id()}/portfolios`,
  });
}
