// See ch56-appendix-c-reactive-forms.md -- minimal Reactive Forms companion spec.
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { describe, it, expect, beforeEach } from 'vitest';
import { ReactiveFormsCompatComponent } from './reactive-forms-compat.component';

describe('ReactiveFormsCompatComponent', () => {
  let fixture: ComponentFixture<ReactiveFormsCompatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsCompatComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ReactiveFormsCompatComponent);
    fixture.detectChanges();
  });

  it('starts invalid with both required fields empty', () => {
    expect(fixture.componentInstance.form.invalid).toBe(true);
    expect(fixture.componentInstance.form.controls['name'].errors?.['required']).toBeDefined();
    expect(fixture.componentInstance.form.controls['email'].errors?.['required']).toBeDefined();
  });

  it('becomes valid once name and a valid email are populated', () => {
    fixture.componentInstance.form.patchValue({
      name: 'Ada Lovelace',
      email: 'ada@example.com',
    });
    expect(fixture.componentInstance.form.valid).toBe(true);
  });

  it('rejects an invalid email', () => {
    fixture.componentInstance.form.patchValue({
      name: 'Ada Lovelace',
      email: 'not-an-email',
    });
    const emailCtl = fixture.componentInstance.form.controls['email'];
    expect(emailCtl.valid).toBe(false);
    expect(emailCtl.errors?.['email']).toBeDefined();
  });
});
