// See ch56-appendix-c-reactive-forms.md -- minimal Reactive Forms companion (Appendix C).
import { Component, inject } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';

@Component({
  selector: 'app-reactive-forms-compat',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './reactive-forms-compat.component.html',
})
export class ReactiveFormsCompatComponent {
  private readonly fb = inject(FormBuilder);

  readonly form: FormGroup = this.fb.group({
    email: this.fb.control<string>('', {
      nonNullable: true,
      validators: [Validators.required, Validators.email],
    }),
    name: this.fb.control<string>('', {
      nonNullable: true,
      validators: [Validators.required],
    }),
  });

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    // eslint-disable-next-line no-console
    console.log('reactive form submitted', this.form.getRawValue());
  }
}
