// See ch06-signal-forms.md -- "Reactive Forms Compatibility"
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { describe, it, expect, beforeEach } from 'vitest';
import { LegacyTransferComponent } from './legacy-transfer.component';

describe('LegacyTransferComponent', () => {
  let fixture: ComponentFixture<LegacyTransferComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LegacyTransferComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(LegacyTransferComponent);
    fixture.detectChanges();
  });

  it('marks the form invalid when required fields are missing', () => {
    expect(fixture.componentInstance.form.invalid).toBe(true);
    expect(fixture.componentInstance.summary()).toContain('Fill in');
  });

  it('becomes valid once amount and recipient are populated', () => {
    fixture.componentInstance.form.patchValue({
      amount: 100.5,
      recipient: 'Alice',
    });
    fixture.detectChanges();

    expect(fixture.componentInstance.form.valid).toBe(true);
    expect(fixture.componentInstance.summary()).toBe('Transfer 100.50 to Alice.');
  });

  it('rejects amounts below the minimum', () => {
    fixture.componentInstance.form.patchValue({
      amount: 0,
      recipient: 'Alice',
    });
    fixture.detectChanges();

    const amountCtl = fixture.componentInstance.form.controls.amount;
    expect(amountCtl.valid).toBe(false);
    expect(amountCtl.errors?.['min']).toBeDefined();
  });

  it('enforces minLength on recipient', () => {
    fixture.componentInstance.form.patchValue({
      amount: 100,
      recipient: 'Al',
    });
    fixture.detectChanges();

    const recipientCtl = fixture.componentInstance.form.controls.recipient;
    expect(recipientCtl.valid).toBe(false);
    expect(recipientCtl.errors?.['minlength']).toBeDefined();
  });
});
