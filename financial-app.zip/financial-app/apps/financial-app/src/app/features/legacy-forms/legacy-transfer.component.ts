// See ch06-signal-forms.md -- "Reactive Forms Compatibility"
import { Component, computed, inject } from '@angular/core';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { toSignal } from '@angular/core/rxjs-interop';

/**
 * LegacyTransferComponent demonstrates the classic Reactive Forms API
 * (FormBuilder / FormGroup / Validators) and how to interop with signals
 * via toSignal(form.valueChanges). New forms in this book use Signal
 * Forms (see ch06-signal-forms.md); this component exists so readers
 * maintaining legacy code have a working reference.
 */
@Component({
  selector: 'app-legacy-transfer',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule],
  templateUrl: './legacy-transfer.component.html',
  styleUrl: './legacy-transfer.component.scss',
})
export class LegacyTransferComponent {
  private readonly fb = inject(FormBuilder);

  readonly form = this.fb.group({
    amount: this.fb.control<number | null>(null, {
      validators: [Validators.required, Validators.min(0.01)],
    }),
    recipient: this.fb.control<string>('', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(3)],
    }),
    memo: this.fb.control<string>('', { nonNullable: true }),
  });

  /** Template-driven [(ngModel)] example: held in a plain field. */
  quickNote = '';

  /** Signal derived from the reactive form for computed-driven UI. */
  readonly formValue = toSignal(this.form.valueChanges, {
    initialValue: this.form.getRawValue(),
  });

  readonly summary = computed(() => {
    const value = this.formValue();
    if (!value.amount || !value.recipient) {
      return 'Fill in both amount and recipient.';
    }
    return `Transfer ${value.amount.toFixed(2)} to ${value.recipient}.`;
  });

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    // eslint-disable-next-line no-console
    console.log('transfer submitted', this.form.getRawValue());
  }
}
