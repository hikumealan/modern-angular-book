// See ch02-signal-components.md -- "Advanced HTTP"
import { Component, DestroyRef, inject, signal } from '@angular/core';
import {
  ImportProgress,
  TransactionImportService,
} from './transaction-import.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-transaction-import',
  standalone: true,
  templateUrl: './transaction-import.component.html',
  styleUrl: './transaction-import.component.scss',
})
export class TransactionImportComponent {
  private readonly importer = inject(TransactionImportService);
  private readonly destroyRef = inject(DestroyRef);

  readonly progress = signal<ImportProgress>({ state: 'idle' });

  private subscription: Subscription | null = null;

  constructor() {
    this.destroyRef.onDestroy(() => this.cancel());
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) {
      return;
    }

    this.cancel();
    this.progress.set({ state: 'uploading', percent: 0 });

    this.subscription = this.importer.import(file).subscribe({
      next: (next) => this.progress.set(next),
      error: (err: unknown) => {
        const fallback = $localize`:@@transactions.import.uploadFailed:Upload failed.`;
        const message = err instanceof Error ? err.message : fallback;
        this.progress.set({ state: 'error', message });
      },
    });
  }

  cancel(): void {
    this.subscription?.unsubscribe();
    this.subscription = null;
  }
}
