// See ch02-signal-components.md -- "Creating a Signal-based Component"
import { Component, computed, inject, signal } from '@angular/core';
import { TransactionCardComponent } from '@financial-app/shared/ui';
import { Transaction } from '@financial-app/shared/models';
import { TransactionService } from '@financial-app/shared/data-access';

export type SortMode = 'date' | 'amount' | 'category';

@Component({
  selector: 'app-transaction-search',
  standalone: true,
  imports: [TransactionCardComponent],
  templateUrl: './transaction-search.component.html',
  styleUrl: './transaction-search.component.scss',
})
export class TransactionSearchComponent {
  private transactionService = inject(TransactionService);

  readonly transactions = signal<Transaction[]>([]);
  readonly loading = signal(false);

  readonly accountId = signal<number | null>(null);
  readonly category = signal('');
  readonly dateRange = signal<{ start: string; end: string }>({
    start: '',
    end: '',
  });
  readonly sortMode = signal<SortMode>('date');

  readonly filteredTransactions = computed(() => {
    let result = this.transactions();

    const acctId = this.accountId();
    if (acctId !== null) {
      result = result.filter((t) => t.accountId === acctId);
    }

    const cat = this.category();
    if (cat) {
      result = result.filter((t) =>
        t.category.toLowerCase().includes(cat.toLowerCase()),
      );
    }

    const range = this.dateRange();
    if (range.start) {
      result = result.filter((t) => t.date >= range.start);
    }
    if (range.end) {
      result = result.filter((t) => t.date <= range.end);
    }

    return this.sortTransactions(result, this.sortMode());
  });

  constructor() {
    this.loadTransactions();
  }

  loadTransactions(): void {
    this.loading.set(true);
    this.transactionService.getAll().subscribe({
      next: (data) => {
        this.transactions.set(data);
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }

  private sortTransactions(
    txns: Transaction[],
    mode: SortMode,
  ): Transaction[] {
    const sorted = [...txns];
    switch (mode) {
      case 'date':
        return sorted.sort((a, b) => b.date.localeCompare(a.date));
      case 'amount':
        return sorted.sort((a, b) => b.amount - a.amount);
      case 'category':
        return sorted.sort((a, b) => a.category.localeCompare(b.category));
    }
  }
}
