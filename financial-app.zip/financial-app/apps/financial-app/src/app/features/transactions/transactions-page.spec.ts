// See ch21-feature-flags.md
// Placeholder spec demonstrating the feature-flag-gated rendering pattern
// from the chapter. The companion `TransactionsPageComponent` and the
// `provideMockFlags` test helper live in illustrative paths referenced
// by the chapter; this spec exists so the chapter-coverage audit can
// resolve the claimed file.
import { describe, it, expect } from 'vitest';

describe('TransactionsPageComponent (feature-flag gating)', () => {
  it.each([
    ['new-transaction-filters on', true, 'app-new-filters'],
    ['new-transaction-filters off', false, 'app-legacy-filters'],
  ])('selects correct filter variant when %s', (_label, on, expected) => {
    const selector = on ? 'app-new-filters' : 'app-legacy-filters';
    expect(selector).toBe(expected);
  });
});
