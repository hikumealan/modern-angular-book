// See ch07-testing-vitest.md
//
// EXPERIMENTAL: These tests exercise the signal-based forms API.
// Adjust assertions if the form field API changes in a future Angular release.
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';

import { TransactionService } from '@financial-app/shared/data-access';
import { TransactionEntryComponent } from './transaction-entry.component';

const mockTransactionService = {
  create: vi.fn().mockReturnValue(of({ id: 99 })),
};

describe('TransactionEntryComponent', () => {
  let component: TransactionEntryComponent;
  let fixture: ComponentFixture<TransactionEntryComponent>;

  beforeEach(async () => {
    mockTransactionService.create.mockReturnValue(of({ id: 99 }));

    await TestBed.configureTestingModule({
      imports: [TransactionEntryComponent],
      providers: [
        provideRouter([]),
        { provide: TransactionService, useValue: mockTransactionService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(TransactionEntryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize form with default values', () => {
    const value = component.form.value();
    expect(value.amount).toBe(0);
    expect(value.type).toBe('debit');
    expect(value.category).toBe('');
    expect(value.description).toBe('');
    expect(value.accountId).toBeNull();
  });

  it('should start with an invalid form (amount and accountId required)', () => {
    expect(component.form.valid()).toBe(false);
  });

  it('should become valid when required fields are filled', () => {
    component.form.controls.amount.setValue(100);
    component.form.controls.accountId.setValue(1);

    expect(component.form.valid()).toBe(true);
  });

  it('should not submit when form is invalid', () => {
    component.onSubmit();
    expect(mockTransactionService.create).not.toHaveBeenCalled();
  });

  it('should call TransactionService.create on valid submit', () => {
    component.form.controls.amount.setValue(50);
    component.form.controls.type.setValue('credit');
    component.form.controls.category.setValue('Income');
    component.form.controls.description.setValue('Freelance payment');
    component.form.controls.accountId.setValue(1);

    component.onSubmit();

    expect(mockTransactionService.create).toHaveBeenCalledWith(
      expect.objectContaining({
        amount: 50,
        type: 'credit',
        category: 'Income',
        accountId: 1,
        pending: true,
      }),
    );
  });
});
