// See ch04-router.md -- "Lazy-Loaded Feature Routes"
import { Routes } from '@angular/router';

export const TRANSACTION_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./transaction-search.component').then(
        (m) => m.TransactionSearchComponent,
      ),
  },
  {
    path: 'new',
    loadComponent: () =>
      import('./transaction-entry.component').then(
        (m) => m.TransactionEntryComponent,
      ),
  },
];
