// See ch07-testing-vitest.md
import { describe, it, expect, beforeEach } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { HttpClient, provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting,
} from '@angular/common/http/testing';

import { Transaction } from '@financial-app/shared/models';
import { TransactionStore } from './transaction.store';

const MOCK_TRANSACTIONS: Transaction[] = [
  {
    id: 1,
    accountId: 100,
    amount: 500,
    type: 'credit',
    category: 'Salary',
    date: '2025-04-01',
    description: 'Payroll deposit',
    pending: false,
  },
  {
    id: 2,
    accountId: 100,
    amount: 75.5,
    type: 'debit',
    category: 'Dining',
    date: '2025-04-02',
    description: 'Restaurant dinner',
    pending: false,
  },
  {
    id: 3,
    accountId: 200,
    amount: 200,
    type: 'debit',
    category: 'Utilities',
    date: '2025-04-03',
    description: 'Internet bill',
    pending: true,
  },
];

describe('TransactionStore', () => {
  let store: InstanceType<typeof TransactionStore>;
  let httpTesting: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        TransactionStore,
      ],
    });

    store = TestBed.inject(TransactionStore);
    httpTesting = TestBed.inject(HttpTestingController);
  });

  it('should start with empty entities and no loading/error state', () => {
    expect(store.entities()).toEqual([]);
    expect(store.loading()).toBe(false);
    expect(store.error()).toBeNull();
  });

  it('should load transactions into entity state', async () => {
    const loadPromise = store.load();
    httpTesting.expectOne('/api/transactions').flush(MOCK_TRANSACTIONS);
    await loadPromise;

    expect(store.entities()).toHaveLength(3);
    expect(store.loading()).toBe(false);
  });

  it('should compute totalCredits and totalDebits', async () => {
    const loadPromise = store.load();
    httpTesting.expectOne('/api/transactions').flush(MOCK_TRANSACTIONS);
    await loadPromise;

    expect(store.totalCredits()).toBe(500);
    expect(store.totalDebits()).toBe(275.5);
  });

  it('should compute netBalance', async () => {
    const loadPromise = store.load();
    httpTesting.expectOne('/api/transactions').flush(MOCK_TRANSACTIONS);
    await loadPromise;

    expect(store.netBalance()).toBe(500 - 75.5 - 200);
  });

  it('should filter transactions by description or category', async () => {
    const loadPromise = store.load();
    httpTesting.expectOne('/api/transactions').flush(MOCK_TRANSACTIONS);
    await loadPromise;

    store.setFilter('dining');
    expect(store.filteredTransactions()).toHaveLength(1);
    expect(store.filteredTransactions()[0].id).toBe(2);
  });

  it('should return all transactions when filter is empty', async () => {
    const loadPromise = store.load();
    httpTesting.expectOne('/api/transactions').flush(MOCK_TRANSACTIONS);
    await loadPromise;

    store.setFilter('');
    expect(store.filteredTransactions()).toHaveLength(3);
  });

  it('should add a transaction', async () => {
    const newTxn: Omit<Transaction, 'id'> = {
      accountId: 100,
      amount: 30,
      type: 'debit',
      category: 'Coffee',
      date: '2025-04-04',
      description: 'Morning latte',
      pending: false,
    };
    const created: Transaction = { ...newTxn, id: 4 };

    const addPromise = store.add(newTxn);
    httpTesting.expectOne('/api/transactions').flush(created);
    await addPromise;

    expect(store.entities()).toHaveLength(1);
    expect(store.entities()[0].id).toBe(4);
  });

  it('should update a transaction in place', async () => {
    const loadPromise = store.load();
    httpTesting.expectOne('/api/transactions').flush(MOCK_TRANSACTIONS);
    await loadPromise;

    const updated: Transaction = {
      ...MOCK_TRANSACTIONS[0],
      description: 'Updated payroll',
    };
    const updatePromise = store.update(1, { description: 'Updated payroll' });
    httpTesting.expectOne('/api/transactions/1').flush(updated);
    await updatePromise;

    const entity = store.entities().find((t) => t.id === 1);
    expect(entity?.description).toBe('Updated payroll');
  });

  it('should handle load errors', async () => {
    const loadPromise = store.load();
    httpTesting
      .expectOne('/api/transactions')
      .flush('Server error', {
        status: 500,
        statusText: 'Internal Server Error',
      });
    await loadPromise;

    expect(store.error()).toBe('Failed to load transactions');
    expect(store.entities()).toEqual([]);
    expect(store.loading()).toBe(false);
  });
});
