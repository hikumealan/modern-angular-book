// See ch06-signal-forms.md -- "A First Signal Form"
//
// EXPERIMENTAL: Angular's signal-based forms API is under active development.
// The function names, import paths, and validator signatures shown here reflect
// the proposal at the time of writing and WILL change in future releases.
import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { createFormGroup, formField, required, min } from '@angular/forms/signals';
import { TransactionService } from '@financial-app/shared/data-access';

@Component({
  selector: 'app-transaction-entry',
  standalone: true,
  templateUrl: './transaction-entry.component.html',
  styleUrl: './transaction-entry.component.scss',
})
export class TransactionEntryComponent {
  private transactionService = inject(TransactionService);
  private router = inject(Router);

  // EXPERIMENTAL -- signal form shape subject to change
  readonly form = createFormGroup({
    amount: formField(0, { validators: [required(), min(0.01)] }),
    type: formField<'credit' | 'debit'>('debit'),
    category: formField(''),
    description: formField(''),
    date: formField(new Date().toISOString().split('T')[0]),
    accountId: formField<number | null>(null, { validators: [required()] }),
  });

  readonly submitting = false;

  onSubmit(): void {
    if (!this.form.valid()) {
      return;
    }

    const value = this.form.value();

    this.transactionService
      .create({
        amount: value.amount,
        type: value.type,
        category: value.category,
        description: value.description,
        date: value.date,
        accountId: value.accountId!,
        pending: true,
      })
      .subscribe({
        next: () => this.router.navigate(['/transactions']),
      });
  }
}
