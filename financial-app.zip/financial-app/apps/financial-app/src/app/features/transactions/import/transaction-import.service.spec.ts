// See ch02-signal-components.md -- "Advanced HTTP"
import { TestBed } from '@angular/core/testing';
import {
  provideHttpClient,
  withInterceptorsFromDi,
} from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting,
} from '@angular/common/http/testing';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { ImportProgress, TransactionImportService } from './transaction-import.service';

describe('TransactionImportService', () => {
  let service: TransactionImportService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting(),
        TransactionImportService,
      ],
    });

    service = TestBed.inject(TransactionImportService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    http.verify();
  });

  it('emits a complete progress state with the server-reported count', () => {
    const file = new File(['id,amount\n1,100'], 'transactions.csv', {
      type: 'text/csv',
    });

    const events: ImportProgress[] = [];
    service.import(file).subscribe((event) => events.push(event));

    const req = http.expectOne('/api/transactions/import');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toBeInstanceOf(FormData);
    expect(req.request.reportProgress).toBe(true);

    req.flush({ importedCount: 42 });

    const last = events[events.length - 1];
    expect(last).toEqual({ state: 'complete', importedCount: 42 });
  });
});
