// See ch02-signal-components.md -- "Advanced HTTP"
import { inject, Injectable } from '@angular/core';
import {
  HttpClient,
  HttpEvent,
  HttpEventType,
  HttpRequest,
} from '@angular/common/http';
import { map, Observable } from 'rxjs';

export type ImportProgress =
  | { state: 'idle' }
  | { state: 'uploading'; percent: number }
  | { state: 'processing' }
  | { state: 'complete'; importedCount: number }
  | { state: 'error'; message: string };

@Injectable({ providedIn: 'root' })
export class TransactionImportService {
  private readonly http = inject(HttpClient);

  import(file: File): Observable<ImportProgress> {
    const form = new FormData();
    form.append('file', file, file.name);

    const req = new HttpRequest<FormData>(
      'POST',
      '/api/transactions/import',
      form,
      { reportProgress: true },
    );

    return this.http.request<{ importedCount: number }>(req).pipe(
      map((event: HttpEvent<{ importedCount: number }>): ImportProgress => {
        switch (event.type) {
          case HttpEventType.UploadProgress: {
            const total = event.total ?? file.size;
            const percent = total > 0 ? Math.round((100 * event.loaded) / total) : 0;
            return { state: 'uploading', percent };
          }
          case HttpEventType.Response: {
            const body = event.body;
            return {
              state: 'complete',
              importedCount: body?.importedCount ?? 0,
            };
          }
          case HttpEventType.Sent:
          case HttpEventType.ResponseHeader:
          default:
            return { state: 'processing' };
        }
      }),
    );
  }
}
