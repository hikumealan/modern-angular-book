// See ch10-ngrx-signal-store.md -- "A First SignalStore"
import { computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import {
  signalStore,
  withState,
  withComputed,
  withMethods,
  patchState,
} from '@ngrx/signals';
import {
  withEntities,
  setAllEntities,
  addEntity,
  updateEntity,
} from '@ngrx/signals/entities';
import { Transaction } from '@financial-app/shared/models';

type TransactionStoreState = {
  loading: boolean;
  error: string | null;
  filter: string;
};

const initialState: TransactionStoreState = {
  loading: false,
  error: null,
  filter: '',
};

export const TransactionStore = signalStore(
  { providedIn: 'root' },
  withEntities<Transaction>(),
  withState(initialState),
  withComputed(({ entities, filter }) => ({
    filteredTransactions: computed(() => {
      const term = filter();
      if (!term) return entities();
      const lower = term.toLowerCase();
      return entities().filter(
        (t) =>
          t.description.toLowerCase().includes(lower) ||
          t.category.toLowerCase().includes(lower),
      );
    }),
    totalCredits: computed(() =>
      entities()
        .filter((t) => t.type === 'credit')
        .reduce((sum, t) => sum + t.amount, 0),
    ),
    totalDebits: computed(() =>
      entities()
        .filter((t) => t.type === 'debit')
        .reduce((sum, t) => sum + t.amount, 0),
    ),
    netBalance: computed(() => {
      const all = entities();
      return all.reduce(
        (sum, t) => sum + (t.type === 'credit' ? t.amount : -t.amount),
        0,
      );
    }),
  })),
  withMethods((store) => {
    const http = inject(HttpClient);

    return {
      async load(): Promise<void> {
        patchState(store, { loading: true, error: null });
        try {
          const data = await firstValueFrom(
            http.get<Transaction[]>('/api/transactions'),
          );
          patchState(store, setAllEntities(data));
        } catch {
          patchState(store, { error: 'Failed to load transactions' });
        } finally {
          patchState(store, { loading: false });
        }
      },

      async add(transaction: Omit<Transaction, 'id'>): Promise<void> {
        const created = await firstValueFrom(
          http.post<Transaction>('/api/transactions', transaction),
        );
        patchState(store, addEntity(created));
      },

      async update(
        id: number,
        changes: Partial<Transaction>,
      ): Promise<void> {
        const updated = await firstValueFrom(
          http.patch<Transaction>(`/api/transactions/${id}`, changes),
        );
        patchState(store, updateEntity({ id, changes: updated }));
      },

      setFilter(term: string): void {
        patchState(store, { filter: term });
      },
    };
  }),
);
