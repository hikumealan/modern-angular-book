// See ch07-testing-vitest.md
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { of } from 'rxjs';

import { Transaction } from '@financial-app/shared/models';
import { TransactionService } from '@financial-app/shared/data-access';
import { TransactionSearchComponent } from './transaction-search.component';

const MOCK_TRANSACTIONS: Transaction[] = [
  {
    id: 1,
    accountId: 100,
    amount: 250,
    type: 'credit',
    category: 'Salary',
    date: '2025-03-15',
    description: 'Monthly paycheck',
    pending: false,
  },
  {
    id: 2,
    accountId: 100,
    amount: 42.99,
    type: 'debit',
    category: 'Groceries',
    date: '2025-03-16',
    description: 'Supermarket purchase',
    pending: true,
  },
  {
    id: 3,
    accountId: 200,
    amount: 120,
    type: 'debit',
    category: 'Utilities',
    date: '2025-03-10',
    description: 'Electric bill',
    pending: false,
  },
];

const mockTransactionService = {
  getAll: vi.fn().mockReturnValue(of(MOCK_TRANSACTIONS)),
};

describe('TransactionSearchComponent', () => {
  let component: TransactionSearchComponent;
  let fixture: ComponentFixture<TransactionSearchComponent>;

  beforeEach(async () => {
    mockTransactionService.getAll.mockReturnValue(of(MOCK_TRANSACTIONS));

    await TestBed.configureTestingModule({
      imports: [TransactionSearchComponent],
      providers: [
        { provide: TransactionService, useValue: mockTransactionService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(TransactionSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should load transactions on init', () => {
    expect(mockTransactionService.getAll).toHaveBeenCalled();
    expect(component.transactions()).toHaveLength(3);
  });

  it('should show all transactions when no filters are applied', () => {
    expect(component.filteredTransactions()).toHaveLength(3);
  });

  it('should filter by category', () => {
    component.category.set('Groceries');
    expect(component.filteredTransactions()).toHaveLength(1);
    expect(component.filteredTransactions()[0].id).toBe(2);
  });

  it('should filter by partial category match (case-insensitive)', () => {
    component.category.set('sal');
    expect(component.filteredTransactions()).toHaveLength(1);
    expect(component.filteredTransactions()[0].category).toBe('Salary');
  });

  it('should filter by accountId', () => {
    component.accountId.set(200);
    expect(component.filteredTransactions()).toHaveLength(1);
    expect(component.filteredTransactions()[0].description).toBe('Electric bill');
  });

  it('should filter by date range', () => {
    component.dateRange.set({ start: '2025-03-14', end: '2025-03-16' });
    const filtered = component.filteredTransactions();
    expect(filtered).toHaveLength(2);
    expect(filtered.map((t) => t.id)).toContain(1);
    expect(filtered.map((t) => t.id)).toContain(2);
  });

  it('should combine multiple filters', () => {
    component.accountId.set(100);
    component.category.set('Groceries');
    expect(component.filteredTransactions()).toHaveLength(1);
    expect(component.filteredTransactions()[0].id).toBe(2);
  });

  it('should sort by date descending by default', () => {
    const dates = component.filteredTransactions().map((t) => t.date);
    expect(dates).toEqual(['2025-03-16', '2025-03-15', '2025-03-10']);
  });

  it('should sort by amount when sort mode changes', () => {
    component.sortMode.set('amount');
    const amounts = component.filteredTransactions().map((t) => t.amount);
    expect(amounts).toEqual([250, 120, 42.99]);
  });

  it('should sort by category alphabetically', () => {
    component.sortMode.set('category');
    const categories = component.filteredTransactions().map((t) => t.category);
    expect(categories).toEqual(['Groceries', 'Salary', 'Utilities']);
  });

  it('should render transaction cards', () => {
    const el: HTMLElement = fixture.nativeElement;
    const cards = el.querySelectorAll('fin-transaction-card');
    expect(cards.length).toBe(3);
  });

  it('should show empty message when no transactions match', () => {
    component.category.set('nonexistent');
    fixture.detectChanges();

    const el: HTMLElement = fixture.nativeElement;
    expect(el.querySelector('.status-message')?.textContent).toContain(
      'No transactions match',
    );
  });
});
