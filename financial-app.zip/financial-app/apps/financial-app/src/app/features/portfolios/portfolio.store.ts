// See ch05-state-management.md
import { computed, inject, Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Portfolio, Holding } from '@financial-app/shared/models';

@Injectable({ providedIn: 'root' })
export class PortfolioStore {
  private http = inject(HttpClient);

  private portfolios = signal<Portfolio[]>([]);
  private selectedHoldings = signal<Holding[]>([]);
  private loading = signal(false);
  private error = signal<string | null>(null);

  readonly portfolios$ = this.portfolios.asReadonly();
  readonly selectedHoldings$ = this.selectedHoldings.asReadonly();
  readonly loading$ = this.loading.asReadonly();
  readonly error$ = this.error.asReadonly();

  readonly totalValue = computed(() =>
    this.portfolios().reduce((sum, p) => sum + p.totalValue, 0),
  );

  readonly holdingCount = computed(() => this.selectedHoldings().length);

  readonly totalGainLoss = computed(() =>
    this.selectedHoldings().reduce(
      (sum, h) => sum + (h.currentPrice - h.purchasePrice) * h.shares,
      0,
    ),
  );

  loadPortfolios(clientId: number): void {
    this.loading.set(true);
    this.error.set(null);

    this.http.get<Portfolio[]>(`/api/clients/${clientId}/portfolios`).subscribe({
      next: (data) => {
        this.portfolios.set(data);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(err.message);
        this.loading.set(false);
      },
    });
  }

  loadHoldings(portfolioId: number): void {
    this.loading.set(true);
    this.error.set(null);

    this.http.get<Holding[]>(`/api/portfolios/${portfolioId}/holdings`).subscribe({
      next: (data) => {
        this.selectedHoldings.set(data);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(err.message);
        this.loading.set(false);
      },
    });
  }
}
