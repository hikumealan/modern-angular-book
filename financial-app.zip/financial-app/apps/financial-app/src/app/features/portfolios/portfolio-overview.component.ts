// See ch02-signal-components.md -- "Signal-Based Inputs from the Router"
// See ch06-http.md -- "Loading Data with httpResource"
import { Component, computed, input } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { RouterLink } from '@angular/router';
// httpResource is experimental in Angular v21 -- API may change in future releases
import { httpResource } from '@angular/common/http';

import { Portfolio } from '@financial-app/shared/models';

import { HoldingDetailComponent } from './holding-detail.component';

@Component({
  selector: 'app-portfolio-overview',
  standalone: true,
  imports: [CurrencyPipe, RouterLink, HoldingDetailComponent],
  templateUrl: './portfolio-overview.component.html',
  styleUrl: './portfolio-overview.component.scss',
})
export class PortfolioOverviewComponent {
  /** Bound from route param :clientId via withComponentInputBinding() */
  clientId = input.required<string>();

  portfoliosResource = httpResource<Portfolio[]>({
    url: () => `/api/clients/${this.clientId()}/portfolios`,
  });

  // See ch03-signals.md -- "Derived State with computed()"
  totalPortfolioValue = computed(() => {
    const portfolios = this.portfoliosResource.value();
    if (!portfolios) return 0;
    return portfolios.reduce((sum, p) => sum + p.totalValue, 0);
  });

  portfolioCount = computed(() => this.portfoliosResource.value()?.length ?? 0);
}
