// See ch04-components.md -- "Signal-Based Inputs from the Router"
// See ch06-http.md -- "Loading Data with httpResource"
// See ch03-signals.md -- "Derived State with computed()"
import { Component, computed, input } from '@angular/core';
import { CurrencyPipe, DecimalPipe } from '@angular/common';
// httpResource is experimental in Angular v21 -- API may change in future releases
import { httpResource } from '@angular/common/http';

import { Holding } from '@financial-app/shared/models';

@Component({
  selector: 'app-holding-detail',
  standalone: true,
  imports: [CurrencyPipe, DecimalPipe],
  templateUrl: './holding-detail.component.html',
  styleUrl: './holding-detail.component.scss',
})
export class HoldingDetailComponent {
  /** Bound from route param :portfolioId via withComponentInputBinding() */
  portfolioId = input.required<string>();

  holdingsResource = httpResource<Holding[]>({
    url: () => `/api/portfolios/${this.portfolioId()}/holdings`,
  });

  totalGainLoss = computed(() => {
    const holdings = this.holdingsResource.value();
    if (!holdings) return 0;
    return holdings.reduce(
      (sum, h) => sum + (h.currentPrice - h.purchasePrice) * h.shares,
      0,
    );
  });

  holdingsWithGainLoss = computed(() => {
    const holdings = this.holdingsResource.value();
    if (!holdings) return [];
    return holdings.map((h) => ({
      ...h,
      gainLoss: (h.currentPrice - h.purchasePrice) * h.shares,
      gainLossPercent: ((h.currentPrice - h.purchasePrice) / h.purchasePrice) * 100,
    }));
  });
}
