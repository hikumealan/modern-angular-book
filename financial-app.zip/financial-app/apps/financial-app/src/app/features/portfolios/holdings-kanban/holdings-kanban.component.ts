// See ch44-drag-and-drop.md -- "Transferring Between Lists: The Transaction Kanban"
import {
  ChangeDetectionStrategy,
  Component,
  signal,
  type WritableSignal,
} from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import {
  CdkDrag,
  type CdkDragDrop,
  CdkDropList,
  CdkDropListGroup,
  moveItemInArray,
  transferArrayItem,
} from '@angular/cdk/drag-drop';

export type HoldingStatus = 'watchlist' | 'active' | 'closed';

export interface KanbanHolding {
  id: string;
  ticker: string;
  company: string;
  shares: number;
  lastPrice: number;
}

interface KanbanColumn {
  status: HoldingStatus;
  label: string;
  items: WritableSignal<KanbanHolding[]>;
}

@Component({
  selector: 'app-holdings-kanban',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CdkDropListGroup, CdkDropList, CdkDrag, CurrencyPipe],
  templateUrl: './holdings-kanban.component.html',
  styleUrl: './holdings-kanban.component.scss',
})
export class HoldingsKanbanComponent {
  // Each column owns its own signal so re-rendering one column does not
  // invalidate the sibling columns. A single `signal<Record<...>>` would
  // notify every subscriber on every drop.
  private readonly signalFor: Record<
    HoldingStatus,
    WritableSignal<KanbanHolding[]>
  > = {
    watchlist: signal<KanbanHolding[]>([
      { id: 'h1', ticker: 'AAPL', company: 'Apple Inc.', shares: 0, lastPrice: 189.42 },
      { id: 'h2', ticker: 'MSFT', company: 'Microsoft Corp.', shares: 0, lastPrice: 418.56 },
    ]),
    active: signal<KanbanHolding[]>([
      { id: 'h3', ticker: 'GOOG', company: 'Alphabet Inc.', shares: 12, lastPrice: 172.18 },
      { id: 'h4', ticker: 'NVDA', company: 'NVIDIA Corp.', shares: 25, lastPrice: 131.77 },
    ]),
    closed: signal<KanbanHolding[]>([
      { id: 'h5', ticker: 'IBM', company: 'IBM Corp.', shares: 0, lastPrice: 228.45 },
    ]),
  };

  protected readonly columns: readonly KanbanColumn[] = [
    { status: 'watchlist', label: 'Watchlist', items: this.signalFor.watchlist },
    { status: 'active', label: 'Active', items: this.signalFor.active },
    { status: 'closed', label: 'Closed', items: this.signalFor.closed },
  ];

  protected onDrop(
    event: CdkDragDrop<KanbanHolding[]>,
    target: HoldingStatus,
  ): void {
    if (event.previousContainer === event.container) {
      if (event.previousIndex === event.currentIndex) {
        return;
      }
      this.signalFor[target].update((items) => {
        const next = [...items];
        moveItemInArray(next, event.previousIndex, event.currentIndex);
        return next;
      });
      return;
    }

    // Cross-column move: copy both arrays before `transferArrayItem`
    // mutates them so we can hand fresh references to both signals.
    const source = event.previousContainer.id.replace('list-', '') as HoldingStatus;
    const sourceNext = [...this.signalFor[source]()];
    const destNext = [...this.signalFor[target]()];
    transferArrayItem(
      sourceNext,
      destNext,
      event.previousIndex,
      event.currentIndex,
    );
    this.signalFor[source].set(sourceNext);
    this.signalFor[target].set(destNext);
  }
}
