// See ch04-router.md -- "Hierarchical Routing with Child Routes"
import { Routes } from '@angular/router';

export const PORTFOLIO_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./portfolio-overview.component').then(
        (m) => m.PortfolioOverviewComponent,
      ),
  },
  {
    // See ch17-defer.md -- "Lazy-Loaded Routes for Deferred Loading"
    path: 'holdings/:portfolioId',
    loadComponent: () =>
      import('./holding-detail.component').then(
        (m) => m.HoldingDetailComponent,
      ),
  },
];
