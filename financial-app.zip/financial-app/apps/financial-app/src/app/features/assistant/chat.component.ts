// See ch14-ai-assistant.md -- placeholder for the AI chat feature
import { Component, signal } from '@angular/core';

@Component({
  selector: 'app-chat',
  standalone: true,
  templateUrl: './chat.component.html',
  styleUrl: './chat.component.scss',
})
export class ChatComponent {
  readonly messages = signal<{ role: 'user' | 'assistant'; text: string }[]>([]);
  readonly input = signal('');

  send(): void {
    const text = this.input().trim();
    if (!text) return;
    this.messages.update((msgs) => [...msgs, { role: 'user', text }]);
    this.input.set('');
  }
}
