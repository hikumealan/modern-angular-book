// See ch47-ai-in-angular.md -- Hashbrown chat scaffold with dev-mode graceful degradation.
//
// Requires NG_HASHBROWN_KEY set in the environment for real LLM calls. When
// the key is absent (typical during `npm start`), the component renders a
// warning banner and falls back to a mock echo responder so the UI is still
// explorable. See the chapter for the full provider-proxy setup.

import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

type Message = { role: 'user' | 'assistant'; text: string };

/** Lightweight wrapper that decides between real Hashbrown and the mock echo. */
class ChatBridge {
  readonly hasKey = typeof (globalThis as { NG_HASHBROWN_KEY?: string }).NG_HASHBROWN_KEY === 'string';

  async send(history: Message[], text: string): Promise<string> {
    if (!this.hasKey) {
      // Mock echo responder: gives visible output so the UI can be demoed.
      await new Promise((r) => setTimeout(r, 200));
      return `(mock) you said: "${text}". Configure NG_HASHBROWN_KEY to enable the real assistant.`;
    }
    // In the full chapter implementation, delegate to Hashbrown's chatResource
    // here via a thin proxy backend. We keep the scaffold provider-agnostic.
    throw new Error(
      'Hashbrown backend proxy not wired up. See ch47-ai-in-angular.md for the provider setup.',
    );
  }
}

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './chat.component.html',
  styleUrl: './chat.component.scss',
})
export class ChatComponent {
  private readonly bridge = inject(ChatBridge, { optional: true }) ?? new ChatBridge();

  readonly messages = signal<Message[]>([]);
  readonly input = signal('');
  readonly thinking = signal(false);
  readonly hasKey = this.bridge.hasKey;
  readonly disabled = computed(() => this.thinking() || this.input().trim().length === 0);

  async send(): Promise<void> {
    const text = this.input().trim();
    if (!text) return;
    this.messages.update((msgs) => [...msgs, { role: 'user', text }]);
    this.input.set('');
    this.thinking.set(true);
    try {
      const reply = await this.bridge.send(this.messages(), text);
      this.messages.update((msgs) => [...msgs, { role: 'assistant', text: reply }]);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Assistant failed. Please retry.';
      this.messages.update((msgs) => [...msgs, { role: 'assistant', text: `Error: ${message}` }]);
    } finally {
      this.thinking.set(false);
    }
  }
}
