// See ch03-reactive-signals.md -- "Working with RxJS"
import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import {
  provideHttpClient,
  withInterceptorsFromDi,
} from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting,
} from '@angular/common/http/testing';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { AccountTypeaheadComponent } from './account-typeahead.component';
import { Account } from '@financial-app/shared/models';

const sampleAccount: Account = {
  id: 1,
  name: 'Primary Checking',
  type: 'checking',
  balance: 1234,
  currency: 'USD',
  ownerId: 10,
};

describe('AccountTypeaheadComponent', () => {
  let fixture: ComponentFixture<AccountTypeaheadComponent>;
  let http: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AccountTypeaheadComponent],
      providers: [
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting(),
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(AccountTypeaheadComponent);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    http.verify();
  });

  it('does not fire a request when the query is shorter than 2 characters', fakeAsync(() => {
    fixture.detectChanges();
    fixture.componentInstance.query.set('p');
    tick(300);

    http.expectNone(/\/api\/accounts/);
  }));

  it('debounces input and issues exactly one request per quiescent term', fakeAsync(() => {
    fixture.detectChanges();
    fixture.componentInstance.query.set('pr');
    fixture.componentInstance.query.set('pri');
    fixture.componentInstance.query.set('prim');
    tick(300);

    const reqs = http.match((r) => r.url.startsWith('/api/accounts'));
    expect(reqs.length).toBe(1);
    expect(reqs[0].request.url).toContain('q=prim');

    reqs[0].flush([sampleAccount]);
    expect(fixture.componentInstance.results()).toEqual([sampleAccount]);
  }));
});
