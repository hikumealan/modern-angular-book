// See ch05-state-management.md -- "Implementing a Store with Signals"
import { computed, inject, Injectable, linkedSignal, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

import { Account } from '@financial-app/shared/models';

@Injectable({ providedIn: 'root' })
export class AccountStore {
  private http = inject(HttpClient);

  private accounts = signal<Account[]>([]);
  private loading = signal(false);
  private error = signal<string | null>(null);

  /** Writable + derived: resets to first account whenever the list changes */
  selectedAccount = linkedSignal<Account | null>(() =>
    this.accounts().length > 0 ? this.accounts()[0] : null,
  );

  readonly allAccounts = this.accounts.asReadonly();
  readonly isLoading = this.loading.asReadonly();
  readonly storeError = this.error.asReadonly();

  readonly totalBalance = computed(() =>
    this.accounts().reduce((sum, a) => sum + a.balance, 0),
  );

  readonly accountsByType = computed(() => {
    const grouped = new Map<Account['type'], Account[]>();
    for (const account of this.accounts()) {
      const list = grouped.get(account.type) ?? [];
      list.push(account);
      grouped.set(account.type, list);
    }
    return grouped;
  });

  async load(): Promise<void> {
    this.loading.set(true);
    this.error.set(null);
    try {
      const data = await firstValueFrom(
        this.http.get<Account[]>('/api/accounts'),
      );
      this.accounts.set(data);
    } catch (e) {
      this.error.set('Failed to load accounts');
    } finally {
      this.loading.set(false);
    }
  }

  async add(account: Omit<Account, 'id'>): Promise<void> {
    const created = await firstValueFrom(
      this.http.post<Account>('/api/accounts', account),
    );
    this.accounts.update((list) => [...list, created]);
  }

  async update(id: number, changes: Partial<Account>): Promise<void> {
    const updated = await firstValueFrom(
      this.http.patch<Account>(`/api/accounts/${id}`, changes),
    );
    this.accounts.update((list) =>
      list.map((a) => (a.id === id ? updated : a)),
    );
  }
}
