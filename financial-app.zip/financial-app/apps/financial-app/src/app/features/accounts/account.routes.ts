// See ch03-routing.md -- "Lazy-Loaded Feature Routes with Resolvers"
import { Routes } from '@angular/router';
import { inject } from '@angular/core';
import { AccountStore } from './account.store';

export const ACCOUNT_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./account-search.component').then(
        (m) => m.AccountSearchComponent,
      ),
  },
  {
    path: ':id',
    loadComponent: () =>
      import('./account-detail.component').then(
        (m) => m.AccountDetailComponent,
      ),
    resolve: {
      account: (route: import('@angular/router').ActivatedRouteSnapshot) => {
        const store = inject(AccountStore);
        const id = Number(route.paramMap.get('id'));
        return store.allAccounts().find((a) => a.id === id) ?? store.load().then(() =>
          store.allAccounts().find((a) => a.id === id),
        );
      },
    },
  },
];
