// See ch52-appendix-b0-backend-fastapi.md -- "Strategy D"
// Thin feature-level wrapper that delegates to the generated
// `AccountsService` from the typescript-angular client. Keeps the feature
// free of generator-specific types and gives us a single place to
// adapt method names if the backend contract shifts.
import { Injectable, inject } from '@angular/core';
import { AccountsService as GeneratedAccountsService } from '@financial-app/shared/api-client-ng';

@Injectable({ providedIn: 'root' })
export class AccountService {
  private readonly api = inject(GeneratedAccountsService);

  listAccounts() {
    return this.api.listAccounts();
  }

  getAccount(id: number) {
    return this.api.getAccount(id);
  }
}
