// See ch05-state-management.md -- "Testing Signal-Based Stores"
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { HttpClient, provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting,
} from '@angular/common/http/testing';

import { Account } from '@financial-app/shared/models';
import { AccountStore } from './account.store';

const MOCK_ACCOUNTS: Account[] = [
  { id: 1, name: 'Checking', type: 'checking', balance: 5000, currency: 'USD', ownerId: 1 },
  { id: 2, name: 'Savings', type: 'savings', balance: 12000, currency: 'USD', ownerId: 1 },
  { id: 3, name: 'Brokerage', type: 'investment', balance: 34000, currency: 'USD', ownerId: 1 },
];

describe('AccountStore', () => {
  let store: AccountStore;
  let httpTesting: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting(), AccountStore],
    });

    store = TestBed.inject(AccountStore);
    httpTesting = TestBed.inject(HttpTestingController);
  });

  it('should start with an empty accounts list', () => {
    expect(store.allAccounts()).toEqual([]);
    expect(store.totalBalance()).toBe(0);
  });

  it('should load accounts and update derived state', async () => {
    const loadPromise = store.load();
    httpTesting.expectOne('/api/accounts').flush(MOCK_ACCOUNTS);
    await loadPromise;

    expect(store.allAccounts()).toHaveLength(3);
    expect(store.totalBalance()).toBe(51000);
  });

  it('should group accounts by type', async () => {
    const loadPromise = store.load();
    httpTesting.expectOne('/api/accounts').flush(MOCK_ACCOUNTS);
    await loadPromise;

    const byType = store.accountsByType();
    expect(byType.get('checking')).toHaveLength(1);
    expect(byType.get('savings')).toHaveLength(1);
    expect(byType.get('investment')).toHaveLength(1);
  });

  it('should set selectedAccount to the first account after load', async () => {
    expect(store.selectedAccount()).toBeNull();

    const loadPromise = store.load();
    httpTesting.expectOne('/api/accounts').flush(MOCK_ACCOUNTS);
    await loadPromise;

    expect(store.selectedAccount()?.id).toBe(1);
  });

  it('should allow manually overriding selectedAccount', async () => {
    const loadPromise = store.load();
    httpTesting.expectOne('/api/accounts').flush(MOCK_ACCOUNTS);
    await loadPromise;

    store.selectedAccount.set(MOCK_ACCOUNTS[2]);
    expect(store.selectedAccount()?.id).toBe(3);
  });

  it('should add an account', async () => {
    const newAccount: Omit<Account, 'id'> = {
      name: 'New Savings',
      type: 'savings',
      balance: 0,
      currency: 'USD',
      ownerId: 1,
    };
    const created: Account = { ...newAccount, id: 4 };

    const addPromise = store.add(newAccount);
    httpTesting.expectOne('/api/accounts').flush(created);
    await addPromise;

    expect(store.allAccounts()).toHaveLength(1);
    expect(store.allAccounts()[0].id).toBe(4);
  });

  it('should update an account in place', async () => {
    const loadPromise = store.load();
    httpTesting.expectOne('/api/accounts').flush(MOCK_ACCOUNTS);
    await loadPromise;

    const updated: Account = { ...MOCK_ACCOUNTS[0], name: 'Primary Checking' };
    const updatePromise = store.update(1, { name: 'Primary Checking' });
    httpTesting.expectOne('/api/accounts/1').flush(updated);
    await updatePromise;

    expect(store.allAccounts().find((a) => a.id === 1)?.name).toBe(
      'Primary Checking',
    );
  });

  it('should handle load errors', async () => {
    const loadPromise = store.load();
    httpTesting
      .expectOne('/api/accounts')
      .flush('Server error', { status: 500, statusText: 'Internal Server Error' });
    await loadPromise;

    expect(store.storeError()).toBe('Failed to load accounts');
    expect(store.allAccounts()).toEqual([]);
  });
});
