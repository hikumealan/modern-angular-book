// See ch03-reactive-signals.md -- "Working with RxJS"
import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import {
  catchError,
  debounceTime,
  distinctUntilChanged,
  filter,
  of,
  switchMap,
} from 'rxjs';
import { Account } from '@financial-app/shared/models';

/**
 * AccountTypeaheadComponent demonstrates RxJS + signal interop:
 * a signal input is converted to an observable, debounced, filtered,
 * and fed through switchMap to cancel stale HTTP requests, then the
 * result is converted back to a signal for template binding.
 */
@Component({
  selector: 'app-account-typeahead',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './account-typeahead.component.html',
  styleUrl: './account-typeahead.component.scss',
})
export class AccountTypeaheadComponent {
  private readonly http = inject(HttpClient);

  readonly query = signal('');

  private readonly results$ = toObservable(this.query).pipe(
    debounceTime(250),
    distinctUntilChanged(),
    filter((term) => term.length >= 2),
    switchMap((term) =>
      this.http
        .get<Account[]>(`/api/accounts?q=${encodeURIComponent(term)}`)
        .pipe(catchError(() => of<Account[]>([]))),
    ),
  );

  readonly results = toSignal(this.results$, { initialValue: [] as Account[] });
}
