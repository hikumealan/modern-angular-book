// See ch02-signal-components.md -- "Building Feature Components with Signals"
// See ch06-http.md -- "Loading Data with httpResource"
// See ch32-performance.md -- "NgOptimizedImage"
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgOptimizedImage } from '@angular/common';
// httpResource is experimental in Angular v21 -- API may change in future releases
import { httpResource } from '@angular/common/http';

import { Account } from '@financial-app/shared/models';
import { AccountCardComponent } from '@financial-app/shared/ui';

@Component({
  selector: 'app-account-search',
  standalone: true,
  imports: [FormsModule, NgOptimizedImage, AccountCardComponent],
  templateUrl: './account-search.component.html',
  styleUrl: './account-search.component.scss',
})
export class AccountSearchComponent {
  searchTerm = signal('');

  // httpResource ties the HTTP call lifecycle to signals automatically
  accountsResource = httpResource<Account[]>({
    url: '/api/accounts',
  });

  filteredAccounts = computed(() => {
    const accounts = this.accountsResource.value() ?? [];
    const term = this.searchTerm().toLowerCase().trim();

    if (!term) {
      return accounts;
    }

    return accounts.filter(
      (account) =>
        account.name.toLowerCase().includes(term) ||
        account.type.toLowerCase().includes(term),
    );
  });
}
