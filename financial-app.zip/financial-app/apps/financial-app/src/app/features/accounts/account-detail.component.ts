// See ch02-signal-components.md -- "Signal-Based Inputs from the Router"
// See ch06-http.md -- "Loading Data with httpResource"
import { Component, input } from '@angular/core';
import { CurrencyPipe, DatePipe } from '@angular/common';
// httpResource is experimental in Angular v21 -- API may change in future releases
import { httpResource } from '@angular/common/http';

import { Account, Transaction } from '@financial-app/shared/models';

@Component({
  selector: 'app-account-detail',
  standalone: true,
  imports: [CurrencyPipe, DatePipe],
  templateUrl: './account-detail.component.html',
  styleUrl: './account-detail.component.scss',
})
export class AccountDetailComponent {
  /** Bound from route param :id via withComponentInputBinding() */
  id = input.required<string>();

  accountResource = httpResource<Account>({
    url: () => `/api/accounts/${this.id()}`,
  });

  transactionsResource = httpResource<Transaction[]>({
    url: () => `/api/accounts/${this.id()}/transactions`,
  });
}
