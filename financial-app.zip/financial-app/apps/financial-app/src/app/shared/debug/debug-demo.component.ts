// See ch49-debugging.md -- dev-only debug surface: signal-graph tracing and breakpoint drill.
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  isDevMode,
  signal,
} from '@angular/core';

@Component({
  selector: 'app-debug-demo',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './debug-demo.component.html',
})
export class DebugDemoComponent {
  readonly devMode = isDevMode();

  readonly count = signal(0);
  readonly doubled = computed(() => this.count() * 2);

  constructor() {
    if (!this.devMode) return;

    effect(() => {
      const c = this.count();
      const d = this.doubled();
      // eslint-disable-next-line no-console
      console.debug('[debug-demo] signal graph', { count: c, doubled: d });
    });
  }

  increment(): void {
    this.count.update((n) => n + 1);
  }

  triggerBreakpoint(): void {
    if (!this.devMode) return;
    const snapshot = { count: this.count(), doubled: this.doubled() };
    // eslint-disable-next-line no-console
    console.debug('[debug-demo] breakpoint snapshot', snapshot);
    // eslint-disable-next-line no-debugger
    debugger;
  }
}
