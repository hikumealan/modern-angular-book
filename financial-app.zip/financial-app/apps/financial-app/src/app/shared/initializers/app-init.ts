// See ch12-initialization-routes.md -- "APP_INITIALIZER"
import { inject, EnvironmentProviders, makeEnvironmentProviders, provideAppInitializer } from '@angular/core';
import { AccountService } from '@financial-app/shared/data-access';

function initializeApp(): Promise<void> {
  const accountService = inject(AccountService);
  return Promise.resolve();
}

export function provideAppInit(): EnvironmentProviders {
  return makeEnvironmentProviders([provideAppInitializer(initializeApp)]);
}
