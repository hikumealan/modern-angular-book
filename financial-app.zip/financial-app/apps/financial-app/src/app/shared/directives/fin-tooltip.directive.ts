// See ch11-directives-templates.md -- "Host Bindings & Element Access"
import { computed, Directive, signal } from '@angular/core';

@Directive({
  selector: '[appFinTooltip]',
  standalone: true,
  exportAs: 'finTooltip',
  host: {
    '(mouseenter)': 'show()',
    '(mouseleave)': 'hide()',
    '(focus)': 'show()',
    '(blur)': 'hide()',
  },
})
export class FinTooltipDirective {
  private readonly visibleSignal = signal(false);

  readonly visible = this.visibleSignal.asReadonly();
  readonly invisible = computed(() => !this.visibleSignal());

  show(): void {
    this.visibleSignal.set(true);
  }

  hide(): void {
    this.visibleSignal.set(false);
  }

  toggle(): void {
    this.visibleSignal.update((current) => !current);
  }
}
