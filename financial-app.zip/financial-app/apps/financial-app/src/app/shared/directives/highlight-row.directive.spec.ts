// See ch12-directives-templates.md -- "Host Bindings & Element Access"
import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { describe, it, expect, beforeEach } from 'vitest';
import { HighlightRowDirective } from './highlight-row.directive';

@Component({
  selector: 'app-highlight-host',
  standalone: true,
  imports: [HighlightRowDirective],
  template: `
    <div
      appHighlightRow
      #row="finHighlight"
      [interactive]="interactive">
      row content
    </div>
  `,
})
class HighlightHostComponent {
  interactive = true;
}

describe('HighlightRowDirective', () => {
  let fixture: ComponentFixture<HighlightHostComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HighlightHostComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(HighlightHostComponent);
    fixture.detectChanges();
  });

  it('adds is-active class and aria-selected on hover', () => {
    const row: HTMLElement = fixture.nativeElement.querySelector('.highlight-row');

    expect(row.classList.contains('is-active')).toBe(false);
    expect(row.getAttribute('aria-selected')).toBe('false');

    row.dispatchEvent(new MouseEvent('mouseenter'));
    fixture.detectChanges();

    expect(row.classList.contains('is-active')).toBe(true);
    expect(row.getAttribute('aria-selected')).toBe('true');

    row.dispatchEvent(new MouseEvent('mouseleave'));
    fixture.detectChanges();

    expect(row.classList.contains('is-active')).toBe(false);
  });

  it('sets role="button" when interactive', () => {
    const row: HTMLElement = fixture.nativeElement.querySelector('.highlight-row');
    expect(row.getAttribute('role')).toBe('button');
  });

  it('omits role when not interactive', () => {
    fixture.componentInstance.interactive = false;
    fixture.detectChanges();

    const row: HTMLElement = fixture.nativeElement.querySelector('.highlight-row');
    expect(row.getAttribute('role')).toBeNull();
  });

  it('reacts to keyboard focus and blur', () => {
    const row: HTMLElement = fixture.nativeElement.querySelector('.highlight-row');

    row.dispatchEvent(new FocusEvent('focus'));
    fixture.detectChanges();
    expect(row.classList.contains('is-active')).toBe(true);

    row.dispatchEvent(new FocusEvent('blur'));
    fixture.detectChanges();
    expect(row.classList.contains('is-active')).toBe(false);
  });
});
