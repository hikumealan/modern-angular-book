// See ch12-directives-templates.md -- "Host Bindings & Element Access"
import { Directive, input, signal } from '@angular/core';

@Directive({
  selector: '[appHighlightRow]',
  standalone: true,
  exportAs: 'finHighlight',
  host: {
    class: 'highlight-row',
    tabindex: '0',
    '[attr.role]': 'interactive() ? "button" : null',
    '[attr.aria-selected]': 'active()',
    '[class.is-active]': 'active()',
    '(mouseenter)': 'setActive(true)',
    '(mouseleave)': 'setActive(false)',
    '(focus)': 'setActive(true)',
    '(blur)': 'setActive(false)',
  },
})
export class HighlightRowDirective {
  interactive = input<boolean>(true);

  private readonly activeSignal = signal(false);
  readonly active = this.activeSignal.asReadonly();

  setActive(value: boolean): void {
    this.activeSignal.set(value);
  }
}
