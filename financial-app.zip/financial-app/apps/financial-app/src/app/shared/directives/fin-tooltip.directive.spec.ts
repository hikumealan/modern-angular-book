// See ch12-directives-templates.md -- "Host Bindings & Element Access"
import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { describe, it, expect, beforeEach } from 'vitest';
import { FinTooltipDirective } from './fin-tooltip.directive';

@Component({
  selector: 'app-tooltip-host',
  standalone: true,
  imports: [FinTooltipDirective],
  template: `
    <button
      appFinTooltip
      #tip="finTooltip"
      type="button"
      aria-describedby="help">
      help
    </button>
    @if (tip.visible()) {
      <span id="help" role="tooltip">Tooltip text</span>
    }
  `,
})
class TooltipHostComponent {}

describe('FinTooltipDirective', () => {
  let fixture: ComponentFixture<TooltipHostComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TooltipHostComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(TooltipHostComponent);
    fixture.detectChanges();
  });

  it('is hidden by default', () => {
    const tooltip = fixture.nativeElement.querySelector('[role="tooltip"]');
    expect(tooltip).toBeNull();
  });

  it('shows on mouseenter and hides on mouseleave', () => {
    const button: HTMLButtonElement = fixture.nativeElement.querySelector('button');

    button.dispatchEvent(new MouseEvent('mouseenter'));
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('[role="tooltip"]')).not.toBeNull();

    button.dispatchEvent(new MouseEvent('mouseleave'));
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('[role="tooltip"]')).toBeNull();
  });

  it('shows on focus and hides on blur for keyboard users', () => {
    const button: HTMLButtonElement = fixture.nativeElement.querySelector('button');

    button.dispatchEvent(new FocusEvent('focus'));
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('[role="tooltip"]')).not.toBeNull();

    button.dispatchEvent(new FocusEvent('blur'));
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('[role="tooltip"]')).toBeNull();
  });
});
