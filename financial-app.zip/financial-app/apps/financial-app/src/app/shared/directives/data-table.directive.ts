// See ch12-directives-templates.md -- "Structural Directives"
import {
  Directive,
  inject,
  input,
  effect,
  TemplateRef,
  ViewContainerRef,
} from '@angular/core';

export interface DataTableContext<T> {
  $implicit: T;
  index: number;
}

@Directive({
  selector: '[appDataTable]',
  standalone: true,
})
export class DataTableDirective<T> {
  appDataTableOf = input.required<T[]>();

  private readonly templateRef =
    inject<TemplateRef<DataTableContext<T>>>(TemplateRef);
  private readonly viewContainer = inject(ViewContainerRef);

  constructor() {
    effect(() => {
      const items = this.appDataTableOf();
      this.viewContainer.clear();

      items.forEach((item, index) => {
        this.viewContainer.createEmbeddedView(this.templateRef, {
          $implicit: item,
          index,
        });
      });
    });
  }

  static ngTemplateContextGuard<T>(
    _dir: DataTableDirective<T>,
    ctx: unknown,
  ): ctx is DataTableContext<T> {
    return true;
  }
}
