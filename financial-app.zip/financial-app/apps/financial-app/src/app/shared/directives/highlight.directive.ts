// See ch11-directives-templates.md -- "Attribute Directives"
import {
  Directive,
  ElementRef,
  inject,
  input,
  Renderer2,
} from '@angular/core';

@Directive({
  selector: '[appHighlight]',
  standalone: true,
  host: {
    '(mouseenter)': 'onMouseEnter()',
    '(mouseleave)': 'onMouseLeave()',
  },
})
export class HighlightDirective {
  highlightColor = input<string>('rgba(26, 115, 232, 0.12)', {
    alias: 'appHighlight',
  });

  private readonly el = inject(ElementRef);
  private readonly renderer = inject(Renderer2);
  private originalBackground: string | null = null;

  onMouseEnter(): void {
    this.originalBackground = this.el.nativeElement.style.backgroundColor;
    this.renderer.setStyle(
      this.el.nativeElement,
      'backgroundColor',
      this.highlightColor(),
    );
  }

  onMouseLeave(): void {
    this.renderer.setStyle(
      this.el.nativeElement,
      'backgroundColor',
      this.originalBackground,
    );
  }
}
