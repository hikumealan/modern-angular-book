// See ch13-initialization-routes.md -- "Resolver"
import { inject } from '@angular/core';
import { ResolveFn } from '@angular/router';

import { Account } from '@financial-app/shared/models';
import { AccountService } from '@financial-app/shared/data-access';

export const accountResolver: ResolveFn<Account> = (route) => {
  const accountService = inject(AccountService);
  const id = Number(route.paramMap.get('id'));

  return accountService.loadAccount(id);
};
