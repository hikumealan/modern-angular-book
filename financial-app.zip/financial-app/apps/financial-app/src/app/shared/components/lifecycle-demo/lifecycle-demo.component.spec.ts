// See ch11-directives-templates.md -- "Component & Directive Lifecycle"
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { describe, it, expect, beforeEach } from 'vitest';
import { LifecycleDemoComponent } from './lifecycle-demo.component';

describe('LifecycleDemoComponent', () => {
  let fixture: ComponentFixture<LifecycleDemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LifecycleDemoComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(LifecycleDemoComponent);
    fixture.componentRef.setInput('label', 'primary');
  });

  it('captures constructor, ngOnInit, and the first effect run', () => {
    fixture.detectChanges();

    const log = fixture.componentInstance.log();
    expect(log[0]).toBe('constructor');
    expect(log).toContain('effect: label=primary');
    expect(log).toContain('ngOnInit');
  });

  it('re-runs the effect when the input changes', () => {
    fixture.detectChanges();
    fixture.componentRef.setInput('label', 'secondary');
    fixture.detectChanges();

    const log = fixture.componentInstance.log();
    expect(log.filter((entry) => entry.startsWith('effect:'))).toEqual([
      'effect: label=primary',
      'effect: label=secondary',
    ]);
  });

  it('clears the log when clear() is called', () => {
    fixture.detectChanges();
    expect(fixture.componentInstance.log().length).toBeGreaterThan(0);

    fixture.componentInstance.clear();
    expect(fixture.componentInstance.log()).toEqual([]);
  });
});
