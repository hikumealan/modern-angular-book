// See ch11-directives-templates.md -- "Component & Directive Lifecycle"
import {
  afterNextRender,
  Component,
  DestroyRef,
  effect,
  inject,
  input,
  OnDestroy,
  OnInit,
  signal,
} from '@angular/core';

@Component({
  selector: 'app-lifecycle-demo',
  standalone: true,
  templateUrl: './lifecycle-demo.component.html',
  styleUrl: './lifecycle-demo.component.scss',
})
export class LifecycleDemoComponent implements OnInit, OnDestroy {
  label = input<string>('demo');

  readonly log = signal<string[]>([]);

  private readonly destroyRef = inject(DestroyRef);

  constructor() {
    this.append('constructor');

    effect(() => {
      this.append(`effect: label=${this.label()}`);
    });

    afterNextRender(() => {
      this.append('afterNextRender (DOM is ready)');
    });

    this.destroyRef.onDestroy(() => this.append('DestroyRef.onDestroy'));
  }

  ngOnInit(): void {
    this.append('ngOnInit');
  }

  ngOnDestroy(): void {
    this.append('ngOnDestroy');
  }

  clear(): void {
    this.log.set([]);
  }

  private append(entry: string): void {
    this.log.update((current) => [...current, entry]);
  }
}
