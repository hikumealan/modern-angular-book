// See ch02-signal-components.md -- "Component Styling & View Encapsulation"
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { describe, it, expect, beforeEach } from 'vitest';
import { ThemedBadgeComponent } from './themed-badge.component';
import { ThemedBadgeShadowComponent } from './themed-badge-shadow.component';

describe('ThemedBadgeComponent (Emulated)', () => {
  let fixture: ComponentFixture<ThemedBadgeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ThemedBadgeComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ThemedBadgeComponent);
  });

  it('renders the label and keeps styles scoped via attribute rewriting', () => {
    fixture.componentRef.setInput('label', 'checking');
    fixture.detectChanges();

    const host: HTMLElement = fixture.nativeElement;
    expect(host.textContent?.trim()).toContain('checking');

    const badge = host.querySelector('.badge');
    expect(badge).not.toBeNull();

    // Emulated encapsulation tags children with a per-component attribute
    // like _ngcontent-*. We do not assert on the exact name because it is
    // generated, but at least one such attribute should exist.
    const badgeEl = badge as HTMLElement;
    const hasNgContentAttr = Array.from(badgeEl.attributes).some((attr) =>
      attr.name.startsWith('_ngcontent-'),
    );
    expect(hasNgContentAttr).toBe(true);
  });
});

describe('ThemedBadgeShadowComponent (ShadowDom)', () => {
  let fixture: ComponentFixture<ThemedBadgeShadowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ThemedBadgeShadowComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ThemedBadgeShadowComponent);
  });

  it('attaches a shadow root to the host and renders inside it', () => {
    fixture.componentRef.setInput('label', 'shadow');
    fixture.detectChanges();

    const host: HTMLElement = fixture.nativeElement;
    expect(host.shadowRoot).not.toBeNull();

    const badge = host.shadowRoot?.querySelector('.badge');
    expect(badge?.textContent).toContain('shadow');

    // Shadow DOM hides the internal markup from the light tree:
    expect(host.querySelector('.badge')).toBeNull();
  });
});
