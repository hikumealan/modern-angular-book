// See ch02-signal-components.md -- "Component Styling & View Encapsulation"
import { Component, input, ViewEncapsulation } from '@angular/core';

/**
 * ThemedBadgeComponent demonstrates the three ViewEncapsulation modes
 * Angular supports. The `mode` input does not change encapsulation at
 * runtime (that is decorator-bound); it only switches the visual label
 * so three instances rendered side-by-side make the comparison concrete.
 *
 * The default Emulated encapsulation is what 99% of components use.
 * The sibling ThemedBadgeShadowComponent and ThemedBadgeGlobalComponent
 * show the alternatives for comparison.
 */
@Component({
  selector: 'app-themed-badge',
  standalone: true,
  templateUrl: './themed-badge.component.html',
  styleUrl: './themed-badge.component.scss',
  // encapsulation: ViewEncapsulation.Emulated is the default; shown here
  // explicitly so the contrast with the sibling components is clear.
  encapsulation: ViewEncapsulation.Emulated,
})
export class ThemedBadgeComponent {
  label = input<string>('emulated');
}
