// See ch02-signal-components.md -- "Component Styling & View Encapsulation"
import { Component, input, ViewEncapsulation } from '@angular/core';

/**
 * Shadow-DOM-encapsulated sibling of ThemedBadgeComponent. Styles are
 * enforced by the platform: nothing can cross the shadow boundary in
 * either direction. Appropriate for embeddable widgets and micro
 * frontends (see ch38-micro-frontends.md).
 */
@Component({
  selector: 'app-themed-badge-shadow',
  standalone: true,
  template: `<span class="badge">
    <span class="badge__dot" aria-hidden="true"></span>
    {{ label() }}
  </span>`,
  styles: [
    `:host {
      display: inline-flex;
      align-items: center;
      padding: 0.25rem 0.625rem;
      border-radius: 999px;
      font-size: 0.875rem;
      font-weight: 500;
      background: #f1f3f4;
      color: #1f2937;
    }
    .badge { display: inline-flex; align-items: center; gap: 0.375rem; }
    .badge__dot {
      width: 0.5rem; height: 0.5rem; border-radius: 50%; background: currentColor;
    }`,
  ],
  encapsulation: ViewEncapsulation.ShadowDom,
})
export class ThemedBadgeShadowComponent {
  label = input<string>('shadow');
}
