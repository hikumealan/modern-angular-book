// See ch11-directives-templates.md -- "Pipes: Built-in and Custom"
import { describe, it, expect } from 'vitest';
import { MaskAccountNumberPipe } from './mask-account-number.pipe';

describe('MaskAccountNumberPipe', () => {
  const pipe = new MaskAccountNumberPipe();

  it('masks all but the last 4 digits by default', () => {
    expect(pipe.transform('1234567890')).toBe('******7890');
  });

  it('respects a custom visible-digits argument', () => {
    expect(pipe.transform('1234567890', 6)).toBe('****567890');
  });

  it('strips non-digit characters before masking', () => {
    expect(pipe.transform('12-34-5678')).toBe('**5678');
  });

  it('accepts numeric inputs', () => {
    expect(pipe.transform(1234567890)).toBe('******7890');
  });

  it('returns the digits unchanged when shorter than visible digits', () => {
    expect(pipe.transform('1234')).toBe('1234');
    expect(pipe.transform('12', 4)).toBe('12');
  });

  it('returns empty string for null or undefined', () => {
    expect(pipe.transform(null)).toBe('');
    expect(pipe.transform(undefined)).toBe('');
  });
});
