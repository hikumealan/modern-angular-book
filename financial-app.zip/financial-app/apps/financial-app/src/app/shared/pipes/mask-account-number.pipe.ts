// See ch12-directives-templates.md -- "Pipes: Built-in and Custom"
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'maskAccountNumber',
  standalone: true,
})
export class MaskAccountNumberPipe implements PipeTransform {
  transform(
    value: string | number | null | undefined,
    visibleDigits = 4,
  ): string {
    if (value == null) {
      return '';
    }

    const digits = String(value).replace(/\D/g, '');
    if (digits.length <= visibleDigits) {
      return digits;
    }

    const maskedCount = digits.length - visibleDigits;
    return '*'.repeat(maskedCount) + digits.slice(-visibleDigits);
  }
}
