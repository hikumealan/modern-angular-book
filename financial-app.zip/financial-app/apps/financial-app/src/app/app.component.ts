import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  template: `
    <header class="app-header">
      <h1>Financial App</h1>
    </header>
    <main class="app-main">
      <router-outlet />
    </main>
  `,
  styles: `
    :host {
      display: block;
      min-height: 100vh;
    }

    .app-header {
      display: flex;
      align-items: center;
      padding: var(--space-md) var(--space-xl);
      background-color: var(--color-surface);
      border-bottom: 1px solid var(--color-border);
      box-shadow: var(--shadow-sm);
    }

    .app-header h1 {
      font-size: 1.25rem;
      font-weight: 600;
      color: var(--color-primary);
    }

    .app-main {
      padding: var(--space-lg);
      max-width: 1280px;
      margin: 0 auto;
    }
  `,
})
export class AppComponent {
  title = 'financial-app';
}
