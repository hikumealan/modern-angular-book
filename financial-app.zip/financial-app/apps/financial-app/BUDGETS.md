# Bundle budgets

<!-- See ch32-performance.md -->

Strict JSON has no comment syntax, so the chapter pointer for the
budgets block in `project.json` lives here. Any change to the budgets
inside `build.configurations.production` should cross-reference
[ch32-performance.md](../../../ch32-performance.md) so the companion
code and the chapter narrative stay in lockstep.

Current values (already present in `project.json`):

| Budget type          | Warning | Error |
| -------------------- | ------- | ----- |
| `initial`            | 500 kB  | 1 MB  |
| `anyComponentStyle`  | 4 kB    | 8 kB  |

The `initial` thresholds match the v21 defaults called out in
ch32. The `anyComponentStyle` thresholds are stricter than the
example in the chapter (6 kB / 10 kB) -- stricter is fine, and
tightening an existing budget is preferred over relaxing one, so
the existing values stand.
