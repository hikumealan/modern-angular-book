// Ch 27 – FinIcon wrapper for Material Symbols
import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';

@Component({
  selector: 'fin-icon',
  standalone: true,
  template: `<span
    class="material-symbols-outlined {{ sizeClass() }}"
    [attr.aria-hidden]="label() ? null : true"
    [attr.aria-label]="label() || null"
    [attr.role]="label() ? 'img' : null"
  >{{ name() }}</span>`,
  styles: `
    :host { display: inline-flex; align-items: center; justify-content: center; }
    .sz-sm { font-size: 18px; }
    .sz-md { font-size: 24px; }
    .sz-lg { font-size: 36px; }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FinIconComponent {
  readonly name = input.required<string>();
  readonly size = input<'sm' | 'md' | 'lg'>('md');
  readonly label = input<string | undefined>(undefined);

  protected readonly sizeClass = computed(() => `sz-${this.size()}`);
}
