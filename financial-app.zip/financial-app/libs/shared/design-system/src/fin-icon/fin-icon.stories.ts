// See ch26-storybook.md
import type { Meta, StoryObj } from '@storybook/angular';
import { FinIconComponent } from './fin-icon.component';

const meta: Meta<FinIconComponent> = {
  title: 'Design System/FinIcon',
  component: FinIconComponent,
  tags: ['autodocs'],
  argTypes: {
    size: {
      control: { type: 'radio' },
      options: ['sm', 'md', 'lg'],
    },
  },
};
export default meta;
type Story = StoryObj<FinIconComponent>;

export const Default: Story = {
  args: {
    name: 'account_balance',
    size: 'md',
  },
};

export const SmallWithLabel: Story = {
  args: {
    name: 'trending_up',
    size: 'sm',
    label: 'Portfolio gains up 4.2% this week',
  },
};

export const LargeDecorative: Story = {
  args: {
    name: 'savings',
    size: 'lg',
  },
};
