// See ch22-material-design-system.md
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  input,
} from '@angular/core';

export type FinButtonVariant = 'primary' | 'secondary' | 'danger' | 'ghost';
export type FinButtonSize = 'sm' | 'md' | 'lg';

@Component({
  selector: 'fin-button',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './fin-button.component.html',
  styleUrl: './fin-button.component.scss',
})
export class FinButtonComponent {
  readonly variant = input<FinButtonVariant>('primary');
  readonly size = input<FinButtonSize>('md');
  readonly disabled = input<boolean>(false);
  readonly loading = input<boolean>(false);

  protected readonly isDisabled = computed(
    () => this.disabled() || this.loading()
  );
}
