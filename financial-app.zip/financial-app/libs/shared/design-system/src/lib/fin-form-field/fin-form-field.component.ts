// See ch22-material-design-system.md
// See ch24-accessibility.md -- aria-describedby wiring for hint / error text.
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  afterNextRender,
  computed,
  effect,
  inject,
  input,
} from '@angular/core';

let finFormFieldUid = 0;

@Component({
  selector: 'fin-form-field',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './fin-form-field.component.html',
  styleUrl: './fin-form-field.component.scss',
})
export class FinFormFieldComponent {
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef);
  private readonly uid = `fin-ff-${++finFormFieldUid}`;

  readonly label = input<string>('');
  readonly hint = input<string>('');
  readonly errorMessage = input<string>('');

  protected readonly labelId = `${this.uid}-label`;
  protected readonly hintId = `${this.uid}-hint`;
  protected readonly errorId = `${this.uid}-error`;
  protected readonly inputId = `${this.uid}-input`;

  protected readonly hasError = computed(() => this.errorMessage().length > 0);
  protected readonly hasHint = computed(
    () => !this.hasError() && this.hint().length > 0
  );

  constructor() {
    // Projected content isn't in the DOM during constructor; wait for first render.
    afterNextRender(() => this.syncProjectedControl());
    // Re-sync whenever validity or hint text changes.
    effect(() => this.syncProjectedControl());
  }

  private syncProjectedControl(): void {
    const control = this.host.nativeElement.querySelector<HTMLElement>(
      'input, textarea, select'
    );
    if (!control) return;

    if (!control.id) {
      control.id = this.inputId;
    }

    const describedBy = this.hasError()
      ? this.errorId
      : this.hasHint()
        ? this.hintId
        : null;

    if (describedBy) {
      control.setAttribute('aria-describedby', describedBy);
    } else {
      control.removeAttribute('aria-describedby');
    }

    if (this.hasError()) {
      control.setAttribute('aria-invalid', 'true');
    } else {
      control.removeAttribute('aria-invalid');
    }
  }
}
