// See ch22-material-design-system.md
// See ch24-accessibility.md -- roving tabindex with arrow-key navigation.
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  computed,
  inject,
  input,
  signal,
} from '@angular/core';

export interface FinDataTableColumn {
  key: string;
  label: string;
}

export type FinDataTableRow = Record<string, unknown>;
export type FinDataTableTrackBy = (
  index: number,
  row: FinDataTableRow
) => unknown;

@Component({
  selector: 'fin-data-table',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './fin-data-table.component.html',
  styleUrl: './fin-data-table.component.scss',
  host: {
    '(keydown)': 'onKeydown($event)',
  },
})
export class FinDataTableComponent {
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef);

  readonly columns = input.required<readonly FinDataTableColumn[]>();
  readonly rows = input.required<readonly FinDataTableRow[]>();
  readonly trackBy = input<FinDataTableTrackBy | undefined>(undefined);

  private readonly focusedRow = signal(0);
  private readonly focusedCol = signal(0);

  protected readonly rowCount = computed(() => this.rows().length);
  protected readonly colCount = computed(() => this.columns().length);

  protected isFocused(row: number, col: number): boolean {
    return this.focusedRow() === row && this.focusedCol() === col;
  }

  protected readonly trackRow = (
    index: number,
    row: FinDataTableRow
  ): unknown => {
    const fn = this.trackBy();
    return fn ? fn(index, row) : index;
  };

  protected readonly trackCol = (
    _: number,
    col: FinDataTableColumn
  ): string => col.key;

  protected cellValue(row: FinDataTableRow, key: string): string {
    const value = row[key];
    if (value === null || value === undefined) return '';
    return String(value);
  }

  protected onCellFocus(row: number, col: number): void {
    this.focusedRow.set(row);
    this.focusedCol.set(col);
  }

  protected onKeydown(event: KeyboardEvent): void {
    const rows = this.rowCount();
    const cols = this.colCount();
    if (rows === 0 || cols === 0) return;

    let r = this.focusedRow();
    let c = this.focusedCol();

    switch (event.key) {
      case 'ArrowUp':
        r = Math.max(0, r - 1);
        break;
      case 'ArrowDown':
        r = Math.min(rows - 1, r + 1);
        break;
      case 'ArrowLeft':
        c = Math.max(0, c - 1);
        break;
      case 'ArrowRight':
        c = Math.min(cols - 1, c + 1);
        break;
      case 'Home':
        if (event.ctrlKey) {
          r = 0;
          c = 0;
        } else {
          c = 0;
        }
        break;
      case 'End':
        if (event.ctrlKey) {
          r = rows - 1;
          c = cols - 1;
        } else {
          c = cols - 1;
        }
        break;
      default:
        return;
    }

    event.preventDefault();
    this.focusedRow.set(r);
    this.focusedCol.set(c);

    const target = this.host.nativeElement.querySelector<HTMLElement>(
      `[data-row="${r}"][data-col="${c}"]`
    );
    target?.focus();
  }
}
