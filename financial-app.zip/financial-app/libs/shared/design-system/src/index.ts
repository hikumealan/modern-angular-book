// Ch 24 – Design System
// See ch22-material-design-system.md -- FinButton / FinFormField / FinDataTable wrappers.
export { ThemeService } from './theme.service';
export { FinIconComponent } from './fin-icon/fin-icon.component';
export {
  FinButtonComponent,
  type FinButtonVariant,
  type FinButtonSize,
} from './lib/fin-button/fin-button.component';
export { FinFormFieldComponent } from './lib/fin-form-field/fin-form-field.component';
export {
  FinDataTableComponent,
  type FinDataTableColumn,
  type FinDataTableRow,
  type FinDataTableTrackBy,
} from './lib/fin-data-table/fin-data-table.component';
export { fadeIn, slideIn, stagger } from './_animations';
