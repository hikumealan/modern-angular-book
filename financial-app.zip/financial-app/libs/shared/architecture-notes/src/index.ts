// See ch09-architecture.md -- vertical slicing and Sheriff domain tags.
//
// Canonical domain-tag constants for FinancialApp. Sheriff's `sheriff.config.ts`
// tags each vertical slice with one of these strings; consumers that need to
// reference a tag by name (audit scripts, documentation generators, AGENTS.md
// rendering) should import from here rather than hard-code the string.

export const DOMAIN_TAGS = {
  transactions: 'domain:transactions',
  accounts: 'domain:accounts',
  portfolios: 'domain:portfolios',
  clients: 'domain:clients',
} as const;

export type DomainTag = (typeof DOMAIN_TAGS)[keyof typeof DOMAIN_TAGS];

export const DOMAIN_NAMES = Object.keys(DOMAIN_TAGS) as (keyof typeof DOMAIN_TAGS)[];

export function isDomainTag(value: string): value is DomainTag {
  return (Object.values(DOMAIN_TAGS) as string[]).includes(value);
}
