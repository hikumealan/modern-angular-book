# shared/architecture-notes

Companion code for [Chapter 11 — Sustainable Architectures for Modern Angular](../../../../ch09-architecture.md).

This library has no runtime dependencies and no UI. It is the single source of truth for the **domain-tag strings** that FinancialApp uses to enforce vertical-slice boundaries via `@softarc/sheriff-core`. Audit tooling, documentation generators, and the workspace-level `AGENTS.md` import the constants from here so that renaming a domain is a one-line change.

## Vertical-Slice Philosophy

FinancialApp organises code by **business capability**, not by technical layer. Every feature lives inside one of four vertical slices:

| Slice | Tag | Responsibility |
|---|---|---|
| `accounts` | `domain:accounts` | Account onboarding, balances, lifecycle events |
| `transactions` | `domain:transactions` | Ledger entries, approvals, settlement |
| `portfolios` | `domain:portfolios` | Holdings, rebalancing, performance |
| `clients` | `domain:clients` | KYC, contact details, risk profile |

A slice owns its feature components, data-access services, stores, and domain model. Cross-slice imports are flagged by Sheriff unless they go through a shared library (`shared/models`, `shared/ui`, `shared/data-access`, …).

The three non-negotiables, in order of importance:

1. **High internal cohesion, low external coupling.** Code that changes together lives together; code that changes independently does not share a barrel.
2. **Explicit public API.** Each slice exposes a `src/index.ts` barrel. Anything not re-exported is considered internal and not importable from another slice.
3. **Dependencies point toward `shared/*`.** Domain slices never import from each other; when two slices genuinely need a shared concept, it is promoted into `shared/models` (or a purpose-built shared library).

See Chapter 11 for the full discussion, including event-storming for boundary discovery, the architecture matrix, and how to pick between barrel exports, Nx libraries, and Sheriff rules.

## Related

- `sheriff.config.ts` — the boundary rules themselves.
- `AGENTS.md` at the repo root — machine-readable summary for AI assistants.
- [Chapter 14 — Monorepos & Libraries](../../../../ch14-monorepos-libraries.md) — the Nx workspace that hosts these slices.
- [Chapter 31 — Style Guide & Governance](../../../../ch16-style-guide-governance.md) — how the tags are enforced in lint and CI.
