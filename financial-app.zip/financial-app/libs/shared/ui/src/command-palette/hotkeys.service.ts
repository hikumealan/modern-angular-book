// See ch50-command-palette.md -- "Global keyboard shortcuts"
import { DestroyRef, Injectable, inject } from '@angular/core';

type Handler = () => void;

@Injectable({ providedIn: 'root' })
export class HotkeysService {
  private readonly bindings = new Map<string, Handler>();
  private readonly listener = (event: KeyboardEvent): void => {
    const sequence = HotkeysService.toSequence(event);
    const handler = this.bindings.get(sequence);
    if (handler) {
      event.preventDefault();
      handler();
    }
  };

  constructor() {
    document.addEventListener('keydown', this.listener);
    inject(DestroyRef).onDestroy(() => {
      document.removeEventListener('keydown', this.listener);
      this.bindings.clear();
    });
  }

  register(sequence: string, handler: Handler): void {
    this.bindings.set(sequence.toLowerCase(), handler);
  }

  unregister(sequence: string): void {
    this.bindings.delete(sequence.toLowerCase());
  }

  private static toSequence(event: KeyboardEvent): string {
    // Normalized form like "meta+k" or "ctrl+shift+p".
    const parts: string[] = [];
    if (event.metaKey) parts.push('meta');
    if (event.ctrlKey) parts.push('ctrl');
    if (event.altKey) parts.push('alt');
    if (event.shiftKey) parts.push('shift');
    parts.push(event.key.toLowerCase());
    return parts.join('+');
  }
}
