// See ch50-command-palette.md -- "A global command registry"
import { Injectable, signal, type Signal } from '@angular/core';

export interface Command {
  id: string;
  title: string;
  category: string;
  keywords: string[];
  handler: () => void;
}

@Injectable({ providedIn: 'root' })
export class CommandRegistryService {
  private readonly registry = signal<Command[]>([]);

  readonly commands: Signal<Command[]> = this.registry.asReadonly();

  register(cmd: Command): void {
    this.registry.update((current) => {
      const existing = current.findIndex((c) => c.id === cmd.id);
      if (existing >= 0) {
        const next = current.slice();
        next[existing] = cmd;
        return next;
      }
      return [...current, cmd];
    });
  }
}
