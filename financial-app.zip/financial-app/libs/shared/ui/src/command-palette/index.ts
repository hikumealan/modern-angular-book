// See ch46-command-palette.md
export { FinCommandPaletteComponent } from './fin-command-palette.component';
export {
  CommandRegistryService,
  type Command,
} from './command-registry.service';
export { HotkeysService } from './hotkeys.service';
