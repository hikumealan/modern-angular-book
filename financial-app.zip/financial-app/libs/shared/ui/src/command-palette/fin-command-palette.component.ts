// See ch46-command-palette.md -- "A signal-driven command palette"
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import { CommandRegistryService, type Command } from './command-registry.service';

@Component({
  selector: 'fin-command-palette',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '(document:keydown.meta.k)': 'toggle($event)',
    '(document:keydown.control.k)': 'toggle($event)',
    '(document:keydown.escape)': 'close()',
  },
  template: `
    @if (open()) {
      <div
        class="fin-cp__backdrop"
        role="dialog"
        aria-modal="true"
        aria-label="Command palette"
        (click)="close()"
      >
        <div class="fin-cp__panel" (click)="$event.stopPropagation()">
          <input
            class="fin-cp__input"
            type="search"
            placeholder="Type a command..."
            aria-label="Command search"
            [value]="query()"
            (input)="query.set($any($event.target).value)"
            autofocus
          />
          <ul class="fin-cp__list" role="listbox">
            @for (cmd of results(); track cmd.id) {
              <li class="fin-cp__item" role="option">
                <button type="button" (click)="run(cmd)">
                  <span class="fin-cp__title">{{ cmd.title }}</span>
                  <span class="fin-cp__category">{{ cmd.category }}</span>
                </button>
              </li>
            } @empty {
              <li class="fin-cp__empty">No matches</li>
            }
          </ul>
        </div>
      </div>
    }
  `,
})
export class FinCommandPaletteComponent {
  private readonly registry = inject(CommandRegistryService);

  protected readonly open = signal(false);
  protected readonly query = signal('');

  protected readonly results = computed(() => {
    const q = this.query().trim().toLowerCase();
    const all = this.registry.commands();
    if (!q) {
      return all;
    }
    return all.filter((cmd) => this.matches(cmd, q));
  });

  toggle(event?: Event): void {
    event?.preventDefault();
    this.open.update((v) => !v);
    if (!this.open()) {
      this.query.set('');
    }
  }

  close(): void {
    this.open.set(false);
    this.query.set('');
  }

  run(cmd: Command): void {
    this.close();
    cmd.handler();
  }

  private matches(cmd: Command, q: string): boolean {
    if (cmd.title.toLowerCase().includes(q)) return true;
    if (cmd.category.toLowerCase().includes(q)) return true;
    return cmd.keywords.some((k) => k.toLowerCase().includes(q));
  }
}
