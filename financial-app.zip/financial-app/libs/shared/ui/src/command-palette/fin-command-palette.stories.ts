// See ch26-storybook.md
import type { Meta, StoryObj } from '@storybook/angular';
import { applicationConfig, moduleMetadata } from '@storybook/angular';
import { FinCommandPaletteComponent } from './fin-command-palette.component';
import { CommandRegistryService } from './command-registry.service';

function seededRegistry(): CommandRegistryService {
  const registry = new CommandRegistryService();
  registry.register({
    id: 'transaction.new',
    title: 'New Transaction',
    category: 'Transactions',
    keywords: ['add', 'create', 'expense'],
    handler: () => console.log('open new transaction dialog'),
  });
  registry.register({
    id: 'account.open',
    title: 'Open Account',
    category: 'Accounts',
    keywords: ['create', 'onboard'],
    handler: () => console.log('open onboarding wizard'),
  });
  registry.register({
    id: 'portfolio.rebalance',
    title: 'Rebalance Portfolio',
    category: 'Portfolios',
    keywords: ['trade', 'rebalance', 'allocations'],
    handler: () => console.log('rebalance portfolio'),
  });
  registry.register({
    id: 'client.find',
    title: 'Find Client',
    category: 'Clients',
    keywords: ['search', 'lookup', 'client'],
    handler: () => console.log('open client search'),
  });
  return registry;
}

const meta: Meta<FinCommandPaletteComponent> = {
  title: 'UI/CommandPalette',
  component: FinCommandPaletteComponent,
  tags: ['autodocs'],
  decorators: [
    moduleMetadata({
      imports: [FinCommandPaletteComponent],
    }),
  ],
  render: () => ({
    template: `
      <div style="min-height: 240px; padding: 16px; font-family: system-ui, sans-serif;">
        <button type="button" (click)="palette.toggle()">
          Open palette (or press Cmd/Ctrl+K)
        </button>
        <p style="margin-top: 8px; color: #64748b;">
          Press Escape or click the backdrop to dismiss.
        </p>
        <fin-command-palette #palette></fin-command-palette>
      </div>
    `,
  }),
};
export default meta;
type Story = StoryObj<FinCommandPaletteComponent>;

export const Default: Story = {
  name: 'Empty registry',
};

export const WithRegisteredCommands: Story = {
  decorators: [
    applicationConfig({
      providers: [
        { provide: CommandRegistryService, useFactory: seededRegistry },
      ],
    }),
  ],
};
