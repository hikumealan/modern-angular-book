// See ch26-storybook.md
import type { Meta, StoryObj } from '@storybook/angular';
import type { Transaction } from '@financial-app/shared/models';
import { TransactionCardComponent } from './transaction-card.component';

const postedDebit: Transaction = {
  id: 4521,
  accountId: 101,
  amount: 42.87,
  type: 'debit',
  category: 'Dining',
  date: '2026-03-14T12:31:00Z',
  description: 'Blue Bottle Coffee',
  pending: false,
};

const meta: Meta<TransactionCardComponent> = {
  title: 'UI/TransactionCard',
  component: TransactionCardComponent,
  tags: ['autodocs'],
  args: {
    transaction: postedDebit,
  },
};
export default meta;
type Story = StoryObj<TransactionCardComponent>;

export const Default: Story = {};

export const CreditDeposit: Story = {
  args: {
    transaction: {
      id: 4522,
      accountId: 101,
      amount: 5200,
      type: 'credit',
      category: 'Payroll',
      date: '2026-03-15T09:00:00Z',
      description: 'Acme Corp Salary Deposit',
      pending: false,
    },
  },
};

export const PendingDebit: Story = {
  args: {
    transaction: {
      id: 4523,
      accountId: 101,
      amount: 128.45,
      type: 'debit',
      category: 'Groceries',
      date: '2026-03-16T18:02:00Z',
      description: 'Whole Foods Market',
      pending: true,
    },
  },
};
