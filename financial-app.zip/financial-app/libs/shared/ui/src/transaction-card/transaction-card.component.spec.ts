// See ch02-signal-components.md -- "Sub Components with Properties and Events"
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { describe, it, expect, vi } from 'vitest';
import { TransactionCardComponent } from './transaction-card.component';
import { Transaction } from '@financial-app/shared/models';

const mockCreditTransaction: Transaction = {
  id: 1,
  accountId: 100,
  amount: 250.0,
  type: 'credit',
  category: 'Salary',
  date: '2025-03-15',
  description: 'Monthly paycheck',
  pending: false,
};

const mockDebitTransaction: Transaction = {
  id: 2,
  accountId: 100,
  amount: 42.99,
  type: 'debit',
  category: 'Groceries',
  date: '2025-03-16',
  description: 'Supermarket purchase',
  pending: true,
};

describe('TransactionCardComponent', () => {
  let component: TransactionCardComponent;
  let fixture: ComponentFixture<TransactionCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TransactionCardComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(TransactionCardComponent);
    component = fixture.componentInstance;
  });

  it('should render credit transaction with positive amount', () => {
    fixture.componentRef.setInput('transaction', mockCreditTransaction);
    fixture.detectChanges();

    const el: HTMLElement = fixture.nativeElement;
    const card = el.querySelector('.transaction-card')!;

    expect(card.classList).toContain('transaction-card--credit');
    expect(el.querySelector('.transaction-card__description')!.textContent).toContain(
      'Monthly paycheck',
    );
    expect(el.querySelector('.transaction-card__amount')!.textContent).toContain('250');
  });

  it('should render debit transaction with pending badge', () => {
    fixture.componentRef.setInput('transaction', mockDebitTransaction);
    fixture.detectChanges();

    const el: HTMLElement = fixture.nativeElement;
    const card = el.querySelector('.transaction-card')!;

    expect(card.classList).toContain('transaction-card--debit');
    expect(el.querySelector('.transaction-card__badge--pending')).toBeTruthy();
    expect(el.querySelector('.transaction-card__badge--pending')!.textContent).toContain(
      'Pending',
    );
  });

  it('should not show pending badge for non-pending transactions', () => {
    fixture.componentRef.setInput('transaction', mockCreditTransaction);
    fixture.detectChanges();

    const el: HTMLElement = fixture.nativeElement;
    expect(el.querySelector('.transaction-card__badge--pending')).toBeNull();
  });

  it('should emit selected event on card click', () => {
    fixture.componentRef.setInput('transaction', mockCreditTransaction);
    fixture.detectChanges();

    const spy = vi.fn();
    component.selected.subscribe(spy);

    const card = fixture.nativeElement.querySelector('.transaction-card')!;
    card.click();

    expect(spy).toHaveBeenCalledWith(mockCreditTransaction);
  });

  it('should emit deleted event when onDelete is called', () => {
    fixture.componentRef.setInput('transaction', mockDebitTransaction);
    fixture.detectChanges();

    const spy = vi.fn();
    component.deleted.subscribe(spy);

    component.onDelete();

    expect(spy).toHaveBeenCalledWith(mockDebitTransaction);
  });
});
