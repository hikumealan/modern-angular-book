// See ch02-signal-components.md -- "Sub Components with Properties and Events"
import { Component, input, output } from '@angular/core';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { Transaction } from '@financial-app/shared/models';

@Component({
  selector: 'fin-transaction-card',
  standalone: true,
  imports: [CurrencyPipe, DatePipe],
  templateUrl: './transaction-card.component.html',
  styleUrl: './transaction-card.component.scss',
})
export class TransactionCardComponent {
  transaction = input.required<Transaction>();

  selected = output<Transaction>();
  deleted = output<Transaction>();

  onSelect(): void {
    this.selected.emit(this.transaction());
  }

  onDelete(): void {
    this.deleted.emit(this.transaction());
  }
}
