// See ch08-rxjs-deep-dive.md
// Cross-reference: ch56-appendix-c-reactive-forms.md
// Thin Reactive Forms example illustrating `outputFromObservable` /
// `outputToObservable` interop. Kept minimal -- full `fin-wizard` patterns
// live in `libs/shared/ui/wizard/`.
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { outputFromObservable } from '@angular/core/rxjs-interop';
import { Subject } from 'rxjs';

import type { Transaction } from '@financial-app/shared/models';

@Component({
  selector: 'fin-transaction-form',
  standalone: true,
  imports: [ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <form [formGroup]="form" (ngSubmit)="onSubmit()">
      <label>
        Amount
        <input type="number" formControlName="amount" />
      </label>
      <label>
        Description
        <input type="text" formControlName="description" />
      </label>
      <button type="submit" [disabled]="form.invalid">Save</button>
    </form>
  `,
})
export class TransactionFormComponent {
  private readonly fb = inject(FormBuilder);
  private readonly saves$ = new Subject<Partial<Transaction>>();

  readonly saved = outputFromObservable(this.saves$);

  readonly form = this.fb.nonNullable.group({
    amount: [0, [Validators.required, Validators.min(0.01)]],
    description: ['', [Validators.maxLength(500)]],
  });

  onSubmit(): void {
    if (this.form.invalid) return;
    this.saves$.next({ ...this.form.getRawValue() });
  }
}
