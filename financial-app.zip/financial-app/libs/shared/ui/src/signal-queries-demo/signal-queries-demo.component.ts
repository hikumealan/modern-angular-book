// See ch11-signal-queries.md -- viewChild, contentChild, and viewChildren.
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  computed,
  contentChild,
  input,
  viewChild,
  viewChildren,
} from '@angular/core';

@Component({
  selector: 'fin-signal-query-item',
  standalone: true,
  template: '<li class="sq-item">{{ label() }}</li>',
})
export class SignalQueryItemComponent {
  readonly label = input.required<string>();
}

@Component({
  selector: 'fin-signal-queries-demo',
  standalone: true,
  imports: [SignalQueryItemComponent],
  templateUrl: './signal-queries-demo.component.html',
  styleUrl: './signal-queries-demo.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SignalQueriesDemoComponent {
  readonly items = input<readonly string[]>([
    'accounts',
    'transactions',
    'portfolios',
    'clients',
  ]);

  protected readonly heading = viewChild.required<ElementRef<HTMLHeadingElement>>('heading');
  protected readonly renderedItems = viewChildren(SignalQueryItemComponent);
  protected readonly featured = contentChild(SignalQueryItemComponent);

  protected readonly summary = computed(() => ({
    headingText: this.heading().nativeElement.textContent?.trim() ?? '',
    viewCount: this.renderedItems().length,
    featuredLabel: this.featured()?.label() ?? null,
  }));
}
