// See ch02-signal-components.md -- "Sub Components with Properties and Events"
import { Component, input, output } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { Account } from '@financial-app/shared/models';

@Component({
  selector: 'fin-account-card',
  standalone: true,
  imports: [CurrencyPipe],
  templateUrl: './account-card.component.html',
  styleUrl: './account-card.component.scss',
})
export class AccountCardComponent {
  account = input.required<Account>();

  selected = output<Account>();

  onSelect(): void {
    this.selected.emit(this.account());
  }
}
