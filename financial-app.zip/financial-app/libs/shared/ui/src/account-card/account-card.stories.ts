// See ch26-storybook.md
import type { Meta, StoryObj } from '@storybook/angular';
import type { Account } from '@financial-app/shared/models';
import { AccountCardComponent } from './account-card.component';

const checking: Account = {
  id: 101,
  name: 'Everyday Checking',
  type: 'checking',
  balance: 4238.19,
  currency: 'USD',
  ownerId: 7,
};

const meta: Meta<AccountCardComponent> = {
  title: 'UI/AccountCard',
  component: AccountCardComponent,
  tags: ['autodocs'],
  args: {
    account: checking,
  },
};
export default meta;
type Story = StoryObj<AccountCardComponent>;

export const Default: Story = {};

export const HighYieldSavings: Story = {
  args: {
    account: {
      id: 102,
      name: 'High-Yield Savings',
      type: 'savings',
      balance: 28450.55,
      currency: 'USD',
      ownerId: 7,
    },
  },
};

export const InvestmentAccount: Story = {
  args: {
    account: {
      id: 103,
      name: 'Vanguard Brokerage',
      type: 'investment',
      balance: 184320.08,
      currency: 'USD',
      ownerId: 7,
    },
  },
};
