// See ch02-signal-components.md -- "Sub Components with Properties and Events"
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { describe, it, expect, vi } from 'vitest';
import { AccountCardComponent } from './account-card.component';
import { Account } from '@financial-app/shared/models';

const mockAccount: Account = {
  id: 1,
  name: 'Primary Checking',
  type: 'checking',
  balance: 5432.1,
  currency: 'USD',
  ownerId: 10,
};

const mockSavingsAccount: Account = {
  id: 2,
  name: 'Emergency Fund',
  type: 'savings',
  balance: 15000.0,
  currency: 'USD',
  ownerId: 10,
};

describe('AccountCardComponent', () => {
  let component: AccountCardComponent;
  let fixture: ComponentFixture<AccountCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AccountCardComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AccountCardComponent);
    component = fixture.componentInstance;
  });

  it('should render account name and balance', () => {
    fixture.componentRef.setInput('account', mockAccount);
    fixture.detectChanges();

    const el: HTMLElement = fixture.nativeElement;

    expect(el.querySelector('.account-card__name')!.textContent).toContain('Primary Checking');
    expect(el.querySelector('.account-card__balance')!.textContent).toContain('5,432.10');
  });

  it('should display the correct type badge', () => {
    fixture.componentRef.setInput('account', mockAccount);
    fixture.detectChanges();

    const badge = fixture.nativeElement.querySelector('.account-card__badge');
    expect(badge.classList).toContain('account-card__badge--checking');
    expect(badge.textContent).toContain('checking');
  });

  it('should apply savings badge for savings account', () => {
    fixture.componentRef.setInput('account', mockSavingsAccount);
    fixture.detectChanges();

    const badge = fixture.nativeElement.querySelector('.account-card__badge');
    expect(badge.classList).toContain('account-card__badge--savings');
  });

  it('should emit selected event on card click', () => {
    fixture.componentRef.setInput('account', mockAccount);
    fixture.detectChanges();

    const spy = vi.fn();
    component.selected.subscribe(spy);

    const card = fixture.nativeElement.querySelector('.account-card')!;
    card.click();

    expect(spy).toHaveBeenCalledWith(mockAccount);
  });
});
