// See ch45-wizards.md -- "Declarative step projection"
import {
  ChangeDetectionStrategy,
  Component,
  input,
  TemplateRef,
  viewChild,
} from '@angular/core';

@Component({
  selector: 'fin-wizard-step',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <ng-template>
      <ng-content />
    </ng-template>
  `,
})
export class FinWizardStepComponent {
  readonly title = input.required<string>();
  readonly valid = input<boolean>(true);

  readonly content = viewChild.required(TemplateRef);
}
