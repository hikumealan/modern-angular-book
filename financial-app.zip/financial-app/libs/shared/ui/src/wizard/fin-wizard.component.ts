// See ch45-multi-step-forms.md -- "A signal-powered wizard"
import { NgTemplateOutlet } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  contentChildren,
  signal,
} from '@angular/core';
import { FinWizardStepComponent } from './fin-wizard-step.component';

@Component({
  selector: 'fin-wizard',
  standalone: true,
  imports: [NgTemplateOutlet],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="fin-wizard">
      <ol class="fin-wizard__progress" aria-label="Wizard progress">
        @for (step of steps(); track $index) {
          <li
            class="fin-wizard__progress-item"
            [class.fin-wizard__progress-item--active]="$index === activeIndex()"
            [class.fin-wizard__progress-item--complete]="$index < activeIndex()"
            [attr.aria-current]="$index === activeIndex() ? 'step' : null"
          >
            <span class="fin-wizard__progress-index">{{ $index + 1 }}</span>
            <span class="fin-wizard__progress-title">{{ step.title() }}</span>
          </li>
        }
      </ol>

      @if (activeStep(); as step) {
        <section class="fin-wizard__panel" [attr.aria-label]="step.title()">
          <ng-container *ngTemplateOutlet="step.content()" />
        </section>
      }

      <nav class="fin-wizard__nav">
        <button
          type="button"
          (click)="previous()"
          [disabled]="activeIndex() === 0"
        >
          Back
        </button>
        <button
          type="button"
          (click)="next()"
          [disabled]="!canAdvance() || activeIndex() === steps().length - 1"
        >
          Next
        </button>
      </nav>
    </div>
  `,
})
export class FinWizardComponent {
  readonly steps = contentChildren(FinWizardStepComponent);
  readonly activeIndex = signal(0);

  protected readonly activeStep = computed(
    () => this.steps()[this.activeIndex()],
  );
  protected readonly canAdvance = computed(
    () => this.activeStep()?.valid() ?? false,
  );

  next(): void {
    const max = this.steps().length - 1;
    if (!this.canAdvance()) {
      return;
    }
    this.activeIndex.update((i) => Math.min(i + 1, max));
  }

  previous(): void {
    this.activeIndex.update((i) => Math.max(i - 1, 0));
  }

  goTo(index: number): void {
    const max = this.steps().length - 1;
    this.activeIndex.set(Math.max(0, Math.min(index, max)));
  }
}
