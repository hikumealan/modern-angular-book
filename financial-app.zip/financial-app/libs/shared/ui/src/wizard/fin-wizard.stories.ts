// See ch26-storybook.md
import type { Meta, StoryObj } from '@storybook/angular';
import { moduleMetadata } from '@storybook/angular';
import { FinWizardComponent } from './fin-wizard.component';
import { FinWizardStepComponent } from './fin-wizard-step.component';

const meta: Meta<FinWizardComponent> = {
  title: 'UI/Wizard',
  component: FinWizardComponent,
  tags: ['autodocs'],
  decorators: [
    moduleMetadata({
      imports: [FinWizardStepComponent],
    }),
  ],
};
export default meta;
type Story = StoryObj<FinWizardComponent>;

export const Default: Story = {
  name: 'Open Account (3 steps)',
  render: () => ({
    template: `
      <fin-wizard>
        <fin-wizard-step title="Client Details">
          <p>Capture the client's name, email, and risk profile.</p>
        </fin-wizard-step>
        <fin-wizard-step title="Fund Account">
          <p>Transfer an opening deposit into the new account.</p>
        </fin-wizard-step>
        <fin-wizard-step title="Review &amp; Submit">
          <p>Confirm account details and submit for approval.</p>
        </fin-wizard-step>
      </fin-wizard>
    `,
  }),
};

export const FirstStepBlocked: Story = {
  name: 'Blocked on first step',
  render: () => ({
    template: `
      <fin-wizard>
        <fin-wizard-step title="Client Details" [valid]="false">
          <p>The Next button stays disabled until this step reports valid.</p>
        </fin-wizard-step>
        <fin-wizard-step title="Fund Account">
          <p>Transfer the opening deposit.</p>
        </fin-wizard-step>
        <fin-wizard-step title="Review">
          <p>Review and submit.</p>
        </fin-wizard-step>
      </fin-wizard>
    `,
  }),
};
