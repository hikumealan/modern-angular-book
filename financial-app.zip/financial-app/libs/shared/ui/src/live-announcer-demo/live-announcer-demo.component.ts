// See ch24-accessibility.md -- "LiveAnnouncer"
import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal,
} from '@angular/core';
import { LiveAnnouncer } from '@angular/cdk/a11y';

@Component({
  selector: 'fin-live-announcer-demo',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './live-announcer-demo.component.html',
  styleUrl: './live-announcer-demo.component.scss',
})
export class LiveAnnouncerDemoComponent {
  private readonly announcer = inject(LiveAnnouncer);

  protected readonly lastAnnouncement = signal<string | null>(null);

  announceSaved(): void {
    const message = 'Transaction saved';
    // `polite` waits for the screen reader to finish its current
    // utterance; use `assertive` only for errors or critical state.
    void this.announcer.announce(message, 'polite');
    this.lastAnnouncement.set(message);
  }
}
