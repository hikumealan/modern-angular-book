// See ch21-feature-flags.md
export { FeatureFlagsService } from './feature-flags.service';
export { FEATURE_FLAGS_CONFIG } from './feature-flags.token';
export { requireFlag } from './require-flag.guard';
export type { FeatureFlag, FeatureFlagsConfig } from './types';
