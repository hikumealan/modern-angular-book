// See ch43-feature-flags.md -- "Providing flag configuration"
import { InjectionToken } from '@angular/core';
import type { FeatureFlagsConfig } from './types';

export const FEATURE_FLAGS_CONFIG = new InjectionToken<FeatureFlagsConfig>(
  'FEATURE_FLAGS_CONFIG',
);
