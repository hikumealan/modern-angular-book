// See ch21-feature-flags.md -- "Typed flag keys"
export type FeatureFlag = string;

export interface FeatureFlagsConfig {
  endpoint?: string;
  pollingIntervalMs?: number;
}
