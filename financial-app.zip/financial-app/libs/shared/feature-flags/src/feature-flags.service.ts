// See ch43-feature-flags.md -- "A signal-based flags service"
import { HttpClient } from '@angular/common/http';
import { Injectable, computed, inject, signal, type Signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { FEATURE_FLAGS_CONFIG } from './feature-flags.token';
import type { FeatureFlag } from './types';

type FlagPayload = Record<string, unknown>;

@Injectable({ providedIn: 'root' })
export class FeatureFlagsService {
  private readonly http = inject(HttpClient);
  private readonly config = inject(FEATURE_FLAGS_CONFIG, { optional: true });

  private readonly flags = signal<Record<string, unknown>>({});

  isEnabled(key: FeatureFlag): Signal<boolean> {
    return computed(() => Boolean(this.flags()[key]));
  }

  variant<T>(key: FeatureFlag, defaultValue: T): Signal<T> {
    return computed(() => {
      const value = this.flags()[key];
      return value === undefined ? defaultValue : (value as T);
    });
  }

  async load(): Promise<void> {
    const endpoint = this.config?.endpoint;
    if (!endpoint) {
      return;
    }
    const payload = await firstValueFrom(this.http.get<FlagPayload>(endpoint));
    this.flags.set(payload ?? {});
  }
}
