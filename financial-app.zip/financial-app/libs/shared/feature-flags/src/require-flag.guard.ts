// See ch43-feature-flags.md -- "Gating routes behind flags"
import { inject } from '@angular/core';
import { Router, type CanActivateFn } from '@angular/router';
import { FeatureFlagsService } from './feature-flags.service';
import type { FeatureFlag } from './types';

export function requireFlag(key: FeatureFlag, redirectTo = '/'): CanActivateFn {
  return () => {
    const flags = inject(FeatureFlagsService);
    const router = inject(Router);
    return flags.isEnabled(key)() ? true : router.createUrlTree([redirectTo]);
  };
}
