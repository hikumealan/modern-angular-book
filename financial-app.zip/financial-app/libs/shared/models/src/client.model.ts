export interface Client {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  riskProfile: 'conservative' | 'moderate' | 'aggressive';
}
