// See ch27-advanced-typescript-openapi.md
// Consolidated branded-ID home. Each domain model re-exports its own
// branded ID (see account.model.ts, transaction.model.ts); this file is
// the single location that exposes the full catalogue for cross-cutting
// code that needs every kind of ID in one place.
declare const BrandSymbol: unique symbol;
type Brand<T, B> = T & { readonly [typeof BrandSymbol]: B };

export type AccountId = Brand<number, 'AccountId'>;
export type TransactionId = Brand<number, 'TransactionId'>;
export type ClientId = Brand<number, 'ClientId'>;
export type PortfolioId = Brand<number, 'PortfolioId'>;
export type HoldingId = Brand<number, 'HoldingId'>;

export const asAccountId = (n: number): AccountId => n as AccountId;
export const asTransactionId = (n: number): TransactionId => n as TransactionId;
export const asClientId = (n: number): ClientId => n as ClientId;
export const asPortfolioId = (n: number): PortfolioId => n as PortfolioId;
export const asHoldingId = (n: number): HoldingId => n as HoldingId;
