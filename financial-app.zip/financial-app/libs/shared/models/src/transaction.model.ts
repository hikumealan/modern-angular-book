// See ch27-advanced-typescript-openapi.md -- "Branded IDs"
type Brand<T, B> = T & { readonly __brand: B };

// See ch27-advanced-typescript-openapi.md -- "Branded IDs"
export type TransactionId = Brand<number, 'TransactionId'>;

// See ch27-advanced-typescript-openapi.md -- smart constructor for TransactionId.
// Mirrors `accountId()` in account.model.ts; confining the `as` cast to this
// constructor is what makes a function signature like
// `markReviewed(id: TransactionId)` genuinely safe -- a caller cannot pass
// an `AccountId` or a raw `number` by accident.
export const transactionId = (n: number): TransactionId => n as TransactionId;

export interface Transaction {
  id: number;
  accountId: number;
  amount: number;
  type: 'credit' | 'debit';
  category: string;
  date: string;
  description: string;
  pending: boolean;
}
