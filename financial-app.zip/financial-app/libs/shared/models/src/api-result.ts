// See ch27-advanced-typescript-openapi.md
// Discriminated union for API responses. Consumers narrow via the
// `status` field so every success/error branch is checked exhaustively.
export interface ApiError {
  readonly code: string;
  readonly message: string;
  readonly details?: Readonly<Record<string, readonly string[]>>;
}

export type ApiResult<T> =
  | { status: 'success'; data: T }
  | { status: 'error'; error: ApiError };

export const apiSuccess = <T>(data: T): ApiResult<T> => ({
  status: 'success',
  data,
});

export const apiFailure = <T>(error: ApiError): ApiResult<T> => ({
  status: 'error',
  error,
});
