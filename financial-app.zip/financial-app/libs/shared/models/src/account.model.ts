// See ch27-advanced-typescript-openapi.md -- "Branded IDs"
type Brand<T, B> = T & { readonly __brand: B };

// See ch27-advanced-typescript-openapi.md -- "Branded IDs"
export type AccountId = Brand<number, 'AccountId'>;

// See ch27-advanced-typescript-openapi.md -- smart constructor for AccountId.
// Call sites that read `id` from a raw API payload use `accountId(raw.id)`
// to cross the untyped -> branded boundary in one place.
export const accountId = (n: number): AccountId => n as AccountId;

export interface Account {
  id: number;
  name: string;
  type: 'checking' | 'savings' | 'investment';
  balance: number;
  currency: string;
  ownerId: number;
}
