// See ch27-advanced-typescript-openapi.md
// Template-literal route types. Paired with a typed-router wrapper,
// these catch navigation typos and brand-mismatches at compile time.
import type {
  AccountId,
  ClientId,
  PortfolioId,
  TransactionId,
} from './ids';

export type AppRoute =
  | '/'
  | '/accounts'
  | `/accounts/${AccountId}`
  | `/accounts/${AccountId}/transactions`
  | '/transactions'
  | `/transactions/${TransactionId}`
  | '/portfolios'
  | `/portfolios/${PortfolioId}`
  | '/clients'
  | `/clients/${ClientId}`;
