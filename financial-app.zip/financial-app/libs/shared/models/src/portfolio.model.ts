export interface Portfolio {
  id: number;
  clientId: number;
  name: string;
  holdings: number[];
  totalValue: number;
}
