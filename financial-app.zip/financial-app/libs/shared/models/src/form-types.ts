// See ch27-advanced-typescript-openapi.md
// Mapped and conditional types that derive form models from domain
// interfaces. Add a field to the domain model and the form model
// automatically gains a matching entry.

// Minimal structural type compatible with Angular's `FormField<T>` /
// signal-forms `FormControl<T>`. Using a structural stand-in avoids a
// hard dependency on `@angular/forms/signals` from shared/models.
export interface FormFieldLike<T> {
  value: () => T;
  setValue(v: T): void;
  valid: () => boolean;
}

export type FormModel<T> = {
  [K in keyof T]: FormFieldLike<T[K]>;
};

export type EditableKeys<T> = {
  [K in keyof T]: T[K] extends (...args: unknown[]) => unknown ? never : K;
}[keyof T];

export type EditableFields<T> = Pick<T, EditableKeys<T>>;

export type FormModelFor<T, Exclude extends keyof T = never> = FormModel<
  Omit<EditableFields<T>, Exclude>
>;
