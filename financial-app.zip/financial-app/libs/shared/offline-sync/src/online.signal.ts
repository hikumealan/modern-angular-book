// See ch34-optimistic-ui.md -- "Reacting to network state"
import { signal, type Signal } from '@angular/core';

export function createOnlineSignal(): Signal<boolean> {
  const online = signal(navigator.onLine);
  window.addEventListener('online', () => online.set(true));
  window.addEventListener('offline', () => online.set(false));
  return online.asReadonly();
}
