// See ch44-offline-sync.md -- "A durable mutation queue"
import { Injectable, signal, type Signal } from '@angular/core';
import type { Mutation } from './types';

// NOTE: localStorage is used here for simplicity and readability. A production
// implementation should use `idb-keyval` or Dexie so the queue survives
// tab crashes, works with larger payloads, and avoids blocking the main thread.
const STORAGE_KEY = 'fin.mutation-queue';

@Injectable({ providedIn: 'root' })
export class MutationQueue {
  private readonly count = signal(this.readAll().length);

  size(): Signal<number> {
    return this.count.asReadonly();
  }

  async enqueue<T>(
    mutation: Omit<Mutation<T>, 'id' | 'timestamp' | 'retryCount'>,
  ): Promise<void> {
    const all = this.readAll();
    all.push({
      ...mutation,
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      retryCount: 0,
    } as Mutation);
    this.writeAll(all);
  }

  async peek(): Promise<Mutation | null> {
    return this.readAll()[0] ?? null;
  }

  async dequeue(id: string): Promise<void> {
    const remaining = this.readAll().filter((m) => m.id !== id);
    this.writeAll(remaining);
  }

  private readAll(): Mutation[] {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return [];
    }
    try {
      return JSON.parse(raw) as Mutation[];
    } catch {
      return [];
    }
  }

  private writeAll(all: Mutation[]): void {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
    this.count.set(all.length);
  }
}
