// See ch44-offline-sync.md -- "Modeling a replayable mutation"
export interface Mutation<T = unknown> {
  id: string;
  type: string;
  payload: T;
  timestamp: number;
  retryCount: number;
}
