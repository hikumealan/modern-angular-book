// See ch34-optimistic-ui.md -- "Flushing the queue when we come back online"
import {
  Injectable,
  InjectionToken,
  effect,
  inject,
  type Signal,
} from '@angular/core';
import { MutationQueue } from './mutation-queue';
import { createOnlineSignal } from './online.signal';
import type { Mutation } from './types';

export type SyncHandler = (mutation: Mutation) => Promise<void>;

export const SYNC_HANDLER = new InjectionToken<SyncHandler>('SYNC_HANDLER');

@Injectable({ providedIn: 'root' })
export class SyncService {
  private readonly queue = inject(MutationQueue);
  private readonly handler = inject<SyncHandler>(SYNC_HANDLER);
  private readonly online: Signal<boolean> = createOnlineSignal();

  private flushing = false;

  constructor() {
    effect(() => {
      if (this.online()) {
        void this.flush();
      }
    });
  }

  async flush(): Promise<void> {
    if (this.flushing) {
      return;
    }
    this.flushing = true;
    try {
      let next = await this.queue.peek();
      while (next && this.online()) {
        try {
          await this.handler(next);
          await this.queue.dequeue(next.id);
        } catch {
          // Leave the mutation in place; a retry/backoff strategy lives here.
          break;
        }
        next = await this.queue.peek();
      }
    } finally {
      this.flushing = false;
    }
  }
}
