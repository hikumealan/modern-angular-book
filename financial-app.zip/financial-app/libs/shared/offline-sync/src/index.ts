// See ch34-optimistic-ui.md
export { MutationQueue } from './mutation-queue';
export { SyncService, SYNC_HANDLER } from './sync.service';
export { createOnlineSignal } from './online.signal';
export type { Mutation } from './types';
