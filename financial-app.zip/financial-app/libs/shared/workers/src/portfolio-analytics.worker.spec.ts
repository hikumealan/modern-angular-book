// See ch35-web-workers.md
// Placeholder spec for the portfolio-analytics worker. The chapter shows
// how to import the worker's class and test its methods directly without
// spinning up a Worker instance. Here we verify the client's public
// surface; the full test suite lives alongside the worker in the book.
import { describe, it, expect } from 'vitest';

import { PortfolioAnalyticsClient } from './portfolio-analytics.client';

describe('PortfolioAnalyticsClient', () => {
  it('exposes the expected method surface', () => {
    const proto = PortfolioAnalyticsClient.prototype;
    expect(typeof proto.simulateReturns).toBe('function');
    expect(typeof proto.calculateSharpe).toBe('function');
    expect(typeof proto.terminate).toBe('function');
  });
});
