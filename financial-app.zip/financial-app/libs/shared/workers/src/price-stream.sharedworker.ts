// See ch35-web-workers.md
/// <reference lib="webworker" />
//
// SharedWorker that opens a single WebSocket for the price stream and
// fans messages out to every tab connected via `MessagePort`. The server
// sees one connection regardless of how many tabs the user has open.

const ports = new Set<MessagePort>();
const lastPrices = new Map<string, number>();

let socket: WebSocket | null = null;

function ensureSocket(): WebSocket {
  if (socket && socket.readyState !== WebSocket.CLOSED) return socket;
  socket = new WebSocket('wss://api.financial-app.com/prices');
  socket.addEventListener('message', ({ data }) => {
    const tick = JSON.parse(data) as { ticker: string; price: number };
    lastPrices.set(tick.ticker, tick.price);
    for (const port of ports) {
      port.postMessage({ type: 'tick', tick });
    }
  });
  return socket;
}

(self as unknown as SharedWorkerGlobalScope).addEventListener(
  'connect',
  (event) => {
    const port = (event as MessageEvent).ports[0];
    ports.add(port);
    ensureSocket();
    port.postMessage({
      type: 'snapshot',
      prices: Object.fromEntries(lastPrices),
    });
    port.start();
  },
);
