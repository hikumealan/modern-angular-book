// See ch35-web-workers.md
// Angular service wrapping the portfolio-analytics worker via Comlink.
// The worker's typed API is the single source of truth for method
// signatures on both sides of the boundary.
import { Injectable, OnDestroy } from '@angular/core';
import * as Comlink from 'comlink';

import type { PortfolioAnalyticsApi } from './portfolio-analytics.worker';

@Injectable({ providedIn: 'root' })
export class PortfolioAnalyticsService implements OnDestroy {
  private readonly worker = new Worker(
    new URL('./portfolio-analytics.worker', import.meta.url),
    { type: 'module' },
  );

  private readonly analytics = Comlink.wrap<PortfolioAnalyticsApi>(this.worker);

  simulateReturns = this.analytics.simulateReturns.bind(this.analytics);
  calculateSharpe = this.analytics.calculateSharpe.bind(this.analytics);

  ngOnDestroy(): void {
    this.worker.terminate();
  }
}
