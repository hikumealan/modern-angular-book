// See ch35-web-workers.md
export { createPortfolioAnalyticsWorker } from './portfolio-analytics.client';
export { PortfolioAnalyticsClient } from './portfolio-analytics.client';
