// See ch38-web-workers.md
export { createPortfolioAnalyticsWorker } from './portfolio-analytics.client';
export { PortfolioAnalyticsClient } from './portfolio-analytics.client';
