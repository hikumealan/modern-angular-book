// See ch35-web-workers.md
/// <reference lib="webworker" />

// Comlink-style API surface, exposed via a hand-rolled postMessage
// dispatcher so the library stays dependency-free.
const api = {
  simulateReturns(returns: number[], years: number): number[] {
    if (returns.length === 0 || years <= 0) return [];
    const mean =
      returns.reduce((sum, r) => sum + r, 0) / returns.length;
    const variance =
      returns.reduce((sum, r) => sum + (r - mean) ** 2, 0) / returns.length;
    const stdDev = Math.sqrt(variance);

    const out: number[] = [];
    let value = 1;
    for (let year = 0; year < years; year++) {
      // Box-Muller transform for a normally distributed draw.
      const u1 = Math.max(Number.EPSILON, Math.random());
      const u2 = Math.random();
      const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
      const yearReturn = mean + stdDev * z;
      value *= 1 + yearReturn;
      out.push(value);
    }
    return out;
  },

  calculateSharpe(returns: number[], riskFreeRate: number): number {
    if (returns.length === 0) return 0;
    const excess = returns.map((r) => r - riskFreeRate);
    const mean = excess.reduce((sum, r) => sum + r, 0) / excess.length;
    const variance =
      excess.reduce((sum, r) => sum + (r - mean) ** 2, 0) / excess.length;
    const stdDev = Math.sqrt(variance);
    return stdDev === 0 ? 0 : mean / stdDev;
  },
};

export type PortfolioAnalyticsApi = typeof api;

interface RequestMessage {
  id: number;
  method: keyof PortfolioAnalyticsApi;
  args: unknown[];
}

interface ResponseMessage {
  id: number;
  result?: unknown;
  error?: string;
}

const ctx = self as unknown as DedicatedWorkerGlobalScope;

ctx.addEventListener('message', (event: MessageEvent<RequestMessage>) => {
  const { id, method, args } = event.data;
  const handler = api[method] as ((...a: unknown[]) => unknown) | undefined;

  if (typeof handler !== 'function') {
    const response: ResponseMessage = {
      id,
      error: `Unknown method: ${String(method)}`,
    };
    ctx.postMessage(response);
    return;
  }

  try {
    const result = handler(...args);
    const response: ResponseMessage = { id, result };
    ctx.postMessage(response);
  } catch (err) {
    const response: ResponseMessage = {
      id,
      error: err instanceof Error ? err.message : String(err),
    };
    ctx.postMessage(response);
  }
});
