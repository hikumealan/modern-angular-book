// See ch35-web-workers.md
import type { PortfolioAnalyticsApi } from './portfolio-analytics.worker';

interface RequestMessage {
  id: number;
  method: keyof PortfolioAnalyticsApi;
  args: unknown[];
}

interface ResponseMessage {
  id: number;
  result?: unknown;
  error?: string;
}

interface PendingRequest {
  resolve: (value: unknown) => void;
  reject: (reason: Error) => void;
}

export class PortfolioAnalyticsClient {
  private readonly worker: Worker;
  private readonly pending = new Map<number, PendingRequest>();
  private nextId = 0;

  constructor() {
    this.worker = new Worker(
      new URL('./portfolio-analytics.worker.ts', import.meta.url),
      { type: 'module' },
    );
    this.worker.addEventListener('message', this.handleMessage);
    this.worker.addEventListener('error', this.handleError);
  }

  simulateReturns(returns: number[], years: number): Promise<number[]> {
    return this.call('simulateReturns', [returns, years]) as Promise<number[]>;
  }

  calculateSharpe(returns: number[], riskFreeRate: number): Promise<number> {
    return this.call('calculateSharpe', [returns, riskFreeRate]) as Promise<number>;
  }

  terminate(): void {
    this.worker.removeEventListener('message', this.handleMessage);
    this.worker.removeEventListener('error', this.handleError);
    this.worker.terminate();
    for (const pending of this.pending.values()) {
      pending.reject(new Error('Worker terminated'));
    }
    this.pending.clear();
  }

  private call(
    method: keyof PortfolioAnalyticsApi,
    args: unknown[],
  ): Promise<unknown> {
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      const message: RequestMessage = { id, method, args };
      this.worker.postMessage(message);
    });
  }

  private readonly handleMessage = (event: MessageEvent<ResponseMessage>) => {
    const { id, result, error } = event.data;
    const pending = this.pending.get(id);
    if (!pending) return;
    this.pending.delete(id);
    if (error) {
      pending.reject(new Error(error));
    } else {
      pending.resolve(result);
    }
  };

  private readonly handleError = (event: ErrorEvent) => {
    for (const pending of this.pending.values()) {
      pending.reject(new Error(event.message || 'Worker error'));
    }
    this.pending.clear();
  };
}

export function createPortfolioAnalyticsWorker(): PortfolioAnalyticsClient {
  return new PortfolioAnalyticsClient();
}
