// See ch19-error-handling.md
export {
  GlobalErrorHandler,
  TELEMETRY_SINK,
  type TelemetrySink,
} from './global-error-handler';
