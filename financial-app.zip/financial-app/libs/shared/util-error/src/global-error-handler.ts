// See ch19-error-handling.md -- global ErrorHandler with optional telemetry forwarding.
//
// Kept dependency-free so util-error stays a leaf library: consumers wire
// their own `TelemetryService` (for example the one from shared/observability)
// via the TELEMETRY_SINK token in their app config. If nothing is provided,
// the handler still logs to the console -- errors are never swallowed.

import { ErrorHandler, Injectable, InjectionToken, inject } from '@angular/core';

export interface TelemetrySink {
  trackError(error: unknown, context?: Record<string, unknown>): void;
}

export const TELEMETRY_SINK = new InjectionToken<TelemetrySink>('TELEMETRY_SINK');

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  private readonly telemetry = inject(TELEMETRY_SINK, { optional: true });

  handleError(error: unknown): void {
    const resolved = this.unwrap(error);

    console.error('[GlobalErrorHandler]', resolved);

    this.telemetry?.trackError(resolved, {
      url: globalThis.location?.href,
      at: new Date().toISOString(),
    });
  }

  private unwrap(error: unknown): Error {
    if (error instanceof Error) {
      return error.cause instanceof Error ? error.cause : error;
    }
    return new Error(String(error));
  }
}
