// See ch48-di-deep-dive.md
// Tree-shakable `InjectionToken` with a built-in factory. Nothing needs
// to list it in `appConfig.providers`; if the app never calls
// `inject(CLOCK)`, neither the token nor its default factory ships.
// Tests override via `TestBed.configureTestingModule({ providers: [
//   { provide: CLOCK, useValue: () => new Date('2026-01-01T00:00:00Z') },
// ]})`.
import { InjectionToken } from '@angular/core';

export const CLOCK = new InjectionToken<() => Date>('CLOCK', {
  providedIn: 'root',
  factory: () => () => new Date(),
});
