// See ch48-di-deep-dive.md
// `useFactory` example: pick a concrete `Logger` at bootstrap based on the
// app's environment. The factory runs inside an injection context, so we
// use `inject()` rather than the legacy `deps: [APP_CONFIG]` shape.
import { InjectionToken, Provider, inject } from '@angular/core';

export interface Logger {
  log(message: string, meta?: Record<string, unknown>): void;
  warn(message: string, meta?: Record<string, unknown>): void;
  error(message: string, meta?: Record<string, unknown>): void;
}

export interface AppConfig {
  readonly environment: 'development' | 'staging' | 'production';
  readonly apiUrl: string;
}

export const APP_CONFIG = new InjectionToken<AppConfig>('APP_CONFIG');
export const LOGGER = new InjectionToken<Logger>('LOGGER');

class ConsoleLogger implements Logger {
  log(m: string, meta?: Record<string, unknown>) {
    console.log(m, meta);
  }
  warn(m: string, meta?: Record<string, unknown>) {
    console.warn(m, meta);
  }
  error(m: string, meta?: Record<string, unknown>) {
    console.error(m, meta);
  }
}

class RemoteLogger implements Logger {
  constructor(private readonly endpoint: string) {}
  private send(level: string, message: string, meta?: Record<string, unknown>) {
    void fetch(`${this.endpoint}/logs`, {
      method: 'POST',
      body: JSON.stringify({ level, message, meta, at: Date.now() }),
    });
  }
  log = (m: string, meta?: Record<string, unknown>) => this.send('info', m, meta);
  warn = (m: string, meta?: Record<string, unknown>) => this.send('warn', m, meta);
  error = (m: string, meta?: Record<string, unknown>) => this.send('error', m, meta);
}

export const loggerProvider: Provider = {
  provide: LOGGER,
  useFactory: (): Logger => {
    const config = inject(APP_CONFIG);
    return config.environment === 'production'
      ? new RemoteLogger(config.apiUrl)
      : new ConsoleLogger();
  },
};
