// See ch08-rxjs-deep-dive.md
import { inject, Injectable, Injector } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { rxResource } from '@angular/core/rxjs-interop';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  map,
  merge,
  retry,
  scan,
  shareReplay,
  switchMap,
  withLatestFrom,
} from 'rxjs';

import type { Transaction } from '@financial-app/shared/models';

@Injectable({ providedIn: 'root' })
export class RxPatterns {
  private readonly http = inject(HttpClient);
  private readonly injector = inject(Injector);

  runningBalance(transactions$: Observable<Transaction>): Observable<number> {
    return transactions$.pipe(
      scan(
        (balance, tx) =>
          tx.type === 'credit' ? balance + tx.amount : balance - tx.amount,
        0,
      ),
    );
  }

  typeaheadResults<T>(
    term$: Observable<string>,
    search: (q: string) => Observable<T>,
  ): Observable<T> {
    return term$.pipe(
      debounceTime(250),
      distinctUntilChanged(),
      switchMap((q) => search(q)),
    );
  }

  mergeEvents<A, B>(a$: Observable<A>, b$: Observable<B>): Observable<A | B> {
    return merge(a$, b$);
  }

  withLatest<A, B>(
    primary$: Observable<A>,
    side$: Observable<B>,
  ): Observable<[A, B]> {
    return primary$.pipe(withLatestFrom(side$), map(([a, b]) => [a, b]));
  }

  cachedConfig<T>(url: string): Observable<T> {
    return this.http.get<T>(url).pipe(
      retry({ count: 2, delay: 500 }),
      shareReplay({ bufferSize: 1, refCount: true }),
    );
  }

  transactionsResource(
    accountId: () => number,
    range: () => { from: string; to: string },
  ) {
    return rxResource({
      injector: this.injector,
      params: () => ({ accountId: accountId(), range: range() }),
      stream: ({ params }) =>
        this.http
          .get<Transaction[]>('/api/transactions', {
            params: { accountId: String(params.accountId), ...params.range },
          })
          .pipe(
            retry({ count: 2, delay: 500 }),
            map((list) => list.sort((a, b) => b.date.localeCompare(a.date))),
          ),
    });
  }

  private readonly userActions$ = new Subject<string>();
  emit(action: string): void {
    this.userActions$.next(action);
  }
  actions$(): Observable<string> {
    return this.userActions$.asObservable();
  }
}
