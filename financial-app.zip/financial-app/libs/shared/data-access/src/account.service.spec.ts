// See ch07-testing-vitest.md
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import {
  provideHttpClientTesting,
  HttpTestingController,
} from '@angular/common/http/testing';
import { AccountService, API_URL } from './account.service';
import { Account } from '@financial-app/shared/models';

const mockAccounts: Account[] = [
  { id: 1, name: 'Main Checking', type: 'checking', balance: 5200, currency: 'USD', ownerId: 10 },
  { id: 2, name: 'Savings', type: 'savings', balance: 18400, currency: 'USD', ownerId: 10 },
];

describe('AccountService', () => {
  let service: AccountService;
  let httpTesting: HttpTestingController;
  const apiUrl = '/api';

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        { provide: API_URL, useValue: apiUrl },
      ],
    });

    service = TestBed.inject(AccountService);
    httpTesting = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpTesting.verify();
  });

  describe('getAccounts', () => {
    it('should request GET /accounts via httpResource', () => {
      TestBed.runInInjectionContext(() => service.getAccounts());
      TestBed.flushEffects();

      const req = httpTesting.expectOne(`${apiUrl}/accounts`);
      expect(req.request.method).toBe('GET');
      req.flush(mockAccounts);
    });

    it('should expose fetched accounts through the resource value', () => {
      const resource = TestBed.runInInjectionContext(() => service.getAccounts());
      TestBed.flushEffects();

      const req = httpTesting.expectOne(`${apiUrl}/accounts`);
      req.flush(mockAccounts);

      expect(resource.value()).toEqual(mockAccounts);
    });

    it('should default to an empty array before data loads', () => {
      const resource = TestBed.runInInjectionContext(() => service.getAccounts());
      expect(resource.value()).toEqual([]);
    });
  });

  describe('getAccountById', () => {
    it('should request GET /accounts/:id via httpResource', () => {
      TestBed.runInInjectionContext(() => service.getAccountById(1));
      TestBed.flushEffects();

      const req = httpTesting.expectOne(`${apiUrl}/accounts/1`);
      expect(req.request.method).toBe('GET');
      req.flush(mockAccounts[0]);
    });

    it('should expose the fetched account through the resource value', () => {
      const resource = TestBed.runInInjectionContext(
        () => service.getAccountById(2),
      );
      TestBed.flushEffects();

      const req = httpTesting.expectOne(`${apiUrl}/accounts/2`);
      req.flush(mockAccounts[1]);

      expect(resource.value()).toEqual(mockAccounts[1]);
    });
  });

  describe('saveAccount', () => {
    it('should POST new accounts without an id', () => {
      const newAccount: Partial<Account> = {
        name: 'New Account',
        type: 'checking',
        balance: 0,
        currency: 'USD',
        ownerId: 10,
      };
      const onNext = vi.fn();

      service.saveAccount(newAccount).subscribe(onNext);

      const req = httpTesting.expectOne(`${apiUrl}/accounts`);
      expect(req.request.method).toBe('POST');
      expect(req.request.body).toEqual(newAccount);
      req.flush({ ...newAccount, id: 3 });

      expect(onNext).toHaveBeenCalledWith(
        expect.objectContaining({ id: 3, name: 'New Account' }),
      );
    });

    it('should PUT existing accounts that have an id', () => {
      const existing: Partial<Account> = { id: 1, name: 'Updated', type: 'savings', balance: 100, currency: 'USD', ownerId: 10 };
      const onNext = vi.fn();

      service.saveAccount(existing).subscribe(onNext);

      const req = httpTesting.expectOne(`${apiUrl}/accounts/1`);
      expect(req.request.method).toBe('PUT');
      req.flush(existing);

      expect(onNext).toHaveBeenCalledWith(expect.objectContaining({ id: 1 }));
    });
  });

  describe('deleteAccount', () => {
    it('should send DELETE /accounts/:id', () => {
      const onComplete = vi.fn();

      service.deleteAccount(1).subscribe({ complete: onComplete });

      const req = httpTesting.expectOne(`${apiUrl}/accounts/1`);
      expect(req.request.method).toBe('DELETE');
      req.flush(null);

      expect(onComplete).toHaveBeenCalled();
    });
  });
});
