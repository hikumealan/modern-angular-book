// See ch05-state-management.md
import { Injectable, Injector, inject } from '@angular/core';
import { HttpClient, httpResource } from '@angular/common/http';
import { Transaction } from '@financial-app/shared/models';
import { API_URL } from './account.service';

export interface TransactionFilters {
  accountId?: number;
  category?: string;
  startDate?: string;
  endDate?: string;
}

@Injectable({ providedIn: 'root' })
export class TransactionService {
  private readonly http = inject(HttpClient);
  private readonly apiUrl = inject(API_URL);
  private readonly injector = inject(Injector);

  // httpResource is experimental and may change in future Angular releases.
  // Accepts a reactive function so the resource refetches when filter signals change.
  getTransactions(filters: () => TransactionFilters) {
    return httpResource<Transaction[]>(() => {
      const f = filters();
      const params: Record<string, string> = {};
      if (f.accountId != null) params['accountId'] = String(f.accountId);
      if (f.category) params['category'] = f.category;
      if (f.startDate) params['startDate'] = f.startDate;
      if (f.endDate) params['endDate'] = f.endDate;
      return { url: `${this.apiUrl}/transactions`, params };
    }, {
      injector: this.injector,
      defaultValue: [] as Transaction[],
    });
  }

  getTransactionsByAccount(accountId: number) {
    return httpResource<Transaction[]>(
      () => `${this.apiUrl}/accounts/${accountId}/transactions`,
      { injector: this.injector, defaultValue: [] as Transaction[] },
    );
  }

  saveTransaction(transaction: Partial<Transaction>) {
    if (transaction.id) {
      return this.http.put<Transaction>(
        `${this.apiUrl}/transactions/${transaction.id}`,
        transaction,
      );
    }
    return this.http.post<Transaction>(
      `${this.apiUrl}/transactions`,
      transaction,
    );
  }

  deleteTransaction(id: number) {
    return this.http.delete<void>(`${this.apiUrl}/transactions/${id}`);
  }
}
