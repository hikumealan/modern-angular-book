// See ch05-state-management.md
import { Injectable, InjectionToken, Injector, inject } from '@angular/core';
import { HttpClient, httpResource } from '@angular/common/http';
import { Account } from '@financial-app/shared/models';

export const API_URL = new InjectionToken<string>('API_URL');

@Injectable({ providedIn: 'root' })
export class AccountService {
  private readonly http = inject(HttpClient);
  private readonly apiUrl = inject(API_URL);
  private readonly injector = inject(Injector);

  // httpResource is experimental and may change in future Angular releases.
  // It provides a signal-based wrapper around HttpClient for reactive reads.
  getAccounts() {
    return httpResource<Account[]>(() => `${this.apiUrl}/accounts`, {
      injector: this.injector,
      defaultValue: [] as Account[],
    });
  }

  getAccountById(id: number) {
    return httpResource<Account | undefined>(() => `${this.apiUrl}/accounts/${id}`, {
      injector: this.injector,
    });
  }

  saveAccount(account: Partial<Account>) {
    if (account.id) {
      return this.http.put<Account>(
        `${this.apiUrl}/accounts/${account.id}`,
        account,
      );
    }
    return this.http.post<Account>(`${this.apiUrl}/accounts`, account);
  }

  deleteAccount(id: number) {
    return this.http.delete<void>(`${this.apiUrl}/accounts/${id}`);
  }
}
