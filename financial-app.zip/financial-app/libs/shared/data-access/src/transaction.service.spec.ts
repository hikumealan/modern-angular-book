// See ch07-testing-vitest.md
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import {
  provideHttpClientTesting,
  HttpTestingController,
} from '@angular/common/http/testing';
import { API_URL } from './account.service';
import {
  TransactionService,
  TransactionFilters,
} from './transaction.service';
import { Transaction } from '@financial-app/shared/models';

const mockTransactions: Transaction[] = [
  {
    id: 1, accountId: 10, amount: 250, type: 'debit',
    category: 'groceries', date: '2025-06-01', description: 'Supermarket', pending: false,
  },
  {
    id: 2, accountId: 10, amount: 3200, type: 'credit',
    category: 'salary', date: '2025-06-01', description: 'Payroll', pending: false,
  },
];

describe('TransactionService', () => {
  let service: TransactionService;
  let httpTesting: HttpTestingController;
  const apiUrl = '/api';

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        { provide: API_URL, useValue: apiUrl },
      ],
    });

    service = TestBed.inject(TransactionService);
    httpTesting = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpTesting.verify();
  });

  describe('getTransactions', () => {
    it('should request GET /transactions with no params when filters are empty', () => {
      const filters = signal<TransactionFilters>({});

      TestBed.runInInjectionContext(() => service.getTransactions(filters));
      TestBed.flushEffects();

      const req = httpTesting.expectOne(
        (r) => r.url === `${apiUrl}/transactions`,
      );
      expect(req.request.method).toBe('GET');
      req.flush(mockTransactions);
    });

    it('should include filter params in the request', () => {
      const filters = signal<TransactionFilters>({
        accountId: 10,
        category: 'groceries',
        startDate: '2025-06-01',
        endDate: '2025-06-30',
      });

      TestBed.runInInjectionContext(() => service.getTransactions(filters));
      TestBed.flushEffects();

      const req = httpTesting.expectOne(
        (r) => r.url === `${apiUrl}/transactions`,
      );
      expect(req.request.params.get('accountId')).toBe('10');
      expect(req.request.params.get('category')).toBe('groceries');
      expect(req.request.params.get('startDate')).toBe('2025-06-01');
      expect(req.request.params.get('endDate')).toBe('2025-06-30');
      req.flush([mockTransactions[0]]);
    });

    it('should default to an empty array before data loads', () => {
      const filters = signal<TransactionFilters>({});
      const resource = TestBed.runInInjectionContext(
        () => service.getTransactions(filters),
      );
      expect(resource.value()).toEqual([]);
    });
  });

  describe('getTransactionsByAccount', () => {
    it('should request GET /accounts/:id/transactions', () => {
      TestBed.runInInjectionContext(
        () => service.getTransactionsByAccount(10),
      );
      TestBed.flushEffects();

      const req = httpTesting.expectOne(
        `${apiUrl}/accounts/10/transactions`,
      );
      expect(req.request.method).toBe('GET');
      req.flush(mockTransactions);
    });
  });

  describe('saveTransaction', () => {
    it('should POST new transactions without an id', () => {
      const newTxn: Partial<Transaction> = {
        accountId: 10, amount: 75, type: 'debit',
        category: 'dining', date: '2025-06-15', description: 'Restaurant', pending: true,
      };
      const onNext = vi.fn();

      service.saveTransaction(newTxn).subscribe(onNext);

      const req = httpTesting.expectOne(`${apiUrl}/transactions`);
      expect(req.request.method).toBe('POST');
      expect(req.request.body).toEqual(newTxn);
      req.flush({ ...newTxn, id: 3 });

      expect(onNext).toHaveBeenCalledWith(
        expect.objectContaining({ id: 3, category: 'dining' }),
      );
    });

    it('should PUT existing transactions that have an id', () => {
      const existing: Partial<Transaction> = {
        id: 1, accountId: 10, amount: 300, type: 'debit',
        category: 'groceries', date: '2025-06-01', description: 'Updated', pending: false,
      };
      const onNext = vi.fn();

      service.saveTransaction(existing).subscribe(onNext);

      const req = httpTesting.expectOne(`${apiUrl}/transactions/1`);
      expect(req.request.method).toBe('PUT');
      req.flush(existing);

      expect(onNext).toHaveBeenCalledWith(
        expect.objectContaining({ id: 1 }),
      );
    });
  });

  describe('deleteTransaction', () => {
    it('should send DELETE /transactions/:id', () => {
      const onComplete = vi.fn();

      service.deleteTransaction(1).subscribe({ complete: onComplete });

      const req = httpTesting.expectOne(`${apiUrl}/transactions/1`);
      expect(req.request.method).toBe('DELETE');
      req.flush(null);

      expect(onComplete).toHaveBeenCalled();
    });
  });
});
