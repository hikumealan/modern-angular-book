// See ch48-di-deep-dive.md
// `inject()` with `{ optional: true }`: tests can provide an overrides
// record to flip flags, and production code skips the provider entirely.
import { InjectionToken, Injectable, inject } from '@angular/core';

export const FEATURE_FLAG_OVERRIDES = new InjectionToken<
  Record<string, boolean>
>('FEATURE_FLAG_OVERRIDES');

@Injectable({ providedIn: 'root' })
export class FeatureFlagService {
  private readonly overrides = inject(FEATURE_FLAG_OVERRIDES, {
    optional: true,
  });

  private readonly defaultFlags: Readonly<Record<string, boolean>> = {};

  isEnabled(flag: string): boolean {
    if (this.overrides && flag in this.overrides) {
      return this.overrides[flag];
    }
    return this.defaultFlags[flag] ?? false;
  }
}
