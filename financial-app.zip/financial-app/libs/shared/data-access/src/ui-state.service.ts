// See ch08-rxjs-deep-dive.md
// Tiny signal-based UI state service. A greenfield replacement for the
// `BehaviorSubject`-style pattern described in the chapter; kept minimal so
// consumers in other features can extend it without importing more surface
// than they need.
import { DestroyRef, Injectable, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class UiStateService {
  private readonly destroyRef = inject(DestroyRef);

  private readonly _selectedAccountId = signal<number | null>(null);
  readonly selectedAccountId = this._selectedAccountId.asReadonly();
  readonly hasSelection = computed(() => this._selectedAccountId() !== null);

  private readonly selectedAccountId$ = new BehaviorSubject<number | null>(null);
  readonly current$: Observable<number | null> =
    this.selectedAccountId$.asObservable();

  constructor() {
    this.selectedAccountId$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((id) => this._selectedAccountId.set(id));
  }

  select(id: number | null): void {
    this.selectedAccountId$.next(id);
  }
}
