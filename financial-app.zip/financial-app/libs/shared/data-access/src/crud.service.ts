// See ch27-advanced-typescript-openapi.md
// Generic CRUD base class. Concrete services extend it with a `basePath`
// and optionally refine the `id` type with a branded ID for extra safety.
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export abstract class CrudService<T extends { id: number }> {
  protected abstract readonly basePath: string;
  protected readonly http = inject(HttpClient);

  getAll(params?: Record<string, string>): Observable<T[]> {
    return this.http.get<T[]>(this.basePath, { params });
  }

  getById(id: number): Observable<T> {
    return this.http.get<T>(`${this.basePath}/${id}`);
  }

  create(payload: Omit<T, 'id'>): Observable<T> {
    return this.http.post<T>(this.basePath, payload);
  }

  update(id: number, payload: Partial<Omit<T, 'id'>>): Observable<T> {
    return this.http.put<T>(`${this.basePath}/${id}`, payload);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.basePath}/${id}`);
  }
}
