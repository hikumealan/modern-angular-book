// See ch48-di-deep-dive.md
// Multi-provider registry for dashboard widgets. Features contribute
// `WidgetRegistration` entries; the dashboard component reads the
// accumulated array. Adding a new widget never requires editing the
// dashboard.
import { InjectionToken, Provider, Type } from '@angular/core';

export interface WidgetRegistration {
  readonly id: string;
  readonly title: string;
  readonly component: Type<unknown>;
  readonly defaultGridSpan: 1 | 2 | 3 | 4;
  readonly permission?: string;
}

export const WIDGET_REGISTRATIONS = new InjectionToken<WidgetRegistration[]>(
  'WIDGET_REGISTRATIONS',
);

export function provideWidget(
  registration: WidgetRegistration,
): Provider {
  return {
    provide: WIDGET_REGISTRATIONS,
    useValue: registration,
    multi: true,
  };
}
