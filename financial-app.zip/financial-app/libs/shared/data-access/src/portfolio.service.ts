// See ch05-state-management.md
import { Injectable, Injector, inject } from '@angular/core';
import { httpResource } from '@angular/common/http';
import { Holding, Portfolio } from '@financial-app/shared/models';
import { API_URL } from './account.service';

@Injectable({ providedIn: 'root' })
export class PortfolioService {
  private readonly apiUrl = inject(API_URL);
  private readonly injector = inject(Injector);

  // httpResource is experimental and may change in future Angular releases
  getPortfoliosByClient(clientId: number) {
    return httpResource<Portfolio[]>(
      () => `${this.apiUrl}/clients/${clientId}/portfolios`,
      { injector: this.injector, defaultValue: [] as Portfolio[] },
    );
  }

  getHoldingsForPortfolio(portfolioId: number) {
    return httpResource<Holding[]>(
      () => `${this.apiUrl}/portfolios/${portfolioId}/holdings`,
      { injector: this.injector, defaultValue: [] as Holding[] },
    );
  }
}
