// See ch08-rxjs-deep-dive.md
import { beforeEach, describe, expect, it } from 'vitest';
import { TestScheduler } from 'rxjs/testing';
import { scan } from 'rxjs';

describe('runningBalance (marble)', () => {
  let scheduler: TestScheduler;

  beforeEach(() => {
    scheduler = new TestScheduler((actual, expected) => {
      expect(actual).toEqual(expected);
    });
  });

  it('accumulates credits and debits as they arrive', () => {
    scheduler.run(({ cold, expectObservable }) => {
      const source = cold('a-b-c|', {
        a: { type: 'credit', amount: 100 } as const,
        b: { type: 'debit', amount: 30 } as const,
        c: { type: 'credit', amount: 10 } as const,
      });

      const running$ = source.pipe(
        scan(
          (balance, tx) =>
            tx.type === 'credit' ? balance + tx.amount : balance - tx.amount,
          0,
        ),
      );

      expectObservable(running$).toBe('x-y-z|', { x: 100, y: 70, z: 80 });
    });
  });
});
