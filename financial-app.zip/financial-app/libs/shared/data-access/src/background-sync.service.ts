// See ch33-pwa-service-workers.md
// BackgroundSync wrapper that queues offline writes in IndexedDB and
// replays them sequentially when connectivity returns. Sequence matters
// for financial transactions (transfer-out before transfer-in), so
// `flushQueue` stops on the first failure rather than racing.
import { Injectable, effect, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

interface PendingRequest {
  readonly id: string;
  readonly url: string;
  readonly method: 'POST' | 'PUT' | 'DELETE';
  readonly body: unknown;
  readonly timestamp: number;
}

const DB_NAME = 'financial-app-sync';
const STORE = 'pending';

@Injectable({ providedIn: 'root' })
export class BackgroundSyncService {
  private readonly http = inject(HttpClient);
  private readonly online = signal(
    typeof navigator === 'undefined' ? true : navigator.onLine,
  );

  constructor() {
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => this.online.set(true));
      window.addEventListener('offline', () => this.online.set(false));
    }
    effect(() => {
      if (this.online()) void this.flushQueue();
    });
  }

  async queue(
    url: string,
    method: PendingRequest['method'],
    body: unknown,
  ): Promise<void> {
    const db = await this.openDB();
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).add({
      id: crypto.randomUUID(),
      url,
      method,
      body,
      timestamp: Date.now(),
    } satisfies PendingRequest);
  }

  private async flushQueue(): Promise<void> {
    const db = await this.openDB();
    const pending: PendingRequest[] = await new Promise((resolve, reject) => {
      const req = db
        .transaction(STORE, 'readonly')
        .objectStore(STORE)
        .getAll();
      req.onsuccess = () => resolve(req.result as PendingRequest[]);
      req.onerror = () => reject(req.error);
    });

    for (const r of pending) {
      try {
        await firstValueFrom(
          this.http.request(r.method, r.url, { body: r.body }),
        );
        db.transaction(STORE, 'readwrite').objectStore(STORE).delete(r.id);
      } catch {
        break;
      }
    }
  }

  private openDB(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () =>
        req.result.createObjectStore(STORE, { keyPath: 'id' });
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
}
