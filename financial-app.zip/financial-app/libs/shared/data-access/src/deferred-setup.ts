// See ch48-di-deep-dive.md
// `runInInjectionContext` escape hatch. When you must call `inject()`
// past an async boundary -- a `setTimeout` callback, a Promise chain --
// capture an `EnvironmentInjector` up front and install it temporarily
// inside the callback.
import {
  EnvironmentInjector,
  inject,
  runInInjectionContext,
} from '@angular/core';
import { AccountService } from './account.service';

export function scheduleBackgroundRefresh(delayMs = 5_000): void {
  const injector = inject(EnvironmentInjector);
  setTimeout(() => {
    runInInjectionContext(injector, () => {
      const accounts = inject(AccountService);
      accounts.getAccounts();
    });
  }, delayMs);
}
