// See ch27-advanced-typescript-openapi.md
// Generic API wrapper returning a discriminated `ApiResult<T>`. Callers
// narrow on `status` rather than catching errors in ad-hoc `try`/`catch`
// blocks scattered through components.
import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, catchError, map, of } from 'rxjs';

import type { ApiResult } from '@financial-app/shared/models';
import type { Transaction } from '@financial-app/shared/models';

export interface TransactionDraft {
  readonly accountId: number;
  readonly amount: number;
  readonly type: 'credit' | 'debit';
  readonly category: string;
  readonly date: string;
  readonly description?: string;
}

@Injectable({ providedIn: 'root' })
export class TransactionApiService {
  private readonly http = inject(HttpClient);

  submitTransaction(tx: TransactionDraft): Observable<ApiResult<Transaction>> {
    return this.http.post<Transaction>('/api/transactions', tx).pipe(
      map((data) => ({ status: 'success' as const, data })),
      catchError((err: HttpErrorResponse) =>
        of({
          status: 'error' as const,
          error: {
            code: (err.error?.code as string) ?? 'UNKNOWN',
            message:
              (err.error?.message as string) ?? 'Unexpected error',
          },
        }),
      ),
    );
  }
}
