// See ch08-rxjs-deep-dive.md
// A small diagnostic buffer of recent errors. `ReplaySubject` keeps the
// last N entries within a bounded time window; the chapter uses it as a
// canonical "recent activity" pattern.
import { Injectable } from '@angular/core';
import { Observable, ReplaySubject } from 'rxjs';

export interface AppError {
  readonly message: string;
  readonly at: number;
  readonly context?: Record<string, unknown>;
}

@Injectable({ providedIn: 'root' })
export class ErrorLogService {
  private readonly errors$ = new ReplaySubject<AppError>(50, 60_000);

  readonly recent$: Observable<AppError> = this.errors$.asObservable();

  record(error: AppError): void {
    this.errors$.next(error);
  }
}
