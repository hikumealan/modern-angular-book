// See ch08-rxjs-deep-dive.md
// Tiny service exposing runtime config through `httpResource`. The RxJS
// `shareReplay`-multicast variant appears in the chapter; here we use the
// signal-based resource equivalent so the rest of the app reads config
// reactively without managing subscriptions.
import { Injectable, Injector, inject } from '@angular/core';
import { httpResource } from '@angular/common/http';

export interface AppConfig {
  readonly environment: 'development' | 'staging' | 'production';
  readonly apiUrl: string;
  readonly featureFlags: Readonly<Record<string, boolean>>;
}

@Injectable({ providedIn: 'root' })
export class ConfigService {
  private readonly injector = inject(Injector);

  readonly config = httpResource<AppConfig>(() => '/api/config', {
    injector: this.injector,
    defaultValue: {
      environment: 'development',
      apiUrl: '/api',
      featureFlags: {},
    } satisfies AppConfig,
  });
}
