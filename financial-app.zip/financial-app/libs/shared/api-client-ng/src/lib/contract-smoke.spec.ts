// See appendix-b-e2e-workflow.md -- "Parameterized contract smoke tests"
//
// Iterates every service in the Strategy D generated barrel and asserts
// that each public method returns an Observable when given minimal input.
// The point is structural coverage: "every operation in openapi.json has
// a callable generated service". The deeper schema validation lives in
// the per-service specs (e.g. accounts.service.spec.ts).
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting,
} from '@angular/common/http/testing';
import { describe, it, expect, beforeEach } from 'vitest';
import { Observable } from 'rxjs';

import {
  AccountsService,
  TransactionsService,
  ClientsService,
  PortfoliosService,
} from './generated/api/api';
import { Configuration } from './generated/configuration';
import { makeTransactionDraft } from '@financial-app/shared/testing';

interface ContractCase {
  name: string;
  invoke: (services: ReturnType<typeof resolveServices>) => Observable<unknown>;
}

function resolveServices() {
  return {
    accounts: TestBed.inject(AccountsService),
    transactions: TestBed.inject(TransactionsService),
    clients: TestBed.inject(ClientsService),
    portfolios: TestBed.inject(PortfoliosService),
  };
}

const contractCases: ContractCase[] = [
  { name: 'AccountsService.listAccounts', invoke: (s) => s.accounts.listAccounts() },
  { name: 'AccountsService.getAccount', invoke: (s) => s.accounts.getAccount(1) },
  { name: 'TransactionsService.listTransactions', invoke: (s) => s.transactions.listTransactions() },
  {
    name: 'TransactionsService.createTransaction',
    invoke: (s) => s.transactions.createTransaction(makeTransactionDraft()),
  },
  { name: 'ClientsService.listClients', invoke: (s) => s.clients.listClients() },
  { name: 'ClientsService.getClient', invoke: (s) => s.clients.getClient(10) },
  { name: 'PortfoliosService.listPortfolios', invoke: (s) => s.portfolios.listPortfolios() },
  {
    name: 'PortfoliosService.listPortfolioHoldings',
    invoke: (s) => s.portfolios.listPortfolioHoldings(1),
  },
];

describe('Strategy D generated services: contract smoke', () => {
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        { provide: Configuration, useValue: new Configuration({ basePath: '' }) },
      ],
    });
    http = TestBed.inject(HttpTestingController);
  });

  it.each(contractCases)('$name returns an Observable', ({ invoke }) => {
    const services = resolveServices();
    const result = invoke(services);
    expect(result).toBeInstanceOf(Observable);
    // Consume the observable so outstanding HTTP requests are created and
    // can be matched by HttpTestingController.match below.
    const sub = result.subscribe({ error: () => undefined });
    // Drain any pending request so the afterEach verify() does not fail.
    http.match(() => true).forEach((req) => req.flush(null, { status: 204, statusText: 'No Content' }));
    sub.unsubscribe();
  });
});
