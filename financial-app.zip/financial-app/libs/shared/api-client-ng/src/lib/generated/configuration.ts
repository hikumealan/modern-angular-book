/* tslint:disable */
/* eslint-disable */
// AUTO-GENERATED (OpenAPI Generator typescript-angular). See appendix-b-e2e-workflow.md.
import { HttpParameterCodec } from '@angular/common/http';

export interface ConfigurationParameters {
  basePath?: string;
  withCredentials?: boolean;
  username?: string;
  password?: string;
  accessToken?: string | (() => string);
  credentials?: { [key: string]: string | (() => string) };
  encoder?: HttpParameterCodec;
}

export class Configuration {
  basePath?: string;
  withCredentials?: boolean;
  username?: string;
  password?: string;
  accessToken?: string | (() => string);
  credentials: { [key: string]: string | (() => string) };
  encoder?: HttpParameterCodec;

  constructor(configurationParameters: ConfigurationParameters = {}) {
    this.basePath = configurationParameters.basePath;
    this.withCredentials = configurationParameters.withCredentials;
    this.username = configurationParameters.username;
    this.password = configurationParameters.password;
    this.accessToken = configurationParameters.accessToken;
    this.encoder = configurationParameters.encoder;
    this.credentials = configurationParameters.credentials ?? {};
  }

  selectHeaderContentType(contentTypes: string[]): string | undefined {
    if (contentTypes.length === 0) {
      return undefined;
    }
    const type = contentTypes.find((x) => this.isJsonMime(x));
    return type ?? contentTypes[0];
  }

  selectHeaderAccept(accepts: string[]): string | undefined {
    if (accepts.length === 0) {
      return undefined;
    }
    const type = accepts.find((x) => this.isJsonMime(x));
    return type ?? accepts[0];
  }

  isJsonMime(mime: string): boolean {
    const jsonMime = /^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$/i;
    return mime !== null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
  }
}
