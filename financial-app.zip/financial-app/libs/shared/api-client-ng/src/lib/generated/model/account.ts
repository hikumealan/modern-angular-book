/* tslint:disable */
/* eslint-disable */
// AUTO-GENERATED (OpenAPI Generator typescript-angular). See appendix-b-e2e-workflow.md.

export type AccountType = 'checking' | 'savings' | 'investment';
export const AccountType = {
  Checking: 'checking' as AccountType,
  Savings: 'savings' as AccountType,
  Investment: 'investment' as AccountType,
};

export type AccountCurrency = 'USD' | 'EUR' | 'GBP' | 'JPY';
export const AccountCurrency = {
  Usd: 'USD' as AccountCurrency,
  Eur: 'EUR' as AccountCurrency,
  Gbp: 'GBP' as AccountCurrency,
  Jpy: 'JPY' as AccountCurrency,
};

export interface Account {
  id: number;
  name: string;
  type: AccountType;
  balance: number;
  currency: AccountCurrency;
  ownerId: number;
}
