/* tslint:disable */
/* eslint-disable */
// AUTO-GENERATED (OpenAPI Generator typescript-angular). See appendix-b-e2e-workflow.md.

export type RiskProfile = 'conservative' | 'moderate' | 'aggressive';
export const RiskProfile = {
  Conservative: 'conservative' as RiskProfile,
  Moderate: 'moderate' as RiskProfile,
  Aggressive: 'aggressive' as RiskProfile,
};

export interface Client {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  riskProfile: RiskProfile;
}
