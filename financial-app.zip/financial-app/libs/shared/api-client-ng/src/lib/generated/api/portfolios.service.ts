/* tslint:disable */
/* eslint-disable */
// AUTO-GENERATED (OpenAPI Generator typescript-angular). See appendix-b-e2e-workflow.md.
import { inject, Injectable, Optional, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import type { Portfolio } from '../model/portfolio';
import type { Holding } from '../model/holding';
import { BASE_PATH } from '../variables';
import { Configuration } from '../configuration';

export interface PortfoliosServiceInterface {
  listPortfolios(): Observable<Array<Portfolio>>;
  listPortfolioHoldings(portfolioId: number): Observable<Array<Holding>>;
}

@Injectable({ providedIn: 'root' })
export class PortfoliosService implements PortfoliosServiceInterface {
  protected basePath = 'http://localhost:8000';
  protected defaultHeaders = new HttpHeaders();
  public configuration: Configuration;
  private http = inject(HttpClient);

  constructor(@Optional() @Inject(BASE_PATH) basePath?: string, @Optional() configuration?: Configuration) {
    this.configuration = configuration ?? new Configuration();
    this.basePath = configuration?.basePath ?? basePath ?? this.basePath;
  }

  public listPortfolios(): Observable<Array<Portfolio>> {
    const headers = this.defaultHeaders.set('Accept', 'application/json');
    return this.http.get<Array<Portfolio>>(`${this.basePath}/api/portfolios`, {
      headers,
      withCredentials: this.configuration.withCredentials,
    });
  }

  public listPortfolioHoldings(portfolioId: number): Observable<Array<Holding>> {
    if (portfolioId == null) {
      throw new Error('Required parameter portfolioId was null or undefined.');
    }
    const headers = this.defaultHeaders.set('Accept', 'application/json');
    return this.http.get<Array<Holding>>(
      `${this.basePath}/api/portfolios/${encodeURIComponent(String(portfolioId))}/holdings`,
      { headers, withCredentials: this.configuration.withCredentials },
    );
  }
}
