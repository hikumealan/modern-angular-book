/* tslint:disable */
/* eslint-disable */
// AUTO-GENERATED (OpenAPI Generator typescript-angular). See appendix-b-e2e-workflow.md.
import { TransactionDraft } from './transaction-draft';

export interface Transaction extends TransactionDraft {
  id: number;
}
