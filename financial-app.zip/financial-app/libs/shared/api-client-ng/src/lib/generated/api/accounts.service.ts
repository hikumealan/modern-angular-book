/* tslint:disable */
/* eslint-disable */
// AUTO-GENERATED (OpenAPI Generator typescript-angular). See appendix-b-e2e-workflow.md.
import { inject, Injectable, Optional, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import type { Account } from '../model/account';
import type { ApiError } from '../model/api-error';
import { BASE_PATH } from '../variables';
import { Configuration } from '../configuration';

export interface AccountsServiceInterface {
  listAccounts(): Observable<Array<Account>>;
  getAccount(accountId: number): Observable<Account>;
}

@Injectable({ providedIn: 'root' })
export class AccountsService implements AccountsServiceInterface {
  protected basePath = 'http://localhost:8000';
  protected defaultHeaders = new HttpHeaders();
  public configuration: Configuration;
  private http = inject(HttpClient);

  constructor(@Optional() @Inject(BASE_PATH) basePath?: string, @Optional() configuration?: Configuration) {
    this.configuration = configuration ?? new Configuration();
    this.basePath = configuration?.basePath ?? basePath ?? this.basePath;
  }

  public listAccounts(): Observable<Array<Account>> {
    const headers = this.defaultHeaders.set('Accept', 'application/json');
    return this.http.get<Array<Account>>(`${this.basePath}/api/accounts`, {
      headers,
      withCredentials: this.configuration.withCredentials,
    });
  }

  public getAccount(accountId: number): Observable<Account> {
    if (accountId == null) {
      throw new Error('Required parameter accountId was null or undefined when calling getAccount.');
    }
    const headers = this.defaultHeaders.set('Accept', 'application/json');
    return this.http.get<Account>(
      `${this.basePath}/api/accounts/${encodeURIComponent(String(accountId))}`,
      { headers, withCredentials: this.configuration.withCredentials },
    );
  }
}
