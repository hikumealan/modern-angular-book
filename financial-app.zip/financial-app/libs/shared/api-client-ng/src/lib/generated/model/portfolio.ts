/* tslint:disable */
/* eslint-disable */
// AUTO-GENERATED (OpenAPI Generator typescript-angular). See appendix-b-e2e-workflow.md.

export interface Portfolio {
  id: number;
  clientId: number;
  name: string;
  holdings?: number[];
  totalValue: number;
}
