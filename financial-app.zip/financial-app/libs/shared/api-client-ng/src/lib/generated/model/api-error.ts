/* tslint:disable */
/* eslint-disable */
// AUTO-GENERATED (OpenAPI Generator typescript-angular). See appendix-b-e2e-workflow.md.

export interface ApiError {
  code: string;
  message: string;
  details?: { [key: string]: Array<string> } | null;
}
