/* tslint:disable */
/* eslint-disable */
// AUTO-GENERATED (OpenAPI Generator typescript-angular). See appendix-b-e2e-workflow.md.
import { inject, Injectable, Optional, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import type { Transaction } from '../model/transaction';
import type { TransactionDraft } from '../model/transaction-draft';
import { BASE_PATH } from '../variables';
import { Configuration } from '../configuration';

export interface TransactionsServiceInterface {
  listTransactions(): Observable<Array<Transaction>>;
  createTransaction(body: TransactionDraft): Observable<Transaction>;
}

@Injectable({ providedIn: 'root' })
export class TransactionsService implements TransactionsServiceInterface {
  protected basePath = 'http://localhost:8000';
  protected defaultHeaders = new HttpHeaders();
  public configuration: Configuration;
  private http = inject(HttpClient);

  constructor(@Optional() @Inject(BASE_PATH) basePath?: string, @Optional() configuration?: Configuration) {
    this.configuration = configuration ?? new Configuration();
    this.basePath = configuration?.basePath ?? basePath ?? this.basePath;
  }

  public listTransactions(): Observable<Array<Transaction>> {
    const headers = this.defaultHeaders.set('Accept', 'application/json');
    return this.http.get<Array<Transaction>>(`${this.basePath}/api/transactions`, {
      headers,
      withCredentials: this.configuration.withCredentials,
    });
  }

  public createTransaction(body: TransactionDraft): Observable<Transaction> {
    if (body == null) {
      throw new Error('Required parameter body was null or undefined when calling createTransaction.');
    }
    const headers = this.defaultHeaders
      .set('Accept', 'application/json')
      .set('Content-Type', 'application/json');
    return this.http.post<Transaction>(`${this.basePath}/api/transactions`, body, {
      headers,
      withCredentials: this.configuration.withCredentials,
    });
  }
}
