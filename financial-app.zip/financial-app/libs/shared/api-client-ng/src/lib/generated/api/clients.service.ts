/* tslint:disable */
/* eslint-disable */
// AUTO-GENERATED (OpenAPI Generator typescript-angular). See appendix-b-e2e-workflow.md.
import { inject, Injectable, Optional, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import type { Client } from '../model/client';
import { BASE_PATH } from '../variables';
import { Configuration } from '../configuration';

export interface ClientsServiceInterface {
  listClients(): Observable<Array<Client>>;
  getClient(clientId: number): Observable<Client>;
}

@Injectable({ providedIn: 'root' })
export class ClientsService implements ClientsServiceInterface {
  protected basePath = 'http://localhost:8000';
  protected defaultHeaders = new HttpHeaders();
  public configuration: Configuration;
  private http = inject(HttpClient);

  constructor(@Optional() @Inject(BASE_PATH) basePath?: string, @Optional() configuration?: Configuration) {
    this.configuration = configuration ?? new Configuration();
    this.basePath = configuration?.basePath ?? basePath ?? this.basePath;
  }

  public listClients(): Observable<Array<Client>> {
    const headers = this.defaultHeaders.set('Accept', 'application/json');
    return this.http.get<Array<Client>>(`${this.basePath}/api/clients`, {
      headers,
      withCredentials: this.configuration.withCredentials,
    });
  }

  public getClient(clientId: number): Observable<Client> {
    if (clientId == null) {
      throw new Error('Required parameter clientId was null or undefined when calling getClient.');
    }
    const headers = this.defaultHeaders.set('Accept', 'application/json');
    return this.http.get<Client>(
      `${this.basePath}/api/clients/${encodeURIComponent(String(clientId))}`,
      { headers, withCredentials: this.configuration.withCredentials },
    );
  }
}
