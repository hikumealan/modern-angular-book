/* tslint:disable */
/* eslint-disable */
// AUTO-GENERATED (OpenAPI Generator typescript-angular). See appendix-b-e2e-workflow.md.

export type TransactionType = 'credit' | 'debit';
export const TransactionType = {
  Credit: 'credit' as TransactionType,
  Debit: 'debit' as TransactionType,
};

export interface TransactionDraft {
  accountId: number;
  amount: number;
  type: TransactionType;
  category: string;
  date: string;
  description?: string | null;
  pending?: boolean;
}
