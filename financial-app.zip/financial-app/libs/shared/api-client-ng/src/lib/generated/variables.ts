/* tslint:disable */
/* eslint-disable */
// AUTO-GENERATED (OpenAPI Generator typescript-angular). See appendix-b-e2e-workflow.md.
import { InjectionToken } from '@angular/core';

export const BASE_PATH = new InjectionToken<string>('basePath');
export const COLLECTION_FORMATS = {
  csv: ',',
  tsv: '   ',
  ssv: ' ',
  pipes: '|',
};
