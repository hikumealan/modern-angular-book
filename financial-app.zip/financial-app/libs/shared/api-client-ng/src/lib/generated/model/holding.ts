/* tslint:disable */
/* eslint-disable */
// AUTO-GENERATED (OpenAPI Generator typescript-angular). See appendix-b-e2e-workflow.md.

export interface Holding {
  id: number;
  portfolioId: number;
  ticker: string;
  shares: number;
  purchasePrice: number;
  currentPrice: number;
}
