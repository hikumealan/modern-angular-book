// See ch52-appendix-b0-backend-fastapi.md -- "Strategy D: generated service unit tests"
//
// Verifies the Strategy D generated AccountsService hits the expected URL,
// deserializes responses into the declared model interface, and that the
// deserialized value passes the Strategy-A-generated Zod schema (hybrid
// D+A runtime validation).
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting,
} from '@angular/common/http/testing';
import { describe, it, expect, beforeEach, afterEach } from 'vitest';

import { AccountsService } from './generated/api/accounts.service';
import { Configuration } from './generated/configuration';
import { Account } from '@financial-app/shared/api-client/generated/generated-zodios';
import { makeAccount } from '@financial-app/shared/testing';

describe('AccountsService (generated)', () => {
  let service: AccountsService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        {
          provide: Configuration,
          useValue: new Configuration({ basePath: 'http://localhost:8000' }),
        },
        AccountsService,
      ],
    });
    service = TestBed.inject(AccountsService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('listAccounts calls GET /api/accounts and validates each row', () => {
    const payload = [makeAccount(), makeAccount({ type: 'savings' })];

    let result: ReadonlyArray<unknown> = [];
    service.listAccounts().subscribe((rows) => (result = rows));

    const req = http.expectOne('http://localhost:8000/api/accounts');
    expect(req.request.method).toBe('GET');
    req.flush(payload);

    expect(result).toHaveLength(2);
    for (const row of result) {
      expect(Account.safeParse(row).success).toBe(true);
    }
  });

  it('getAccount calls GET /api/accounts/:id with encoded id', () => {
    const payload = makeAccount({ id: 42 });

    let result: unknown;
    service.getAccount(42).subscribe((v) => (result = v));

    const req = http.expectOne('http://localhost:8000/api/accounts/42');
    expect(req.request.method).toBe('GET');
    req.flush(payload);

    expect(Account.safeParse(result).success).toBe(true);
  });

  it('getAccount throws synchronously when id is null', () => {
    expect(() => service.getAccount(null as unknown as number).subscribe()).toThrow(
      /Required parameter accountId/,
    );
  });
});
