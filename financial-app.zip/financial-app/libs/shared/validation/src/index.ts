// Ch 31 – Validation schemas
export { TransactionSchema, type Transaction } from './transaction.schema';
