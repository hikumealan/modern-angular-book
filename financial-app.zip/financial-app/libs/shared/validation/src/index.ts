// See ch27-advanced-typescript-openapi.md and ch52-appendix-b0-backend-fastapi.md
export { TransactionSchema, type Transaction } from './transaction.schema';
export {
  transactionEntrySchema,
  type TransactionEntryDraft,
} from './transaction-entry.schema';
