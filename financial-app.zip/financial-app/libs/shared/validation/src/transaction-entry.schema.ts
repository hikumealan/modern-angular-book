// See ch52-appendix-b0-backend-fastapi.md -- "Extending a Generated Schema with UX Rules"
//
// Demonstrates the canonical pattern for adding UX-only validation on top
// of a generator-produced Zod schema: import the generated schema as the
// structural source of truth, extend it with UI-specific fields or
// refinements, and export the composed schema for Signal Forms to consume.
//
// The generated `transactionDraftSchema` is regenerated from the backend
// on every run of `npm run generate:datamodel`. This file does not need
// to be regenerated; the `refine()` rule and the `confirmAmount` field
// live in application code because they only matter at the form layer.

import { z } from 'zod';
import { transactionDraftSchema } from '@financial-app/shared/api-client/generated/generated.zod';

/**
 * Signal Form schema for the transaction-entry screen.
 *
 * Wraps the generated `transactionDraftSchema` (the single source of
 * truth for accepted transaction payloads) with two UX-only concerns:
 *
 * - A `confirmAmount` field that only exists in the form and is stripped
 *   before the payload is posted. Guards against typo-level errors in
 *   large transfers.
 * - A `.refine()` that rejects submissions where `amount !== confirmAmount`.
 *
 * Neither addition leaks into the backend contract. The server never
 * sees `confirmAmount`, and regenerating the Zod schema from the
 * backend does not overwrite or remove this file.
 */
export const transactionEntrySchema = transactionDraftSchema
  .extend({
    confirmAmount: z.number().gt(0, 'Confirmation amount is required'),
  })
  .refine((draft) => draft.amount === draft.confirmAmount, {
    message: 'Confirmation amount must match the entered amount',
    path: ['confirmAmount'],
  });

export type TransactionEntryDraft = z.infer<typeof transactionEntrySchema>;
