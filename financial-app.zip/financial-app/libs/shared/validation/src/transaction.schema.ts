// Ch 31 – Zod schema for Transaction
import { z } from 'zod';

export const TransactionSchema = z.object({
  id: z.string().uuid(),
  date: z.coerce.date(),
  description: z.string().min(1).max(255),
  amount: z.number().finite(),
  currency: z.string().length(3),
  category: z.string().min(1),
  accountId: z.string().uuid(),
  type: z.enum(['credit', 'debit']),
  status: z.enum(['pending', 'posted', 'failed']).default('pending'),
  metadata: z.record(z.unknown()).optional(),
});

export type Transaction = z.infer<typeof TransactionSchema>;
