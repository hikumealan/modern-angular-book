// See ch20-observability.md -- "Correlation IDs across the stack"
import { HttpInterceptorFn } from '@angular/common/http';
import { getCorrelationId } from './correlation-id';

export const correlationInterceptor: HttpInterceptorFn = (req, next) => {
  const withHeader = req.clone({
    setHeaders: { 'X-Correlation-Id': getCorrelationId() },
  });
  return next(withHeader);
};
