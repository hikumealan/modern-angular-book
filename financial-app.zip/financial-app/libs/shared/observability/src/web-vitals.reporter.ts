// See ch20-observability.md -- "Core Web Vitals"
import { onCLS, onFCP, onINP, onLCP, onTTFB, type Metric } from 'web-vitals';
import { TelemetryService } from './telemetry.service';

export function reportWebVitals(service: TelemetryService): void {
  const forward = (metric: Metric): void => {
    service.trackEvent(`web-vital:${metric.name}`, {
      value: metric.value,
      rating: metric.rating,
    });
  };

  onLCP(forward);
  onINP(forward);
  onCLS(forward);
  onFCP(forward);
  onTTFB(forward);
}
