// See ch42-observability.md -- "A signal-based telemetry service"
import { Injectable, signal, type Signal } from '@angular/core';

type Properties = Record<string, unknown>;

// Allow-list of keys we consider safe to log. Anything else is dropped
// to keep PII (email, name, account numbers, etc.) out of telemetry.
const SAFE_KEYS: ReadonlySet<string> = new Set([
  'route',
  'feature',
  'action',
  'durationMs',
  'status',
  'variant',
  'value',
  'rating',
  'name',
  'category',
]);

@Injectable({ providedIn: 'root' })
export class TelemetryService {
  private readonly userId = signal<string | null>(null);

  readonly currentUser: Signal<string | null> = this.userId.asReadonly();

  trackEvent(name: string, properties?: Properties): void {
    const safe = properties ? this.scrub(properties) : undefined;
    // Replace with Sentry / OpenTelemetry / Application Insights in production.
    console.log('[telemetry]', name, safe);
  }

  trackError(error: unknown, context?: Properties): void {
    const safe = context ? this.scrub(context) : undefined;
    // Replace with Sentry.captureException(error, { extra: safe }) in production.
    console.error('[telemetry:error]', error, safe);
  }

  setUser(userId: string | null): void {
    // Callers must pass an opaque, hashed identifier -- never email or name.
    this.userId.set(userId);
  }

  private scrub(props: Properties): Properties {
    const out: Properties = {};
    for (const [key, value] of Object.entries(props)) {
      if (SAFE_KEYS.has(key)) {
        out[key] = value;
      }
    }
    return out;
  }
}
