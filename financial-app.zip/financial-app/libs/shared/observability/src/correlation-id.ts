// See ch42-observability.md -- "Correlation IDs across the stack"
const STORAGE_KEY = 'fin.correlation-id';

export function getCorrelationId(): string {
  const existing = sessionStorage.getItem(STORAGE_KEY);
  if (existing) {
    return existing;
  }
  const id = crypto.randomUUID();
  sessionStorage.setItem(STORAGE_KEY, id);
  return id;
}
