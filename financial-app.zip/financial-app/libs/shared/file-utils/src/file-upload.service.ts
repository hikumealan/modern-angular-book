// See ch34-file-handling.md
import { Injectable, inject, signal, type Signal } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpEventType,
  type HttpEvent,
} from '@angular/common/http';
import { catchError, EMPTY } from 'rxjs';

export interface UploadHandle<T> {
  progress: Signal<number>;
  response: Signal<T | null>;
  error: Signal<HttpErrorResponse | null>;
}

@Injectable({ providedIn: 'root' })
export class FileUploadService {
  private readonly http = inject(HttpClient);

  upload<T>(url: string, file: File): UploadHandle<T> {
    const progress = signal(0);
    const response = signal<T | null>(null);
    const error = signal<HttpErrorResponse | null>(null);

    const form = new FormData();
    form.append('file', file, file.name);

    this.http
      .post<T>(url, form, { reportProgress: true, observe: 'events' })
      .pipe(
        catchError((err: HttpErrorResponse) => {
          error.set(err);
          return EMPTY;
        }),
      )
      .subscribe((event: HttpEvent<T>) => {
        if (event.type === HttpEventType.UploadProgress && event.total) {
          progress.set(Math.round((100 * event.loaded) / event.total));
        } else if (event.type === HttpEventType.Response) {
          progress.set(100);
          response.set(event.body);
        }
      });

    return {
      progress: progress.asReadonly(),
      response: response.asReadonly(),
      error: error.asReadonly(),
    };
  }
}
