// See ch29-file-handling.md
import { Injectable } from '@angular/core';

export interface CsvColumn<T> {
  key: keyof T & string;
  label: string;
}

@Injectable({ providedIn: 'root' })
export class CsvExportService {
  export<T extends Record<string, unknown>>(
    rows: readonly T[],
    columns: readonly CsvColumn<T>[],
    filename: string,
  ): void {
    const csv = this.toCsv(rows, columns);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    this.triggerDownload(blob, filename);
  }

  toCsv<T extends Record<string, unknown>>(
    rows: readonly T[],
    columns: readonly CsvColumn<T>[],
  ): string {
    const header = columns.map((c) => this.escape(c.label)).join(',');
    const body = rows
      .map((row) =>
        columns.map((c) => this.escape(this.stringify(row[c.key]))).join(','),
      )
      .join('\r\n');
    return body ? `${header}\r\n${body}` : header;
  }

  private stringify(value: unknown): string {
    if (value === null || value === undefined) return '';
    if (value instanceof Date) return value.toISOString();
    return String(value);
  }

  // RFC 4180-style escaping: wrap in quotes if the value contains a comma,
  // quote, or newline; double any embedded quotes.
  private escape(value: string): string {
    if (/[",\r\n]/.test(value)) {
      return `"${value.replace(/"/g, '""')}"`;
    }
    return value;
  }

  private triggerDownload(blob: Blob, filename: string): void {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
  }
}
