// See ch29-file-handling.md
import { Injectable } from '@angular/core';

export interface StatementAccount {
  id: string | number;
  name: string;
  balance: number;
}

export interface StatementTransaction {
  date: string | Date;
  description: string;
  amount: number;
}

export interface StatementDateRange {
  from: Date;
  to: Date;
}

@Injectable({ providedIn: 'root' })
export class PdfStatementService {
  // Stub implementation. A real build would use `pdf-lib` (or similar) to
  // compose a true PDF document with typography, tables, and a logo. For
  // now we emit a plain-text blob so downstream flows can wire up download
  // and upload paths without pulling in the full dependency.
  async generate(
    account: StatementAccount,
    transactions: readonly StatementTransaction[],
    dateRange: StatementDateRange,
  ): Promise<Blob> {
    const lines: string[] = [
      `Statement for ${account.name} (#${account.id})`,
      `Period: ${this.formatDate(dateRange.from)} -> ${this.formatDate(dateRange.to)}`,
      `Balance: ${account.balance.toFixed(2)}`,
      '',
      'Date            Description                         Amount',
      '------------------------------------------------------------',
    ];

    for (const tx of transactions) {
      const date = this.formatDate(tx.date);
      const desc = tx.description.padEnd(35, ' ').slice(0, 35);
      const amount = tx.amount.toFixed(2).padStart(10, ' ');
      lines.push(`${date}  ${desc}  ${amount}`);
    }

    return new Blob([lines.join('\n')], { type: 'text/plain' });
  }

  private formatDate(value: string | Date): string {
    const d = value instanceof Date ? value : new Date(value);
    return d.toISOString().slice(0, 10);
  }
}
