// See ch35-charts.md
export interface AllocationSlice {
  label: string;
  value: number;
  color?: string;
}
