// See ch30-charts.md
export interface AllocationSlice {
  label: string;
  value: number;
  color?: string;
}
