// See ch30-charts.md
export { FinAllocationChartComponent } from './fin-allocation-chart/fin-allocation-chart.component';
export type { AllocationSlice } from './types';
