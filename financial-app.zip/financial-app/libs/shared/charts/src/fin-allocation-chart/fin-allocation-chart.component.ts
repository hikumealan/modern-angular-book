// See ch30-charts.md -- a real implementation would wrap apexcharts.
// This self-contained SVG donut keeps the library dependency-free and
// demonstrates the Ch 32 accessibility pattern: role="img" plus a
// visually-hidden data table fallback for screen readers.
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  input,
} from '@angular/core';
import { DecimalPipe, PercentPipe } from '@angular/common';
import type { AllocationSlice } from '../types';

interface ArcSegment {
  readonly label: string;
  readonly value: number;
  readonly color: string;
  readonly path: string;
  readonly fraction: number;
}

const DEFAULT_PALETTE = [
  '#2563eb',
  '#16a34a',
  '#f59e0b',
  '#dc2626',
  '#9333ea',
  '#0891b2',
  '#db2777',
  '#65a30d',
];

@Component({
  selector: 'fin-allocation-chart',
  standalone: true,
  imports: [DecimalPipe, PercentPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrl: './fin-allocation-chart.component.scss',
  template: `
    <svg
      class="fin-allocation-chart__svg"
      [attr.viewBox]="viewBox"
      role="img"
      [attr.aria-label]="ariaLabel()"
    >
      @for (segment of segments(); track segment.label) {
        <path [attr.d]="segment.path" [attr.fill]="segment.color" aria-hidden="true">
          <title>{{ segment.label }}: {{ segment.fraction | percent: '1.0-1' }}</title>
        </path>
      }
    </svg>

    <table class="fin-allocation-chart__sr-only">
      <caption>{{ ariaLabel() }}</caption>
      <thead>
        <tr>
          <th scope="col">Category</th>
          <th scope="col">Value</th>
          <th scope="col">Share</th>
        </tr>
      </thead>
      <tbody>
        @for (segment of segments(); track segment.label) {
          <tr>
            <th scope="row">{{ segment.label }}</th>
            <td>{{ segment.value | number: '1.0-2' }}</td>
            <td>{{ segment.fraction | percent: '1.0-1' }}</td>
          </tr>
        }
      </tbody>
    </table>
  `,
})
export class FinAllocationChartComponent {
  slices = input.required<AllocationSlice[]>();
  ariaLabel = input<string>('Allocation chart');

  protected readonly viewBox = '0 0 100 100';
  protected readonly outerRadius = 45;
  protected readonly innerRadius = 28;

  protected readonly total = computed(() =>
    this.slices().reduce((sum, s) => sum + Math.max(0, s.value), 0),
  );

  protected readonly segments = computed<ArcSegment[]>(() => {
    const total = this.total();
    if (total <= 0) return [];

    let startAngle = 0;
    return this.slices().map((slice, i) => {
      const fraction = Math.max(0, slice.value) / total;
      const endAngle = startAngle + fraction * 2 * Math.PI;
      const path = this.describeArc(startAngle, endAngle, fraction);
      const segment: ArcSegment = {
        label: slice.label,
        value: slice.value,
        color: slice.color ?? DEFAULT_PALETTE[i % DEFAULT_PALETTE.length],
        path,
        fraction,
      };
      startAngle = endAngle;
      return segment;
    });
  });

  private describeArc(
    startAngle: number,
    endAngle: number,
    fraction: number,
  ): string {
    const cx = 50;
    const cy = 50;
    const ro = this.outerRadius;
    const ri = this.innerRadius;

    if (fraction >= 1) {
      return [
        `M ${cx - ro} ${cy}`,
        `A ${ro} ${ro} 0 1 1 ${cx + ro} ${cy}`,
        `A ${ro} ${ro} 0 1 1 ${cx - ro} ${cy}`,
        `M ${cx - ri} ${cy}`,
        `A ${ri} ${ri} 0 1 0 ${cx + ri} ${cy}`,
        `A ${ri} ${ri} 0 1 0 ${cx - ri} ${cy}`,
        'Z',
      ].join(' ');
    }

    const largeArc = endAngle - startAngle > Math.PI ? 1 : 0;
    const outerStart = this.polar(cx, cy, ro, startAngle);
    const outerEnd = this.polar(cx, cy, ro, endAngle);
    const innerEnd = this.polar(cx, cy, ri, endAngle);
    const innerStart = this.polar(cx, cy, ri, startAngle);

    return [
      `M ${outerStart.x} ${outerStart.y}`,
      `A ${ro} ${ro} 0 ${largeArc} 1 ${outerEnd.x} ${outerEnd.y}`,
      `L ${innerEnd.x} ${innerEnd.y}`,
      `A ${ri} ${ri} 0 ${largeArc} 0 ${innerStart.x} ${innerStart.y}`,
      'Z',
    ].join(' ');
  }

  private polar(cx: number, cy: number, r: number, angle: number) {
    // SVG is y-down and angles start at 12 o'clock, so shift by -PI/2.
    const a = angle - Math.PI / 2;
    return { x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) };
  }
}
