// See ch33-websockets-realtime.md
import { DestroyRef, Injectable, inject, signal, type Signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Subject, retry, timer } from 'rxjs';
import { webSocket, type WebSocketSubject } from 'rxjs/webSocket';

export type ConnectionStatus = 'disconnected' | 'connecting' | 'connected';

interface PriceMessage {
  ticker: string;
  price: number;
}

@Injectable({ providedIn: 'root' })
export class PriceStreamService {
  private readonly destroyRef = inject(DestroyRef);

  private readonly _status = signal<ConnectionStatus>('disconnected');
  private readonly _prices = signal<Map<string, number>>(new Map());

  readonly status: Signal<ConnectionStatus> = this._status.asReadonly();
  readonly prices: Signal<Map<string, number>> = this._prices.asReadonly();

  private socket: WebSocketSubject<PriceMessage> | null = null;
  private readonly closeSignal = new Subject<void>();

  connect(url: string): void {
    this.disconnect();
    this._status.set('connecting');

    this.socket = webSocket<PriceMessage>({
      url,
      openObserver: { next: () => this._status.set('connected') },
      closeObserver: { next: () => this._status.set('disconnected') },
    });

    this.socket
      .pipe(
        retry({
          delay: (_error, retryCount) => {
            this._status.set('connecting');
            return timer(Math.min(30_000, 1000 * 2 ** retryCount));
          },
        }),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe({
        next: (msg) => {
          const next = new Map(this._prices());
          next.set(msg.ticker, msg.price);
          this._prices.set(next);
        },
        error: () => this._status.set('disconnected'),
      });
  }

  disconnect(): void {
    this.socket?.complete();
    this.socket = null;
    this.closeSignal.next();
    this._status.set('disconnected');
  }
}
