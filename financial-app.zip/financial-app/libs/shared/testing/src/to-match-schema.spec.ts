// See ch52-appendix-b0-backend-fastapi.md -- "Schema-backed response assertions"
import { describe, it, expect } from 'vitest';
import { Account } from '@financial-app/shared/api-client/generated/generated-zodios';
import './to-match-schema';
import { makeAccount } from './factories';

describe('toMatchSchema custom matcher', () => {
  it('passes when value matches schema', () => {
    expect(makeAccount()).toMatchSchema(Account);
  });

  it('fails with a readable message when the value diverges from the schema', () => {
    const invalid = { id: 'not-a-number', name: '', type: 'unknown' };
    expect(() => expect(invalid).toMatchSchema(Account)).toThrowError(/schema mismatch/);
  });
});
