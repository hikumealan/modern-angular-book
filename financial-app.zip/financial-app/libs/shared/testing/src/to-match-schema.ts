// See appendix-b-e2e-workflow.md -- "Schema-backed response assertions"
import { expect } from 'vitest';
import type { ZodIssue, ZodType } from 'zod';

/**
 * Register the `toMatchSchema` Vitest matcher globally.
 *
 * Usage:
 *   import '@financial-app/shared/testing';
 *   // or import { registerSchemaMatcher } from '@financial-app/shared/testing';
 *
 *   expect(value).toMatchSchema(AccountSchema);
 *
 * Failure output shows each Zod issue as `path: message`, which is
 * considerably more readable than a nested `safeParse` result dump.
 */
export function registerSchemaMatcher(): void {
  expect.extend({
    toMatchSchema(received: unknown, schema: ZodType) {
      const result = schema.safeParse(received);
      if (result.success) {
        return {
          pass: true,
          message: () => 'expected value NOT to match schema, but it did',
        };
      }
      const issues = result.error.issues
        .map((issue: ZodIssue) => `  - ${issue.path.join('.') || '<root>'}: ${issue.message}`)
        .join('\n');
      return {
        pass: false,
        message: () => `schema mismatch:\n${issues}`,
      };
    },
  });
}

declare module 'vitest' {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  interface Assertion<T> {
    toMatchSchema(schema: ZodType): void;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  interface AsymmetricMatchersContaining {
    toMatchSchema(schema: ZodType): void;
  }
}

// Register on import so consumers can just `import '@financial-app/shared/testing'`
// in their Vitest setup file.
registerSchemaMatcher();
