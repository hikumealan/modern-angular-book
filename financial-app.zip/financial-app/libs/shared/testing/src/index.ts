// See appendix-b-e2e-workflow.md -- "Shared Testing Library"
//
// Public barrel for schema-driven test helpers. Everything exported
// here is built on top of the generated artifact modules
// (@financial-app/shared/api-client/generated,
//  @financial-app/shared/api-client-ng). Regenerating those artifacts
// automatically updates the fixtures these helpers produce -- tests
// using them cannot drift from the contract.
export * from './to-match-schema';
export * from './factories';
export * from './msw-handlers';
export * from './playwright-fixture';
