// See ch52-appendix-b0-backend-fastapi.md -- "Generated test-data factories with zod-mock"
//
// Type-safe fixture factories derived from the Strategy A generated Zod
// schemas. Every factory produces data that passes the same schema used
// at runtime, so tests cannot accidentally lie about the contract.
import { generateMock } from '@anatine/zod-mock';
import {
  Account,
  Client,
  Holding,
  Portfolio,
  Transaction,
  TransactionDraft,
} from '@financial-app/shared/api-client/generated/generated-zodios';
import type {
  Account as AccountT,
  Client as ClientT,
  Holding as HoldingT,
  Portfolio as PortfolioT,
  Transaction as TransactionT,
  TransactionDraft as TransactionDraftT,
} from '@financial-app/shared/api-client/generated/generated-zodios';

export const makeAccount = (overrides: Partial<AccountT> = {}): AccountT => ({
  ...generateMock(Account),
  ...overrides,
});

export const makeTransactionDraft = (
  overrides: Partial<TransactionDraftT> = {},
): TransactionDraftT => ({
  ...generateMock(TransactionDraft),
  ...overrides,
});

export const makeTransaction = (overrides: Partial<TransactionT> = {}): TransactionT => ({
  ...generateMock(Transaction),
  ...overrides,
});

export const makeClient = (overrides: Partial<ClientT> = {}): ClientT => ({
  ...generateMock(Client),
  ...overrides,
});

export const makeHolding = (overrides: Partial<HoldingT> = {}): HoldingT => ({
  ...generateMock(Holding),
  ...overrides,
});

export const makePortfolio = (overrides: Partial<PortfolioT> = {}): PortfolioT => ({
  ...generateMock(Portfolio),
  ...overrides,
});
