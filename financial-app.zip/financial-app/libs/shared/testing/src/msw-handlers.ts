// See appendix-b-e2e-workflow.md -- "MSW handlers derived from the spec (scoped)"
//
// Scope: 200-response GET operations only. Stateful handlers (POST-then-GET),
// error variants, and path-parameter-specific responses remain hand-authored.
// For full coverage of an OpenAPI spec including POST/PUT/DELETE, errors,
// and delays, see https://github.com/zoubingwu/msw-auto-mock.
import { http, HttpResponse } from 'msw';
import { generateMock } from '@anatine/zod-mock';
import type { ZodType } from 'zod';
import {
  Account,
  Client,
  Holding,
  Portfolio,
  Transaction,
} from '@financial-app/shared/api-client/generated/generated-zodios';

/**
 * Map each GET endpoint to its response schema. Regenerating the
 * Strategy A artifacts updates the imported schemas automatically.
 */
const GET_ROUTES: Array<{ path: string; schema: ZodType }> = [
  { path: '/api/accounts', schema: Account.array() },
  { path: '/api/accounts/:account_id', schema: Account },
  { path: '/api/transactions', schema: Transaction.array() },
  { path: '/api/clients', schema: Client },
  { path: '/api/clients/:client_id', schema: Client },
  { path: '/api/portfolios', schema: Portfolio.array() },
  { path: '/api/portfolios/:portfolio_id/holdings', schema: Holding.array() },
];

/**
 * Builds an MSW handler array covering the 200-response GET endpoints
 * of the FinancialApp contract. Use as the baseline for component
 * tests; layer POST/PUT/DELETE and error handlers on top as needed.
 */
export function mswHandlersFromSpec(origin = '') {
  return GET_ROUTES.map(({ path, schema }) =>
    http.get(`${origin}${path}`, () => HttpResponse.json(generateMock(schema))),
  );
}
