// See appendix-b-e2e-workflow.md -- "Shared Testing Library"
//
// Playwright fixture exposing a schema-validating `apiRequest` helper.
// Use via `test.extend(contractFixture)` in Playwright specs. The
// fixture wraps the raw `request` object so every response is
// `safeParse`d against the generated Zod schema before the test sees it.
//
// Importing `@playwright/test` directly from this library keeps the
// dependency scoped to `type:testing` projects (enforced by Sheriff).
// Production code never imports from this module.
import type { APIRequestContext, APIResponse } from '@playwright/test';
import { test as base } from '@playwright/test';
import type { ZodType } from 'zod';

export interface ContractRequest {
  /**
   * GET + safeParse. Returns the validated body, or throws with a
   * descriptive error if the real backend response doesn't match the
   * generated schema. This is the "catch-all" safety net for drift
   * that slipped past CI's regeneration gate.
   */
  getAndValidate<T>(url: string, schema: ZodType<T>): Promise<T>;

  /** Raw request access; prefer `getAndValidate` when a schema exists. */
  raw: APIRequestContext;
}

function buildContractRequest(request: APIRequestContext): ContractRequest {
  return {
    raw: request,
    async getAndValidate<T>(url: string, schema: ZodType<T>): Promise<T> {
      const response: APIResponse = await request.get(url);
      if (!response.ok()) {
        throw new Error(`Contract request ${url} failed: ${response.status()}`);
      }
      const body: unknown = await response.json();
      const parsed = schema.safeParse(body);
      if (!parsed.success) {
        const issues = parsed.error.issues
          .map((i) => `  - ${i.path.join('.')}: ${i.message}`)
          .join('\n');
        throw new Error(`Contract mismatch at ${url}:\n${issues}`);
      }
      return parsed.data;
    },
  };
}

export const test = base.extend<{ contract: ContractRequest }>({
  contract: async ({ request }, use) => {
    await use(buildContractRequest(request));
  },
});

export { expect } from '@playwright/test';
