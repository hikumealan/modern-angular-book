// See appendix-b-e2e-workflow.md -- "Generated test-data factories with zod-mock"
import { describe, it, expect } from 'vitest';
import {
  Account,
  Client,
  Holding,
  Portfolio,
  Transaction,
  TransactionDraft,
} from '@financial-app/shared/api-client/generated/generated-zodios';
import { makeAccount, makeClient, makeHolding, makePortfolio, makeTransaction, makeTransactionDraft } from './factories';

describe('testing factories', () => {
  it.each([
    ['makeAccount', makeAccount, Account],
    ['makeTransactionDraft', makeTransactionDraft, TransactionDraft],
    ['makeTransaction', makeTransaction, Transaction],
    ['makeClient', makeClient, Client],
    ['makeHolding', makeHolding, Holding],
    ['makePortfolio', makePortfolio, Portfolio],
  ] as const)('%s produces data that matches its schema', (_name, factory, schema) => {
    const value = factory();
    const parsed = schema.safeParse(value);
    expect(parsed.success).toBe(true);
  });

  it('accepts overrides without invalidating the schema', () => {
    const account = makeAccount({ name: 'Override', currency: 'EUR' });
    expect(account.name).toBe('Override');
    expect(account.currency).toBe('EUR');
    expect(Account.safeParse(account).success).toBe(true);
  });
});
