// Ch 21 – CSP violation listener
import { ErrorHandler, Injectable, NgZone, OnDestroy } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class CspViolationReporter implements OnDestroy {
  private readonly handler: (e: SecurityPolicyViolationEvent) => void;

  constructor(
    private errorHandler: ErrorHandler,
    private zone: NgZone,
  ) {
    this.handler = (event: SecurityPolicyViolationEvent) => {
      this.zone.run(() => {
        this.errorHandler.handleError(new Error(
          `CSP violation: ${event.violatedDirective} — blocked "${event.blockedURI}" ` +
          `(source: ${event.sourceFile}:${event.lineNumber})`,
        ));
      });
    };
    document.addEventListener('securitypolicyviolation', this.handler);
  }

  ngOnDestroy(): void {
    document.removeEventListener('securitypolicyviolation', this.handler);
  }
}
