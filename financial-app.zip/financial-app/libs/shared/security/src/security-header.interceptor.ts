// Ch 21 – HttpInterceptorFn adding security headers
import { HttpInterceptorFn } from '@angular/common/http';

export const securityHeaderInterceptor: HttpInterceptorFn = (req, next) => {
  const secured = req.clone({
    setHeaders: {
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      'X-XSS-Protection': '1; mode=block',
      'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
    },
  });
  return next(secured);
};
