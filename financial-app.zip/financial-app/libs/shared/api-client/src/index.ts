// See appendix-b-e2e-workflow.md -- "Strategy A" and "Strategy C"
//
// Barrel for the api-client library. This library hosts the output of
// Strategy A (openapi-zod-client -> Zodios + Zod) and Strategy C
// (datamodel-code-generator + ts-to-zod). The outputs are regenerated
// from openapi.json by:
//   npm run generate:zod-client   # Strategy A
//   npm run generate:datamodel    # Strategy C
//
// Do not hand-edit files under `./generated/`.
export * from './generated/generated-zodios';
