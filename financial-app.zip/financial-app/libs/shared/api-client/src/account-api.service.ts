// See ch27-advanced-typescript-openapi.md
// Thin Angular wrapper around the `openapi-fetch` typed client. The full
// `paths` interface is emitted by `openapi-typescript` from openapi.json;
// here we declare just the subset this stub exercises so the file type-
// checks without requiring a regenerated schema.ts.
import { Injectable, Injector, inject } from '@angular/core';
import { httpResource } from '@angular/common/http';
import createClient from 'openapi-fetch';

import type { Account } from '@financial-app/shared/models';
import type { AccountId } from '@financial-app/shared/models';

interface Paths {
  '/api/accounts/{id}': {
    get: {
      parameters: { path: { id: AccountId } };
      responses: { 200: { content: { 'application/json': Account } } };
    };
  };
}

@Injectable({ providedIn: 'root' })
export class AccountApiService {
  private readonly client = createClient<Paths>({ baseUrl: '' });
  private readonly injector = inject(Injector);

  readonly accounts = httpResource<Account[]>(() => '/api/accounts', {
    injector: this.injector,
    defaultValue: [] as Account[],
  });

  async getById(id: AccountId): Promise<Account> {
    const { data, error } = await this.client.GET('/api/accounts/{id}', {
      params: { path: { id } },
    });
    if (error || !data) throw new Error('Failed to fetch account');
    return data;
  }
}
