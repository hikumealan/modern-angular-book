// See ch17-auth-patterns.md -- client-side bearer-token interceptor.
//
// Attaches `Authorization: Bearer <token>` to outgoing API calls when the
// OauthService has a token. Requests to non-API URLs, and requests issued
// before the user authenticates, pass through unchanged.

import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { OauthService } from './oauth.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const oauth = inject(OauthService);
  const token = oauth.accessToken();

  if (!token || !req.url.startsWith('/api')) {
    return next(req);
  }

  return next(
    req.clone({
      setHeaders: { Authorization: `Bearer ${token}` },
    }),
  );
};
