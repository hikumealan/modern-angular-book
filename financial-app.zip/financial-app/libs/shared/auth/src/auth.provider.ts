// See ch48-di-deep-dive.md
// `useExisting` example -- a concrete class is aliased to an
// interface-typed token so the rest of the app depends on the contract,
// not the implementation.
import { InjectionToken, Injectable, Provider, signal } from '@angular/core';

export interface AuthClient {
  readonly accessToken: () => string | null;
  login(credentials: { username: string; password: string }): Promise<void>;
  logout(): Promise<void>;
}

export const AUTH_CLIENT = new InjectionToken<AuthClient>('AUTH_CLIENT');

@Injectable({ providedIn: 'root' })
export class OAuthAuthService implements AuthClient {
  private readonly token = signal<string | null>(null);

  accessToken = (): string | null => this.token();

  async login(_credentials: {
    username: string;
    password: string;
  }): Promise<void> {
    this.token.set('stub-access-token');
  }

  async logout(): Promise<void> {
    this.token.set(null);
  }
}

export const authClientProviders: Provider[] = [
  OAuthAuthService,
  { provide: AUTH_CLIENT, useExisting: OAuthAuthService },
];
