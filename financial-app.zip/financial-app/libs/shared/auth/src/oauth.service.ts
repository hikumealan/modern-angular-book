// See ch17-auth-patterns.md -- SSO-aware OAuth service stub.
//
// Illustrative stand-in for a production auth library (Auth0, Okta, or the
// Backend-for-Frontend pattern the chapter recommends). The public surface --
// an access-token signal, an `isAuthenticated` computed, and login/logout --
// is the minimum the rest of FinancialApp depends on.

import { Injectable, computed, signal } from '@angular/core';

export interface SsoProfile {
  readonly subject: string;
  readonly email?: string;
  readonly idp?: 'okta' | 'azure-ad' | 'google' | 'stub';
}

@Injectable({ providedIn: 'root' })
export class OauthService {
  private readonly token = signal<string | null>(null);
  private readonly profile = signal<SsoProfile | null>(null);

  readonly accessToken = this.token.asReadonly();
  readonly currentUser = this.profile.asReadonly();
  readonly isAuthenticated = computed(() => this.token() !== null);

  login(profile: SsoProfile, token: string): void {
    this.profile.set(profile);
    this.token.set(token);
  }

  logout(): void {
    this.profile.set(null);
    this.token.set(null);
  }
}
