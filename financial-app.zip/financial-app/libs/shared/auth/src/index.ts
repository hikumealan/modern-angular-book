// See ch17-auth-patterns.md
export { authInterceptor } from './auth.interceptor';
export { OauthService, type SsoProfile } from './oauth.service';
