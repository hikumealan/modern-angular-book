// See ch48-di-deep-dive.md
// Cross-MFE shared-auth bridge. The shell bootstraps first, constructs
// the real `AuthService`, and publishes it on `window`. Each MFE factories
// the shared instance in via `SHARED_AUTH`. The DI trees remain isolated
// -- only this one token crosses the boundary.
import { InjectionToken, Provider, Signal } from '@angular/core';

export interface User {
  readonly id: string;
  readonly email: string;
}

export interface Credentials {
  readonly username: string;
  readonly password: string;
}

export interface SharedAuthApi {
  readonly user: Signal<User | null>;
  readonly token: Signal<string | null>;
  signIn(credentials: Credentials): Promise<void>;
  signOut(): Promise<void>;
}

export const SHARED_AUTH = new InjectionToken<SharedAuthApi>('SHARED_AUTH');

declare global {
  interface Window {
    __financialAppAuth?: SharedAuthApi;
  }
}

export function provideSharedAuth(): Provider {
  return {
    provide: SHARED_AUTH,
    useFactory: (): SharedAuthApi => {
      const shared = window.__financialAppAuth;
      if (!shared) {
        throw new Error(
          'Shared auth not installed. Shell must bootstrap first.',
        );
      }
      return shared;
    },
  };
}
