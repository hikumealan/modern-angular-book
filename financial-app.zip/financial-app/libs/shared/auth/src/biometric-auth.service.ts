// See ch41-capacitor-mobile.md
// Capacitor biometric wrapper. The real implementation delegates to
// `@capacitor-community/biometric-auth` and `@capacitor/preferences`;
// those are native-only dev dependencies and stubbed here via `declare`
// so the rest of the app compiles cleanly on web and CI where the
// plugins are unavailable.
import { Injectable, inject, signal } from '@angular/core';

const REFRESH_TOKEN_KEY = 'fa.refresh_token';

declare const BiometricAuth: {
  checkBiometry(): Promise<{ isAvailable: boolean }>;
  authenticate(opts: { reason: string }): Promise<void>;
} | undefined;

declare const Preferences: {
  get(o: { key: string }): Promise<{ value: string | null }>;
  set(o: { key: string; value: string }): Promise<void>;
} | undefined;

class PlatformServiceStub {
  readonly isNative = signal(false).asReadonly();
}

@Injectable({ providedIn: 'root' })
export class BiometricAuthService {
  private readonly platform = inject(PlatformServiceStub, { optional: true })
    ?? new PlatformServiceStub();

  async isAvailable(): Promise<boolean> {
    if (!this.platform.isNative()) return false;
    if (typeof BiometricAuth === 'undefined') return false;
    return (await BiometricAuth.checkBiometry()).isAvailable;
  }

  async enrollForQuickLogin(refreshToken: string): Promise<void> {
    if (!(await this.isAvailable())) return;
    if (typeof Preferences === 'undefined') return;
    await Preferences.set({ key: REFRESH_TOKEN_KEY, value: refreshToken });
  }

  async authenticate(): Promise<string | null> {
    if (!(await this.isAvailable())) return null;
    if (typeof BiometricAuth === 'undefined' || typeof Preferences === 'undefined') {
      return null;
    }
    try {
      await BiometricAuth.authenticate({ reason: 'Log in to FinancialApp' });
    } catch {
      return null;
    }
    return (await Preferences.get({ key: REFRESH_TOKEN_KEY })).value;
  }
}
