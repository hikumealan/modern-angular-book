// See ch38-micro-frontends.md
// Signal-based auth context shared across host and remote MFEs. Because
// the service is `providedIn: 'root'` and the shell and remotes share an
// Angular runtime under Native Federation, every MFE reads the same
// singleton.
import { Injectable, computed, signal } from '@angular/core';

export interface User {
  readonly id: string;
  readonly email: string;
  readonly displayName?: string;
  readonly roles?: readonly string[];
}

@Injectable({ providedIn: 'root' })
export class AuthContext {
  private readonly currentUser = signal<User | null>(null);

  readonly user = this.currentUser.asReadonly();
  readonly isAuthenticated = computed(() => this.currentUser() !== null);

  setUser(user: User | null): void {
    this.currentUser.set(user);
  }
}
