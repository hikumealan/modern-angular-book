// See ch48-di-deep-dive.md -- multi-provider, factory, and optional/skip-self patterns.
import { Injectable, Provider, inject } from '@angular/core';
import { API_BASE_URL, CLOCK, FEATURE_CONFIG, FeatureConfig } from './tokens';

export { API_BASE_URL, CLOCK, FEATURE_CONFIG };
export type { Clock, FeatureConfig } from './tokens';

export const accountsFeatureProvider: Provider = {
  provide: FEATURE_CONFIG,
  multi: true,
  useValue: { id: 'accounts', label: 'Accounts', enabled: true } satisfies FeatureConfig,
};

export const portfolioFeatureProvider: Provider = {
  provide: FEATURE_CONFIG,
  multi: true,
  useValue: { id: 'portfolio', label: 'Portfolio', enabled: true } satisfies FeatureConfig,
};

export interface ApiClient {
  readonly baseUrl: string;
}

export const API_CLIENT_FACTORY_PROVIDER: Provider = {
  provide: 'API_CLIENT',
  useFactory: (): ApiClient => ({ baseUrl: inject(API_BASE_URL) }),
};

@Injectable({ providedIn: 'root' })
export class FeatureRegistry {
  private readonly features = inject(FEATURE_CONFIG, { optional: true }) ?? [];
  readonly enabled = this.features.filter((f) => f.enabled);
  readonly now = inject(CLOCK).now();
}

@Injectable()
export class ScopedFeatureRegistry {
  private readonly parent = inject(FeatureRegistry, { optional: true, skipSelf: true });
  private readonly local = inject(FEATURE_CONFIG, { self: true, optional: true }) ?? [];
  readonly combined: readonly FeatureConfig[] = [
    ...(this.parent?.enabled ?? []),
    ...this.local,
  ];
}
