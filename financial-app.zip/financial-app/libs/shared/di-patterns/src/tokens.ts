// See ch48-di-deep-dive.md -- reusable DI tokens for the demo library.
import { InjectionToken } from '@angular/core';

export interface FeatureConfig {
  readonly id: string;
  readonly label: string;
  readonly enabled: boolean;
}

export const FEATURE_CONFIG = new InjectionToken<readonly FeatureConfig[]>(
  'FEATURE_CONFIG',
);

export const API_BASE_URL = new InjectionToken<string>('API_BASE_URL', {
  providedIn: 'root',
  factory: () => '/api',
});

export interface Clock {
  now(): Date;
}

export const CLOCK = new InjectionToken<Clock>('CLOCK', {
  providedIn: 'root',
  factory: () => ({ now: () => new Date() }),
});
