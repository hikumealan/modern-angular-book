// See ch42-compliance.md -- "A signal-based consent service"
import { Injectable, computed, signal, type Signal } from '@angular/core';
import type { ConsentCategory, ConsentState } from './types';

const STORAGE_KEY = 'fin.consent';

const INITIAL: ConsentState = {
  necessary: true,
  analytics: false,
  marketing: false,
  decidedAt: null,
};

@Injectable({ providedIn: 'root' })
export class ConsentService {
  private readonly internal = signal<ConsentState>(this.load());

  readonly state: Signal<ConsentState> = this.internal.asReadonly();

  hasDecided(): Signal<boolean> {
    return computed(() => this.internal().decidedAt !== null);
  }

  grant(categories: ConsentCategory[]): void {
    this.update((current) => {
      const next = { ...current };
      for (const category of categories) {
        next[category] = true;
      }
      return next;
    });
  }

  revoke(categories: ConsentCategory[]): void {
    this.update((current) => {
      const next = { ...current };
      for (const category of categories) {
        if (category === 'necessary') {
          // Necessary cookies are, by definition, not revocable.
          continue;
        }
        next[category] = false;
      }
      return next;
    });
  }

  private update(
    mutator: (current: ConsentState) => ConsentState,
  ): void {
    const next: ConsentState = {
      ...mutator(this.internal()),
      decidedAt: new Date().toISOString(),
    };
    this.internal.set(next);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  }

  private load(): ConsentState {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return INITIAL;
    }
    try {
      return { ...INITIAL, ...(JSON.parse(raw) as Partial<ConsentState>) };
    } catch {
      return INITIAL;
    }
  }
}
