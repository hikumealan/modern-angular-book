// See ch46-compliance.md -- "Modeling consent"
export type ConsentCategory = 'necessary' | 'analytics' | 'marketing';

export interface ConsentState {
  necessary: boolean;
  analytics: boolean;
  marketing: boolean;
  decidedAt: string | null;
}
