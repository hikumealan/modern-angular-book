// See ch42-compliance.md
export { ConsentService } from './consent.service';
export { ConsentBannerComponent } from './consent-banner/consent-banner.component';
export { AuditLogger } from './audit-logger';
export {
  maskAccountNumber,
  maskSsn,
  maskEmail,
  maskObject,
} from './pii-masker';
export type { ConsentCategory, ConsentState } from './types';
