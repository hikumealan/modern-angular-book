// See ch42-compliance.md -- "A compliant consent banner"
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { ConsentService } from '../consent.service';

@Component({
  selector: 'fin-consent-banner',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './consent-banner.component.html',
  styleUrl: './consent-banner.component.scss',
})
export class ConsentBannerComponent {
  private readonly consent = inject(ConsentService);

  protected readonly hasDecided = this.consent.hasDecided();
  protected readonly showCustomize = signal(false);

  acceptAll(): void {
    this.consent.grant(['necessary', 'analytics', 'marketing']);
  }

  rejectNonEssential(): void {
    this.consent.revoke(['analytics', 'marketing']);
    this.consent.grant(['necessary']);
  }

  customize(): void {
    this.showCustomize.set(true);
  }

  saveCustom(analytics: boolean, marketing: boolean): void {
    this.consent.grant(['necessary']);
    if (analytics) {
      this.consent.grant(['analytics']);
    } else {
      this.consent.revoke(['analytics']);
    }
    if (marketing) {
      this.consent.grant(['marketing']);
    } else {
      this.consent.revoke(['marketing']);
    }
  }
}
