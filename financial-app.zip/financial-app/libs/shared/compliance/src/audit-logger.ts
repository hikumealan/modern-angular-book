// See ch46-compliance.md -- "Audit trails"
import { Injectable } from '@angular/core';

interface AuditEntry {
  event: string;
  timestamp: string;
  correlationId: string;
  context?: Record<string, unknown>;
}

@Injectable({ providedIn: 'root' })
export class AuditLogger {
  log(event: string, context?: Record<string, unknown>): void {
    const entry: AuditEntry = {
      event,
      timestamp: new Date().toISOString(),
      correlationId: this.readCorrelationId(),
      context,
    };
    // In production this would forward to TelemetryService / an audit sink
    // (e.g. Splunk, Datadog, or a dedicated compliance pipeline).
    console.log('[audit]', entry);
  }

  private readCorrelationId(): string {
    // Mirror of shared/observability's storage key so audit entries line up
    // with correlated telemetry without creating a cross-lib dependency.
    return sessionStorage.getItem('fin.correlation-id') ?? 'unknown';
  }
}
