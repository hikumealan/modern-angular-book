// See ch46-compliance.md -- "Masking PII at the boundary"
export function maskAccountNumber(n: string): string {
  const last4 = n.slice(-4);
  return `****${last4}`;
}

export function maskSsn(s: string): string {
  const digits = s.replace(/\D/g, '');
  const last4 = digits.slice(-4);
  return `***-**-${last4}`;
}

export function maskEmail(e: string): string {
  const at = e.indexOf('@');
  if (at < 1) {
    return '***';
  }
  const local = e.slice(0, at);
  const domain = e.slice(at);
  const first = local[0] ?? '';
  return `${first}***${domain}`;
}

export function maskObject<T>(obj: T, sensitiveKeys: string[]): T {
  const keys = new Set(sensitiveKeys);
  const walk = (value: unknown): unknown => {
    if (Array.isArray(value)) {
      return value.map((item) => walk(item));
    }
    if (value && typeof value === 'object') {
      const out: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(value)) {
        out[k] = keys.has(k) ? '***' : walk(v);
      }
      return out;
    }
    return value;
  };
  return walk(obj) as T;
}
