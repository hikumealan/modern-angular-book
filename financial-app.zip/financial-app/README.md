# Financial App

An Angular v21 application built with Nx, demonstrating modern Angular patterns including zoneless change detection, signal-based state management with NgRx Signals, and a monorepo architecture with enforced module boundaries.

## Prerequisites

- **Node.js** >= 20.x
- **npm** >= 10.x
- **Nx CLI** (optional, can use `npx nx` instead)

## Setup

```bash
# Install dependencies
npm install

# Start the mock API server (runs on port 3000)
npm run mock-api

# In a separate terminal, start the dev server (runs on port 4200)
npm start
```

## Available Scripts

| Command | Description |
| --- | --- |
| `npm start` | Serve the app in development mode (`http://localhost:4200`) |
| `npm run mock-api` | Start json-server mock API on port 3000 |
| `npm test` | Run unit tests with Vitest |
| `npm run lint` | Lint the project with ESLint |
| `npm run build` | Production build |
| `npm run build:ssr` | SSR production build |
| `npm run backend:dev` | Start FastAPI contract backend on port 8000 (see Appendix B) |
| `npm run backend:spec` | Dump FastAPI OpenAPI spec to `openapi.json` |
| `npm run generate:zod-client` | Strategy A -- regenerate Zod + Zodios client |
| `npm run generate:datamodel` | Strategy C -- regenerate TS types + Zod from spec |
| `npm run generate:ng-client` | Strategy D -- regenerate typescript-angular library |
| `npm run check:spec-drift` | Strategy B -- diff frontend Zod-derived spec vs backend spec |
| `npm run generate:all` | Run every generator in sequence (used in CI) |
| `npm run contract:test` | Schema-backed Vitest + Playwright contract suites |

## Project Structure

```
financial-app/
├── apps/
│   ├── financial-app/          # Main application
│   │   └── src/
│   └── financial-app-e2e/      # Playwright E2E tests (Ch 25, Appendix B §9.3)
├── backend/                    # FastAPI contract backend (Appendix B §2)
│   ├── backend/                #   Pydantic models + FastAPI app
│   └── tests/                  #   pytest smoke tests
├── libs/
│   └── shared/
│       ├── models/             # Domain interfaces and types
│       ├── ui/                 # Reusable presentational & wrapper components
│       ├── data-access/        # Services, stores, API clients
│       ├── design-system/      # Design tokens, themes, ThemeService, FinIcon (Ch 27)
│       ├── security/           # Sanitization utilities, security interceptor (Ch 21)
│       ├── api-client/         # Strategy A (Zodios) + C (TS + Zod) output (Appendix B)
│       ├── api-client-ng/      # Strategy D (typescript-angular) output (Appendix B §6)
│       ├── testing/            # Schema-driven Vitest + Playwright helpers (Appendix B §9.4)
│       └── validation/         # Hand-authored Zod schemas (Ch 31, Appendix B §7)
├── mock-api/                   # json-server seed data and routes
├── tools/                      # generate-from-backend, generate-ng-client, ... (Appendix B)
├── openapi.json                # Canonical FastAPI-derived spec (Appendix B §2)
├── openapi.yaml                # Legacy hand-authored spec (Ch 31)
├── openapitools.json           # Pinned OpenAPI Generator version (Appendix B §6)
├── .github/workflows/          # Includes contract.yml (Appendix B §10)
├── .storybook/                 # Workspace-level Storybook config (Ch 28)
├── .cursor/rules/              # Angular-specific AI rules (Ch 29)
├── ngsw-config.json            # Service worker config (Ch 26)
├── nx.json                     # Nx workspace configuration
├── tsconfig.base.json          # Root TypeScript config with path mappings
├── eslint.config.js            # Flat ESLint config
├── sheriff.config.ts           # Module boundary enforcement
└── vitest.workspace.ts         # Vitest workspace config
```

## Architecture

- **Zoneless** — Uses `provideZonelessChangeDetection()` (no zone.js)
- **Signals** — State managed with `@ngrx/signals`
- **Module boundaries** — Enforced by `@softarc/sheriff-core` (apps depend on libs, not the reverse)
- **Path aliases** — `@financial-app/shared/models`, `@financial-app/shared/ui`, `@financial-app/shared/data-access`

## Testing

Tests use Vitest. Run the full suite:

```bash
npm test
```

Or use Nx to test a specific project:

```bash
npx nx test shared-models
```

## Building for Production

```bash
npm run build
```

Output is written to `dist/apps/financial-app/`.

## Contract-Driven Workflow (Appendix B)

The `backend/` directory contains a FastAPI + Pydantic service that serves as the contract source of truth. Four frontend generator strategies consume the emitted OpenAPI spec:

- **Strategy A** (`npm run generate:zod-client`) -- Zod + Zodios client in one file. Used by the admin-screen area.
- **Strategy B** (`npm run check:spec-drift`) -- diff frontend-authored Zod schemas against the backend spec. Drift-detection only.
- **Strategy C** (`npm run generate:datamodel`) -- TypeScript types + Zod via a two-stage pipeline.
- **Strategy D** (`npm run generate:ng-client`) -- full Angular library with HttpClient services. Used by the main app.

Run all four plus the drift check at once:

```bash
npm run backend:spec    # dump fresh openapi.json
npm run generate:all    # regenerate every strategy
```

The CI workflow (`.github/workflows/contract.yml`) runs the same pipeline and fails on any `git diff --exit-code` from the committed generated artifacts. See [Appendix B: End-to-End Contract-Driven Angular Workflow](../appendix-b-e2e-workflow.md) for the full recipe. The sibling adapters ([B1 Node + Express](../appendix-b1-backend-express.md), [B2 Spring Boot](../appendix-b2-backend-spring.md), [B3 Go](../appendix-b3-backend-go.md)) show how to run the same four strategies against non-Python backends.
