# Financial App

An Angular v21 application built with Nx, demonstrating modern Angular patterns including zoneless change detection, signal-based state management with NgRx Signals, and a monorepo architecture with enforced module boundaries.

## Prerequisites

- **Node.js** >= 20.x
- **npm** >= 10.x
- **Nx CLI** (optional, can use `npx nx` instead)

## Setup

```bash
# Install dependencies
npm install

# Start the mock API server (runs on port 3000)
npm run mock-api

# In a separate terminal, start the dev server (runs on port 4200)
npm start
```

## Available Scripts

| Command | Description |
| --- | --- |
| `npm start` | Serve the app in development mode (`http://localhost:4200`) |
| `npm run mock-api` | Start json-server mock API on port 3000 |
| `npm test` | Run unit tests with Vitest |
| `npm run lint` | Lint the project with ESLint |
| `npm run build` | Production build |
| `npm run build:ssr` | SSR production build |

## Project Structure

```
financial-app/
├── apps/
│   ├── financial-app/          # Main application
│   │   └── src/
│   └── financial-app-e2e/      # Playwright E2E tests (Ch 25)
├── libs/
│   └── shared/
│       ├── models/             # Domain interfaces and types
│       ├── ui/                 # Reusable presentational & wrapper components
│       ├── data-access/        # Services, stores, API clients
│       ├── design-system/      # Design tokens, themes, ThemeService, FinIcon (Ch 27)
│       ├── security/           # Sanitization utilities, security interceptor (Ch 21)
│       ├── api-client/         # OpenAPI-generated typed services (Ch 31)
│       └── validation/         # Shared Zod schemas (Ch 31)
├── mock-api/                   # json-server seed data and routes
├── .storybook/                 # Workspace-level Storybook config (Ch 28)
├── .cursor/rules/              # Angular-specific AI rules (Ch 29)
├── tools/generators/           # Custom Nx generators (Ch 30)
├── openapi.yaml                # API specification (Ch 31)
├── ngsw-config.json            # Service worker config (Ch 26)
├── nx.json                     # Nx workspace configuration
├── tsconfig.base.json          # Root TypeScript config with path mappings
├── eslint.config.js            # Flat ESLint config
├── sheriff.config.ts           # Module boundary enforcement
└── vitest.workspace.ts         # Vitest workspace config
```

## Architecture

- **Zoneless** — Uses `provideZonelessChangeDetection()` (no zone.js)
- **Signals** — State managed with `@ngrx/signals`
- **Module boundaries** — Enforced by `@softarc/sheriff-core` (apps depend on libs, not the reverse)
- **Path aliases** — `@financial-app/shared/models`, `@financial-app/shared/ui`, `@financial-app/shared/data-access`

## Testing

Tests use Vitest. Run the full suite:

```bash
npm test
```

Or use Nx to test a specific project:

```bash
npx nx test shared-models
```

## Building for Production

```bash
npm run build
```

Output is written to `dist/apps/financial-app/`.
