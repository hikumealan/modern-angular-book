# Financial App

An Angular v21 application built with Nx, demonstrating modern Angular patterns including zoneless change detection, signal-based state management with NgRx Signals, and a monorepo architecture with enforced module boundaries. This is the companion codebase for the [Modern Angular book](../README.md).

## Prerequisites

- **Node.js** >= 20.x
- **npm** >= 10.x
- **Nx CLI** (optional, can use `npx nx` instead)

## Setup

```bash
# Install dependencies
npm install

# Start the mock API server (runs on port 3000)
npm run mock-api

# In a separate terminal, start the dev server (runs on port 4200)
npm start
```

## Available Scripts

| Command | Description |
| --- | --- |
| `npm start` | Serve the app in development mode (`http://localhost:4200`) |
| `npm run mock-api` | Start json-server mock API on port 3000 |
| `npm test` | Run unit tests with Vitest |
| `npm run lint` | Lint the project with ESLint |
| `npm run build` | Production build |
| `npm run build:ssr` | SSR production build |
| `npm run audit:chapters` | Audit the codebase for book-chapter coverage |
| `npm run hotspots` | Generate a forensic hotspot report (Chapter 39) |
| `npm run backend:dev` | Start FastAPI contract backend on port 8000 (Appendix B0) |
| `npm run backend:spec` | Dump FastAPI OpenAPI spec to `openapi.json` |
| `npm run generate:zod-client` | Strategy A -- regenerate Zod + Zodios client |
| `npm run generate:datamodel` | Strategy C -- regenerate TS types + Zod from spec |
| `npm run generate:ng-client` | Strategy D -- regenerate typescript-angular library |
| `npm run check:spec-drift` | Strategy B -- diff frontend Zod-derived spec vs backend spec |
| `npm run generate:all` | Run every generator in sequence (used in CI) |
| `npm run contract:test` | Schema-backed Vitest + Playwright contract suites |

## Project Structure

```
financial-app/
|-- apps/
|   |-- financial-app/          # Main application (Chapter 1)
|   |   `-- src/
|   |-- financial-app-e2e/      # Playwright E2E tests (Chapter 37)
|   |-- financial-widget/       # Angular Elements custom-element build (Chapter 40)
|   `-- financial-app-mobile/   # Capacitor mobile shell (Chapter 41)
|-- backend/                    # FastAPI contract backend (Appendix B0)
|   |-- backend/                #   Pydantic models + FastAPI app
|   `-- tests/                  #   pytest smoke tests
|-- libs/
|   `-- shared/
|       |-- models/             # Domain interfaces, branded IDs (Chapters 5, 27)
|       |-- ui/                 # Reusable UI, wizard (Chapter 45), command-palette (Chapter 46), signal-queries demo (Chapter 11)
|       |-- data-access/        # Services, stores, API clients (Chapter 5)
|       |-- design-system/      # Tokens, themes, FinButton, FinFormField, FinDataTable, FinIcon (Chapter 22)
|       |-- security/           # Security interceptor, CSP reporter (Chapter 18)
|       |-- auth/               # OAuth service, auth interceptor, biometric (Chapters 17, 41)
|       |-- util-error/         # GlobalErrorHandler (Chapter 19)
|       |-- api-client/         # Strategy A (Zodios) + C (TS + Zod) output (Appendix B0)
|       |-- api-client-ng/      # Strategy D (typescript-angular) output (Appendix B0)
|       |-- testing/            # Schema-driven Vitest + Playwright helpers (Appendix B0)
|       |-- validation/         # Hand-authored Zod schemas (Chapter 27)
|       |-- realtime/           # WebSocket price stream service (Chapter 28)
|       |-- file-utils/         # Upload, CSV export, PDF statement services (Chapter 29)
|       |-- charts/             # FinAllocationChart and other chart wrappers (Chapter 30)
|       |-- workers/            # Portfolio analytics web worker (Chapter 35)
|       |-- observability/      # TelemetryService, web-vitals, correlation ID (Chapter 20)
|       |-- feature-flags/      # FeatureFlagsService and guards (Chapter 21)
|       |-- offline-sync/       # MutationQueue, SyncService, online signal (Chapter 34)
|       |-- compliance/         # ConsentBanner, AuditLogger, PiiMasker (Chapter 42)
|       |-- architecture-notes/ # Domain tag constants (Chapter 9)
|       `-- di-patterns/        # Multi-provider, factory, optional/self-skip-self demos (Chapter 48)
|-- mock-api/                   # json-server seed data and routes
|-- migrations/                 # Migration log (Chapter 50)
|-- tools/                      # generate-from-backend, generate-ng-client, audit-chapter-coverage, rewrite-chapter-refs, forensic-hotspots
|-- docker/                     # Dockerfile, nginx.conf (Chapter 36)
|-- openapi.json                # Canonical FastAPI-derived spec (Appendix B0)
|-- openapi.yaml                # Legacy hand-authored spec (Chapter 27)
|-- openapitools.json           # Pinned OpenAPI Generator version (Appendix B0)
|-- .github/workflows/          # contract.yml, deploy.yml, supply-chain.yml, nx-migrate.yml, storybook.yml, ci.yml, e2e.yml
|-- .storybook/                 # Workspace-level Storybook config (Chapter 26)
|-- .cursor/rules/              # Angular AI rules (Chapter 47)
|-- ngsw-config.json            # Service worker config (Chapter 33)
|-- nx.json                     # Nx workspace configuration (Chapter 14)
|-- tsconfig.base.json          # Root TypeScript config with path mappings
|-- eslint.config.js            # Flat ESLint config (Chapter 16)
|-- sheriff.config.ts           # Module boundary enforcement (Chapter 16)
`-- vitest.workspace.ts         # Vitest workspace config (Chapter 7)
```

## Architecture

- **Zoneless** -- uses `provideZonelessChangeDetection()` (no zone.js)
- **Signals** -- state managed with `@ngrx/signals`
- **Module boundaries** -- enforced by `@softarc/sheriff-core` (apps depend on libs, not the reverse; see Chapter 16)
- **Path aliases** -- `@financial-app/shared/models`, `@financial-app/shared/ui`, `@financial-app/shared/data-access`, etc.
- **Chapter traceability** -- every source file references its chapter(s) in a top-of-file comment. Run `npm run audit:chapters` to verify.

## Testing

Tests use Vitest. Run the full suite:

```bash
npm test
```

Or use Nx to test a specific project:

```bash
npx nx test shared-models
```

E2E tests use Playwright (Chapter 37):

```bash
npx nx e2e financial-app-e2e
```

## Building for Production

```bash
npm run build
```

Output is written to `dist/apps/financial-app/`.

## Contract-Driven Workflow (Appendix B0)

The `backend/` directory contains a FastAPI + Pydantic service that serves as the contract source of truth. Four frontend generator strategies consume the emitted OpenAPI spec:

- **Strategy A** (`npm run generate:zod-client`) -- Zod + Zodios client in one file. Used by the admin-screen area.
- **Strategy B** (`npm run check:spec-drift`) -- diff frontend-authored Zod schemas against the backend spec. Drift-detection only.
- **Strategy C** (`npm run generate:datamodel`) -- TypeScript types + Zod via a two-stage pipeline.
- **Strategy D** (`npm run generate:ng-client`) -- full Angular library with HttpClient services. Used by the main app.

Run all four plus the drift check at once:

```bash
npm run backend:spec    # dump fresh openapi.json
npm run generate:all    # regenerate every strategy
```

The CI workflow (`.github/workflows/contract.yml`) runs the same pipeline and fails on any `git diff --exit-code` from the committed generated artifacts. Generated files carry a banner referencing Appendix B0 (injected by `tools/inject-chapter-banner.mjs`) so the chapter-coverage audit keeps passing after regeneration.

See [Appendix B0: Backend Adapter -- FastAPI + Pydantic](../ch52-appendix-b0-backend-fastapi.md) for the full recipe. The sibling adapters show how to run the same four strategies against non-Python backends:

- [Appendix B1 -- Node + Express](../ch53-appendix-b1-backend-express.md)
- [Appendix B2 -- Spring Boot](../ch54-appendix-b2-backend-spring.md)
- [Appendix B3 -- Go](../ch55-appendix-b3-backend-go.md)
