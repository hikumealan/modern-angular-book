# FinancialApp Backend

FastAPI + Pydantic contract source-of-truth for the FinancialApp demo. See [Appendix B0](../../ch52-appendix-b0-backend-fastapi.md) for the full end-to-end workflow.

This is **not** a production backend. It exists to demonstrate the contract-driven Angular workflow: Pydantic models are authored once and every downstream artifact (TypeScript types, Zod schemas, Angular services, dynamic forms) is regenerated from the emitted OpenAPI spec.

## Prerequisites

- Python 3.12 or later
- [`uv`](https://docs.astral.sh/uv/) (preferred) or pip

## Install

With `uv`:

```bash
cd financial-app/backend
uv sync
```

Or with pip:

```bash
cd financial-app/backend
pip install -e '.[dev]'
```

## Run the Development Server

```bash
uv run uvicorn backend.main:app --reload --port 8000
```

Then:

- OpenAPI JSON: http://localhost:8000/openapi.json
- Swagger UI:   http://localhost:8000/docs
- ReDoc:        http://localhost:8000/redoc

## Dump the Spec to Disk

```bash
uv run python -m backend.dump_openapi > ../openapi.json
```

This is the command CI runs in the `backend-spec` job to produce the artifact consumed by the four frontend generator strategies.

## Run the Tests

```bash
uv run pytest
```

## Extend the Contract

Edit `backend/models.py`, add or modify routes in `backend/main.py`, then regenerate the spec:

```bash
uv run python -m backend.dump_openapi > ../openapi.json
```

From the monorepo root:

```bash
npm run generate:all   # regenerates all four frontend strategies
```

If any regenerated artifact diffs from what is committed, CI fails with "generated artifacts out of date". That gate is the whole point of this workflow.

## What This Backend Does *Not* Do

- No database. Everything is in-memory and resets between restarts.
- No authentication or authorization.
- No observability, rate limiting, or production hardening.
- No attempt to be a full mock replacement for `json-server` at `mock-api/`. The two coexist; use `json-server` for fast UI iteration and this backend for contract work. See [Appendix B0 §12](../../ch52-appendix-b0-backend-fastapi.md#12-migrating-financialapp-from-json-server-to-fastapi).
