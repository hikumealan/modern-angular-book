# See appendix-b-e2e-workflow.md -- "Shared FastAPI Backend"
"""Smoke tests for the FinancialApp backend.

Not a full test suite. Just enough to prove the contract loop works:
each endpoint exists, responds with the declared shape, and the emitted
OpenAPI spec is structurally sane.
"""

from __future__ import annotations

from fastapi.testclient import TestClient

from backend.main import app

client = TestClient(app)


def test_health_returns_ok() -> None:
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_list_accounts_returns_seeded_accounts() -> None:
    response = client.get("/api/accounts")
    assert response.status_code == 200
    accounts = response.json()
    assert len(accounts) >= 1
    account = accounts[0]
    # Verify JSON alias conversion (snake_case -> camelCase in wire format)
    assert "ownerId" in account
    assert "owner_id" not in account


def test_get_account_404_on_missing() -> None:
    response = client.get("/api/accounts/9999")
    assert response.status_code == 404


def test_create_transaction_accepts_valid_draft() -> None:
    payload = {
        "accountId": 1,
        "amount": 42.50,
        "type": "debit",
        "category": "groceries",
        "date": "2026-04-15",
        "description": "Weekly shop",
    }
    response = client.post("/api/transactions", json=payload)
    assert response.status_code == 201
    created = response.json()
    assert created["id"] > 0
    assert created["accountId"] == 1
    assert created["amount"] == "42.50"  # Decimal serializes as string


def test_create_transaction_rejects_zero_amount() -> None:
    response = client.post(
        "/api/transactions",
        json={
            "accountId": 1,
            "amount": 0,  # violates gt=0.01
            "type": "debit",
            "category": "test",
            "date": "2026-04-15",
        },
    )
    assert response.status_code == 422


def test_openapi_spec_exposes_schemas() -> None:
    spec = app.openapi()
    schemas = spec["components"]["schemas"]
    for name in ("Account", "Transaction", "TransactionDraft", "Client", "Portfolio", "Holding"):
        assert name in schemas, f"Missing schema: {name}"


def test_openapi_spec_declares_constraints() -> None:
    spec = app.openapi()
    account_props = spec["components"]["schemas"]["Account"]["properties"]
    assert account_props["name"]["minLength"] == 1
    assert account_props["name"]["maxLength"] == 100
    assert account_props["type"]["enum"] == ["checking", "savings", "investment"]


def test_dump_openapi_includes_spec_hash() -> None:
    from backend.dump_openapi import _compute_hash

    spec = app.openapi()
    spec["x-spec-hash"] = _compute_hash(spec)
    assert len(spec["x-spec-hash"]) == 12
