# See ch52-appendix-b0-backend-fastapi.md -- "The Pydantic Models"
"""Pydantic models backing the FinancialApp OpenAPI spec.

These are the single source of truth: constraints declared here
flow through /openapi.json into the four frontend generator strategies.
Field aliases keep snake_case in Python while the JSON wire format
uses camelCase (matching existing libs/shared/validation/ Zod schemas).
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

AccountType = Literal["checking", "savings", "investment"]
CurrencyCode = Literal["USD", "EUR", "GBP", "JPY"]
TransactionType = Literal["credit", "debit"]
RiskProfile = Literal["conservative", "moderate", "aggressive"]


class Account(BaseModel):
    """A deposit or investment account owned by a client."""

    model_config = ConfigDict(populate_by_name=True)

    id: int
    name: str = Field(min_length=1, max_length=100)
    type: AccountType
    balance: Decimal = Field(ge=0)
    currency: CurrencyCode
    owner_id: int = Field(alias="ownerId")


class TransactionDraft(BaseModel):
    """Payload accepted by POST /api/transactions.

    Amount must be strictly positive. Category is required and capped
    to keep reporting tidy. Description is optional free-form text.
    """

    model_config = ConfigDict(populate_by_name=True)

    account_id: int = Field(alias="accountId")
    amount: Decimal = Field(gt=Decimal("0.01"))
    type: TransactionType
    category: str = Field(min_length=1, max_length=50)
    date: date
    description: str | None = Field(default=None, max_length=500)
    pending: bool = False


class Transaction(TransactionDraft):
    """A persisted transaction -- `TransactionDraft` plus a server-assigned id."""

    id: int


class Client(BaseModel):
    """A human owner of accounts and portfolios."""

    model_config = ConfigDict(populate_by_name=True)

    id: int
    first_name: str = Field(alias="firstName", min_length=1, max_length=50)
    last_name: str = Field(alias="lastName", min_length=1, max_length=50)
    email: str = Field(pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    risk_profile: RiskProfile = Field(alias="riskProfile")


class Holding(BaseModel):
    """A position in a portfolio."""

    model_config = ConfigDict(populate_by_name=True)

    id: int
    portfolio_id: int = Field(alias="portfolioId")
    ticker: str = Field(min_length=1, max_length=10)
    shares: Decimal = Field(gt=0)
    purchase_price: Decimal = Field(alias="purchasePrice", ge=0)
    current_price: Decimal = Field(alias="currentPrice", ge=0)


class Portfolio(BaseModel):
    """A collection of holdings owned by a client."""

    model_config = ConfigDict(populate_by_name=True)

    id: int
    client_id: int = Field(alias="clientId")
    name: str = Field(min_length=1, max_length=100)
    holdings: list[int] = Field(default_factory=list)
    total_value: Decimal = Field(alias="totalValue", ge=0)


class ApiError(BaseModel):
    """Standard error envelope returned with non-2xx responses."""

    code: str
    message: str
    details: dict[str, list[str]] | None = None
