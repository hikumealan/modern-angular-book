# See appendix-b-e2e-workflow.md -- "Shared FastAPI Backend"
"""FinancialApp backend package.

This package exists to demonstrate the contract-driven workflow
described in appendix-b-e2e-workflow.md. It is intentionally minimal:
in-memory data, no auth, no database. The point is the OpenAPI spec.
"""

__version__ = "1.0.0"
