# See ch52-appendix-b0-backend-fastapi.md -- "Shared FastAPI Backend"
"""FinancialApp backend package.

This package exists to demonstrate the contract-driven workflow
described in ch52-appendix-b0-backend-fastapi.md. It is intentionally minimal:
in-memory data, no auth, no database. The point is the OpenAPI spec.
"""

__version__ = "1.0.0"
