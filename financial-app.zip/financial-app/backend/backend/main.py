# See ch52-appendix-b0-backend-fastapi.md -- "The FastAPI App"
"""FastAPI application exposing the FinancialApp contract.

Endpoints mirror the existing openapi.yaml and json-server routes.
Storage is intentionally in-memory; this service exists to demonstrate
the contract loop, not to be a production backend.
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Annotated

from fastapi import FastAPI, HTTPException, Path, status

from .models import (
    Account,
    ApiError,
    Client,
    Holding,
    Portfolio,
    Transaction,
    TransactionDraft,
)

app = FastAPI(
    title="FinancialApp API",
    version="1.0.0",
    description=(
        "Contract source of truth for the FinancialApp running example. "
        "See ch52-appendix-b0-backend-fastapi.md for the end-to-end workflow."
    ),
    openapi_tags=[
        {"name": "accounts", "description": "Account CRUD operations."},
        {"name": "transactions", "description": "Transaction entry and search."},
        {"name": "clients", "description": "Client onboarding."},
        {"name": "portfolios", "description": "Portfolio and holding management."},
    ],
)


# --- In-memory seed data -------------------------------------------------

_accounts: dict[int, Account] = {
    1: Account(
        id=1,
        name="Primary Checking",
        type="checking",
        balance=Decimal("5432.10"),
        currency="USD",
        ownerId=10,
    ),
    2: Account(
        id=2,
        name="Emergency Fund",
        type="savings",
        balance=Decimal("15000.00"),
        currency="USD",
        ownerId=10,
    ),
}
_transactions: dict[int, Transaction] = {}
_clients: dict[int, Client] = {
    10: Client(
        id=10,
        firstName="Alex",
        lastName="Advisor",
        email="alex@example.com",
        riskProfile="moderate",
    ),
}
_portfolios: dict[int, Portfolio] = {}
_holdings: dict[int, Holding] = {}


# --- Accounts ------------------------------------------------------------

@app.get("/api/accounts", response_model=list[Account], tags=["accounts"])
def list_accounts() -> list[Account]:
    return list(_accounts.values())


@app.get(
    "/api/accounts/{account_id}",
    response_model=Account,
    responses={404: {"model": ApiError}},
    tags=["accounts"],
)
def get_account(account_id: Annotated[int, Path(ge=1)]) -> Account:
    account = _accounts.get(account_id)
    if account is None:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND,
            detail={"code": "NOT_FOUND", "message": "Account not found"},
        )
    return account


# --- Transactions --------------------------------------------------------

@app.get("/api/transactions", response_model=list[Transaction], tags=["transactions"])
def list_transactions() -> list[Transaction]:
    return list(_transactions.values())


@app.post(
    "/api/transactions",
    response_model=Transaction,
    status_code=status.HTTP_201_CREATED,
    responses={422: {"model": ApiError}},
    tags=["transactions"],
)
def create_transaction(draft: TransactionDraft) -> Transaction:
    new_id = max(_transactions.keys(), default=0) + 1
    transaction = Transaction(id=new_id, **draft.model_dump(by_alias=False))
    _transactions[new_id] = transaction
    return transaction


# --- Clients -------------------------------------------------------------

@app.get("/api/clients", response_model=list[Client], tags=["clients"])
def list_clients() -> list[Client]:
    return list(_clients.values())


@app.get(
    "/api/clients/{client_id}",
    response_model=Client,
    responses={404: {"model": ApiError}},
    tags=["clients"],
)
def get_client(client_id: Annotated[int, Path(ge=1)]) -> Client:
    client = _clients.get(client_id)
    if client is None:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND,
            detail={"code": "NOT_FOUND", "message": "Client not found"},
        )
    return client


# --- Portfolios and Holdings --------------------------------------------

@app.get("/api/portfolios", response_model=list[Portfolio], tags=["portfolios"])
def list_portfolios() -> list[Portfolio]:
    return list(_portfolios.values())


@app.get(
    "/api/portfolios/{portfolio_id}/holdings",
    response_model=list[Holding],
    tags=["portfolios"],
)
def list_portfolio_holdings(portfolio_id: Annotated[int, Path(ge=1)]) -> list[Holding]:
    return [h for h in _holdings.values() if h.portfolio_id == portfolio_id]


# --- Health --------------------------------------------------------------

@app.get("/api/health", tags=["accounts"])
def health() -> dict[str, str | date]:
    return {"status": "ok", "service": "financial-app-backend"}
