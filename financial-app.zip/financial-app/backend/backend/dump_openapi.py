# See appendix-b-e2e-workflow.md -- "Dumping the Spec"
"""Write the FastAPI OpenAPI 3.1 spec to stdout.

Used by CI (`backend-spec` job) to produce the canonical openapi.json
artifact that every frontend generator consumes. Running it offline
via `python -m backend.dump_openapi > openapi.json` is preferred over
hitting the live /openapi.json endpoint because it avoids needing a
free port in CI.

The `x-spec-hash` extension is injected so Playwright visual-regression
baselines can be anchored to a specific contract version.
"""

from __future__ import annotations

import hashlib
import json
import sys

from .main import app


def _compute_hash(spec: dict[str, object]) -> str:
    canonical = json.dumps(spec, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()[:12]


def main() -> None:
    spec = app.openapi()
    spec["x-spec-hash"] = _compute_hash(spec)
    json.dump(spec, sys.stdout, indent=2, sort_keys=True)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
