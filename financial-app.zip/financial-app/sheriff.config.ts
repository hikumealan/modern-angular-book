// See ch16-style-guide-governance.md -- module boundary enforcement.
// Each shared lib gets an explicit depRules entry so the graph is traceable.
// Violations fail `nx lint` via `@softarc/sheriff-core`'s ESLint plugin.

import { noDependencies, SheriffConfig } from '@softarc/sheriff-core';

export const sheriffConfig: SheriffConfig = {
  version: 1,
  tagging: {
    'apps/<app>': 'app:<app>',
    'libs/shared/<lib>': 'shared:<lib>',
  },
  depRules: {
    // Apps depend on anything shared.
    'app:*': ['shared:*'],

    // Leaf libraries: no dependencies on other libs.
    'shared:models': noDependencies,

    // Validation depends only on models (Zod schemas mirror the domain types).
    'shared:validation': ['shared:models'],

    // API clients depend on models + validation (see ch52-appendix-b0-backend-fastapi.md).
    'shared:api-client': ['shared:models', 'shared:validation'],
    'shared:api-client-ng': ['shared:models', 'shared:validation'],

    // UI primitives depend on models + design-system tokens.
    'shared:ui': ['shared:models', 'shared:design-system'],
    'shared:design-system': ['shared:models'],

    // Data access depends on models + api clients + validation.
    'shared:data-access': ['shared:models', 'shared:api-client-ng', 'shared:validation'],

    // Feature-specific shared libs (each scopes to a vertical concern).
    'shared:realtime': ['shared:models'],
    'shared:file-utils': ['shared:models'],
    'shared:charts': ['shared:models', 'shared:design-system'],
    'shared:workers': ['shared:models'],

    // Operational libs can depend on data-access + models for correlation/pii masking.
    'shared:observability': ['shared:models'],
    'shared:feature-flags': noDependencies,
    'shared:offline-sync': ['shared:models', 'shared:data-access'],
    'shared:security': noDependencies,
    'shared:compliance': ['shared:models'],

    // Testing utilities see everything they help test.
    'shared:testing': ['shared:models', 'shared:validation', 'shared:api-client', 'shared:api-client-ng'],
  },
};
