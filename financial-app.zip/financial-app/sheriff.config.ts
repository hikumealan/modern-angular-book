import { noDependencies, SheriffConfig } from '@softarc/sheriff-core';

export const sheriffConfig: SheriffConfig = {
  version: 1,
  tagging: {
    'apps/<app>': 'app:<app>',
    'libs/shared/<lib>': 'shared:<lib>',
  },
  depRules: {
    'app:*': ['shared:*'],
    'shared:models': noDependencies,
    'shared:ui': ['shared:models'],
    'shared:data-access': ['shared:models'],
  },
};
