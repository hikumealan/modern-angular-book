// See ch52-appendix-b0-backend-fastapi.md -- "Strategy A -- FastAPI/Pydantic as Single Source of Truth"
//
// Strategy A generator: invokes openapi-zod-client against the canonical
// openapi.json and writes the combined Zod + Zodios client output into
// libs/shared/api-client/src/generated/generated-zodios.ts.
//
// The emitted file is the single runtime surface for the FinancialApp admin
// feature area. The main app uses Strategy D (see tools/generate-ng-client.mjs)
// for everyday HttpClient-driven services.

import { execSync } from 'node:child_process';
import { existsSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { injectBanner } from './inject-chapter-banner.mjs';

const scriptDir = dirname(fileURLToPath(import.meta.url));
const workspaceRoot = resolve(scriptDir, '..');

const specPath = resolve(workspaceRoot, 'openapi.json');
const outputPath = resolve(
  workspaceRoot,
  'libs/shared/api-client/src/generated/generated-zodios.ts',
);

if (!existsSync(specPath)) {
  console.error(`[strategy-a] Missing ${specPath}. Run "npm run backend:spec" first.`);
  process.exit(1);
}

mkdirSync(dirname(outputPath), { recursive: true });

console.log('[strategy-a] Generating Zod + Zodios client from', specPath);

execSync(
  [
    'npx openapi-zod-client',
    JSON.stringify(specPath),
    '-o',
    JSON.stringify(outputPath),
    '--export-schemas',
    '--with-docs',
  ].join(' '),
  { stdio: 'inherit', cwd: workspaceRoot },
);

// Banner-inject the generated Zodios file so the reverse-audit passes.
await injectBanner(outputPath, {
  chapterRef: 'ch52-appendix-b0-backend-fastapi.md',
  extra: 'AUTO-GENERATED (openapi-zod-client -- Strategy A).',
});

console.log('[strategy-a] Done ->', outputPath);
