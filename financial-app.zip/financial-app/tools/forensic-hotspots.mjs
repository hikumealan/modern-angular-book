// See ch39-forensic-architecture.md -- churn-based hotspot detection.
//
// Identifies the files with the most lines-changed (additions + deletions)
// over the last 90 days. High-churn files are candidate hotspots; combine
// this report with complexity analysis (Detective, CodeScene, or a simple
// `wc -l` pass) to prioritize refactoring effort.
//
// Usage: node tools/forensic-hotspots.mjs
// Output: markdown table on stdout (top 10 files).

import { execFileSync } from 'node:child_process';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(scriptDir, '..');

const WINDOW_DAYS = 90;
const TOP_N = 10;

function runGit(args) {
  return execFileSync('git', args, {
    cwd: repoRoot,
    encoding: 'utf8',
    maxBuffer: 64 * 1024 * 1024,
  });
}

function collectChurn() {
  const raw = runGit([
    'log',
    `--since=${WINDOW_DAYS}.days.ago`,
    '--pretty=format:%H%x09%s',
    '--numstat',
  ]);

  const churn = new Map();
  let commits = 0;

  for (const line of raw.split('\n')) {
    if (!line) continue;
    const parts = line.split('\t');
    if (parts.length === 2) {
      commits += 1;
      continue;
    }
    if (parts.length !== 3) continue;
    const [addedStr, deletedStr, path] = parts;
    if (!path || addedStr === '-' || deletedStr === '-') continue;
    const added = Number(addedStr);
    const deleted = Number(deletedStr);
    if (!Number.isFinite(added) || !Number.isFinite(deleted)) continue;
    const entry = churn.get(path) ?? { added: 0, deleted: 0, commits: 0 };
    entry.added += added;
    entry.deleted += deleted;
    entry.commits += 1;
    churn.set(path, entry);
  }

  return { churn, commits };
}

function renderReport({ churn, commits }) {
  const rows = [...churn.entries()]
    .map(([path, e]) => ({ path, ...e, total: e.added + e.deleted }))
    .sort((a, b) => b.total - a.total)
    .slice(0, TOP_N);

  const lines = [];
  lines.push(`# Forensic Hotspots -- last ${WINDOW_DAYS} days`);
  lines.push('');
  lines.push(`Commits scanned: ${commits} | Files changed: ${churn.size}`);
  lines.push('');
  lines.push('| Rank | File | Commits | +added | -deleted | Total churn |');
  lines.push('| ---- | ---- | ------- | ------ | -------- | ----------- |');
  rows.forEach((r, i) => {
    lines.push(`| ${i + 1} | \`${r.path}\` | ${r.commits} | ${r.added} | ${r.deleted} | ${r.total} |`);
  });
  return lines.join('\n') + '\n';
}

try {
  const data = collectChurn();
  process.stdout.write(renderReport(data));
} catch (err) {
  console.error(`forensic-hotspots: ${err.message}`);
  process.exit(1);
}
