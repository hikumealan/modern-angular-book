// See appendix-b-e2e-workflow.md -- "Strategy B -- Zod + Pydantic Co-Equal with CI Diff"
//
// Strategy B: emits an OpenAPI 3.1 document derived from the hand-authored
// Zod schemas in libs/shared/validation/. Strategy B's companion script
// tools/diff-openapi.mjs then diffs this output against the backend's
// canonical openapi.json and fails on breaking drift.

import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { z } from 'zod';
import {
  OpenAPIRegistry,
  OpenApiGeneratorV31,
  extendZodWithOpenApi,
} from '@asteasolutions/zod-to-openapi';

extendZodWithOpenApi(z);

const scriptDir = dirname(fileURLToPath(import.meta.url));
const workspaceRoot = resolve(scriptDir, '..');
const outputPath = resolve(
  workspaceRoot,
  'libs/shared/validation/src/generated/openapi-from-zod.json',
);

// The validation lib is authored in TypeScript; importing it from a plain .mjs
// script requires a lightweight build step in real projects. For the book's
// purposes we define the schemas inline here, mirroring what's in
// libs/shared/validation/src/*.schema.ts. In production wire this to
// `tsx`-compiled imports from the actual validation package.

const AccountSchema = z
  .object({
    id: z.number().int(),
    name: z.string().min(1).max(100),
    type: z.enum(['checking', 'savings', 'investment']),
    balance: z.number().nonnegative(),
    currency: z.enum(['USD', 'EUR', 'GBP', 'JPY']),
    ownerId: z.number().int(),
  })
  .openapi('Account');

const TransactionDraftSchema = z
  .object({
    accountId: z.number().int(),
    amount: z.number().gt(0.01),
    type: z.enum(['credit', 'debit']),
    category: z.string().min(1).max(50),
    date: z.string(),
    description: z.string().max(500).optional(),
    pending: z.boolean().default(false),
  })
  .openapi('TransactionDraft');

const TransactionSchema = TransactionDraftSchema.extend({
  id: z.number().int(),
}).openapi('Transaction');

const registry = new OpenAPIRegistry();
registry.register('Account', AccountSchema);
registry.register('TransactionDraft', TransactionDraftSchema);
registry.register('Transaction', TransactionSchema);

registry.registerPath({
  method: 'get',
  path: '/api/accounts',
  tags: ['accounts'],
  responses: {
    200: {
      description: 'List of accounts',
      content: { 'application/json': { schema: z.array(AccountSchema) } },
    },
  },
});

registry.registerPath({
  method: 'get',
  path: '/api/accounts/{account_id}',
  tags: ['accounts'],
  request: {
    params: z.object({ account_id: z.number().int() }),
  },
  responses: {
    200: { description: 'Account', content: { 'application/json': { schema: AccountSchema } } },
    404: { description: 'Not found' },
  },
});

registry.registerPath({
  method: 'post',
  path: '/api/transactions',
  tags: ['transactions'],
  request: {
    body: { content: { 'application/json': { schema: TransactionDraftSchema } }, required: true },
  },
  responses: {
    201: { description: 'Created', content: { 'application/json': { schema: TransactionSchema } } },
  },
});

const generator = new OpenApiGeneratorV31(registry.definitions);
const spec = generator.generateDocument({
  openapi: '3.1.0',
  info: {
    title: 'FinancialApp (frontend Zod view)',
    version: '1.0.0',
    description: 'OpenAPI derived from libs/shared/validation/ for Strategy B diff.',
  },
});

mkdirSync(dirname(outputPath), { recursive: true });
writeFileSync(outputPath, JSON.stringify(spec, null, 2) + '\n');

console.log('[strategy-b] Emitted', outputPath);
