#!/usr/bin/env node
// See ch16-style-guide-governance.md -- audit tooling for chapter-to-code parity.
//
// Audit every book chapter against the financial-app/ companion codebase.
//
// Forward check (chapter -> file):
//   For each ch*.md in the repo root, extract fenced code blocks and preceding
//   prose. Look for hints like `// apps/financial-app/...` or `// libs/shared/...`
//   that name a file. Flag hints that don't resolve on disk.
//
// Reverse check (file -> chapter):
//   For each source file under financial-app/ (ts, html, scss, py, mjs, yml),
//   check the top 20 lines for `See chNN-*.md` or `Ch NN` comments. Flag files
//   without one. Also flag tags pointing at chapter files that no longer exist.
//
// Output: tools/chapter-coverage.json (machine-readable) and
//         docs/chapter-coverage.md (human-readable).

import { readdir, readFile, writeFile, stat, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { dirname, resolve, relative, extname, basename } from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(scriptDir, '..', '..'); // .../modern-angular-book
const financialRoot = resolve(repoRoot, 'financial-app');

// ----------------------------------------------------------------------------
// Helpers

async function listFilesRecursive(dir, filter, ignored = new Set()) {
  const out = [];
  let entries;
  try {
    entries = await readdir(dir, { withFileTypes: true });
  } catch {
    return out;
  }
  for (const entry of entries) {
    if (ignored.has(entry.name)) continue;
    const full = resolve(dir, entry.name);
    if (entry.isDirectory()) {
      out.push(...(await listFilesRecursive(full, filter, ignored)));
    } else if (entry.isFile() && (!filter || filter(entry.name, full))) {
      out.push(full);
    }
  }
  return out;
}

const IGNORED_DIRS = new Set([
  'node_modules', '.git', '.nx', 'dist', 'tmp', '.cache', 'coverage',
  '.angular', '.storybook-static',
]);

const SOURCE_EXTS = new Set(['.ts', '.html', '.scss', '.css', '.py', '.mjs', '.cjs', '.js', '.yml', '.yaml']);

function isSourceFile(name) {
  return SOURCE_EXTS.has(extname(name));
}

function isChapterMd(name) {
  return /^ch\d{2}-.*\.md$/.test(name);
}

// ----------------------------------------------------------------------------
// Forward check: chapter -> referenced files

const FILE_HINT_RE = /(?:^|\s)(?:\/\/|#|<!--)\s*(apps\/[\w./-]+|libs\/[\w./-]+|backend\/[\w./-]+|tools\/[\w./-]+|\.github\/workflows\/[\w./-]+)\s*(?:-->|$)/gm;

// A path is "illustrative" when its first segment after apps/ or libs/
// does NOT match a real top-level directory. E.g. `apps/accounts-mfe/...`
// is illustrative because no such app exists; but `apps/financial-app/...`
// is a real claim.
function classifyPath(path) {
  const fullPath = resolve(financialRoot, path);
  if (existsSync(fullPath)) return 'present';

  const segs = path.split('/');
  // apps/<name>/... -- illustrative if <name> doesn't exist.
  if (segs[0] === 'apps' && segs.length >= 2) {
    if (!existsSync(resolve(financialRoot, 'apps', segs[1]))) return 'illustrative';
  }
  // libs/<subtree>/...
  if (segs[0] === 'libs' && segs.length >= 2) {
    if (!existsSync(resolve(financialRoot, 'libs', segs[1]))) return 'illustrative';
    if (segs[1] === 'shared' && segs.length >= 3) {
      if (!existsSync(resolve(financialRoot, 'libs', 'shared', segs[2]))) return 'illustrative';
    }
  }
  // backend/<sub>/...
  if (segs[0] === 'backend' && segs.length >= 2) {
    if (!existsSync(resolve(financialRoot, 'backend', segs[1]))) return 'illustrative';
  }

  // Nested-path heuristic: if the PARENT directory of the claim doesn't
  // exist, the snippet is describing a hypothetical nested structure
  // (e.g., `libs/shared/security/src/lib/...` where there is no `lib/`
  // subtree). Treat as illustrative.
  const parent = dirname(fullPath);
  if (!existsSync(parent)) return 'illustrative';

  return 'missing';
}

async function auditChapter(chapterFile) {
  const content = await readFile(chapterFile, 'utf8');
  const chapterName = basename(chapterFile);

  const claims = [];
  const seen = new Set();

  let m;
  while ((m = FILE_HINT_RE.exec(content)) !== null) {
    const path = m[1].replace(/[.,;:]$/, '');
    if (seen.has(path)) continue;
    seen.add(path);
    claims.push({ path, kind: classifyPath(path) });
  }

  return { chapter: chapterName, claims };
}

// ----------------------------------------------------------------------------
// Reverse check: source file -> chapter tag

const CHAPTER_TAG_RE = /(?:See\s+|Ch\s+)(ch\d{2}-[\w-]+\.md|\d+)/i;

async function auditSourceFile(file) {
  const content = await readFile(file, 'utf8').catch(() => '');
  const head = content.split('\n').slice(0, 25).join('\n');
  const m = head.match(CHAPTER_TAG_RE);
  const rel = relative(repoRoot, file);
  if (!m) return { file: rel, tagged: false };

  // Extract referenced chapter file if present
  const target = m[1];
  const looksLikeFilename = target.endsWith('.md');
  let exists = true;
  if (looksLikeFilename) {
    exists = existsSync(resolve(repoRoot, target));
  }
  return { file: rel, tagged: true, target, exists };
}

// ----------------------------------------------------------------------------
// Main

async function main() {
  // Forward check
  const chapterFiles = (await readdir(repoRoot))
    .filter(isChapterMd)
    .map(n => resolve(repoRoot, n))
    .sort();

  const perChapter = [];
  for (const cf of chapterFiles) {
    perChapter.push(await auditChapter(cf));
  }

  // Reverse check
  const sourceFiles = await listFilesRecursive(financialRoot, isSourceFile, IGNORED_DIRS);
  // Skip generated files for the reverse-check initial report; they are
  // handled by the Phase 6 generator banner fix.
  const handWritten = sourceFiles.filter(f => !/\/generated\//.test(f));
  const reverseResults = [];
  for (const sf of handWritten) {
    reverseResults.push(await auditSourceFile(sf));
  }

  // Bucketize
  const buckets = {
    present: [],
    missing: [],
    drift: [],
    illustrative_only: [],
    untagged_files: [],
    orphan_tags: [],
  };

  for (const c of perChapter) {
    for (const claim of c.claims) {
      if (claim.kind === 'present') buckets.present.push({ chapter: c.chapter, path: claim.path });
      else if (claim.kind === 'illustrative') buckets.illustrative_only.push({ chapter: c.chapter, path: claim.path });
      else buckets.missing.push({ chapter: c.chapter, path: claim.path });
    }
  }

  for (const r of reverseResults) {
    if (!r.tagged) {
      buckets.untagged_files.push(r.file);
    } else if (r.target && !r.exists) {
      buckets.orphan_tags.push({ file: r.file, target: r.target });
    }
  }

  // Summary
  const summary = {
    generatedAt: new Date().toISOString(),
    chapterCount: chapterFiles.length,
    sourceFilesScanned: handWritten.length,
    counts: Object.fromEntries(Object.entries(buckets).map(([k, v]) => [k, v.length])),
  };

  // Write JSON
  const jsonPath = resolve(scriptDir, 'chapter-coverage.json');
  await writeFile(jsonPath, JSON.stringify({ summary, buckets, perChapter }, null, 2));

  // Write Markdown
  const docsDir = resolve(repoRoot, 'docs');
  if (!existsSync(docsDir)) await mkdir(docsDir, { recursive: true });
  const mdPath = resolve(docsDir, 'chapter-coverage.md');

  const lines = [];
  lines.push(`# Chapter Coverage Audit`);
  lines.push('');
  lines.push(`Generated: ${summary.generatedAt}`);
  lines.push('');
  lines.push(`## Summary`);
  lines.push('');
  lines.push(`| Metric | Count |`);
  lines.push(`|---|---|`);
  lines.push(`| Chapters scanned | ${summary.chapterCount} |`);
  lines.push(`| Source files scanned (excluding generated) | ${summary.sourceFilesScanned} |`);
  lines.push(`| File references present | ${summary.counts.present} |`);
  lines.push(`| File references missing | ${summary.counts.missing} |`);
  lines.push(`| Content drift (placeholder) | ${summary.counts.drift} |`);
  lines.push(`| Illustrative-only snippets | ${summary.counts.illustrative_only} |`);
  lines.push(`| Untagged source files | ${summary.counts.untagged_files} |`);
  lines.push(`| Orphan tags (chapter doesn't exist) | ${summary.counts.orphan_tags} |`);
  lines.push('');

  if (buckets.missing.length) {
    lines.push(`## Missing File References`);
    lines.push('');
    lines.push('Chapter claims a file that does not exist in financial-app/.');
    lines.push('');
    lines.push(`| Chapter | Claimed path |`);
    lines.push(`|---|---|`);
    for (const m of buckets.missing.slice(0, 200)) {
      lines.push(`| ${m.chapter} | \`${m.path}\` |`);
    }
    if (buckets.missing.length > 200) {
      lines.push(`| ... | *${buckets.missing.length - 200} more* |`);
    }
    lines.push('');
  }

  if (buckets.untagged_files.length) {
    lines.push(`## Untagged Source Files`);
    lines.push('');
    lines.push('Source file in financial-app/ lacks a `See chNN-*.md` or `Ch NN` comment in the top 25 lines.');
    lines.push('');
    for (const f of buckets.untagged_files.slice(0, 200)) {
      lines.push(`- \`${f}\``);
    }
    if (buckets.untagged_files.length > 200) {
      lines.push(`- *...${buckets.untagged_files.length - 200} more*`);
    }
    lines.push('');
  }

  if (buckets.orphan_tags.length) {
    lines.push(`## Orphan Tags`);
    lines.push('');
    lines.push('Source file references a chapter filename that no longer exists.');
    lines.push('');
    lines.push(`| Source file | Broken target |`);
    lines.push(`|---|---|`);
    for (const o of buckets.orphan_tags.slice(0, 200)) {
      lines.push(`| \`${o.file}\` | \`${o.target}\` |`);
    }
    lines.push('');
  }

  await writeFile(mdPath, lines.join('\n'));

  // Console summary
  console.log('Chapter Coverage Audit');
  console.log('=======================');
  console.log(`Chapters scanned: ${summary.chapterCount}`);
  console.log(`Source files scanned (non-generated): ${summary.sourceFilesScanned}`);
  console.log('');
  console.log(`Buckets:`);
  for (const [k, v] of Object.entries(summary.counts)) {
    console.log(`  ${k.padEnd(22)} ${v}`);
  }
  console.log('');
  console.log(`JSON: ${relative(repoRoot, jsonPath)}`);
  console.log(`Markdown: ${relative(repoRoot, mdPath)}`);

  // Exit non-zero if critical buckets are non-empty (for CI gating)
  const hasFailures =
    summary.counts.missing > 0 ||
    summary.counts.orphan_tags > 0;
  process.exit(hasFailures ? 1 : 0);
}

main().catch(err => {
  console.error(err);
  process.exit(2);
});
