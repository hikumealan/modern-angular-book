// See appendix-b-e2e-workflow.md -- "Strategy C -- Pydantic-primary via datamodel-code-generator + ts-to-zod"
//
// Two-stage pipeline:
//   1. datamodel-code-generator: OpenAPI -> TypeScript interfaces
//   2. ts-to-zod:                TypeScript -> Zod schemas
//
// Step 1 requires datamodel-code-generator to be installed in the backend's
// uv environment (it's declared as a dev dependency in backend/pyproject.toml).
// Step 2 uses the Node-side ts-to-zod package.

import { execSync } from 'node:child_process';
import { existsSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = dirname(fileURLToPath(import.meta.url));
const workspaceRoot = resolve(scriptDir, '..');

const specPath = resolve(workspaceRoot, 'openapi.json');
const tsOutputPath = resolve(
  workspaceRoot,
  'libs/shared/api-client/src/generated/generated-types.ts',
);
const zodOutputPath = resolve(
  workspaceRoot,
  'libs/shared/api-client/src/generated/generated.zod.ts',
);

if (!existsSync(specPath)) {
  console.error(`[strategy-c] Missing ${specPath}. Run "npm run backend:spec" first.`);
  process.exit(1);
}

mkdirSync(dirname(tsOutputPath), { recursive: true });

console.log('[strategy-c] Stage 1: datamodel-code-generator -> TypeScript');

execSync(
  [
    'uv run --directory backend datamodel-codegen',
    '--input',
    JSON.stringify(specPath),
    '--input-file-type',
    'openapi',
    '--output',
    JSON.stringify(tsOutputPath),
    '--output-model-type',
    'typescript',
    '--use-double-quotes',
    '--disable-timestamp',
  ].join(' '),
  { stdio: 'inherit', cwd: workspaceRoot },
);

console.log('[strategy-c] Stage 2: ts-to-zod -> Zod schemas');

execSync(
  [
    'npx ts-to-zod',
    JSON.stringify(tsOutputPath),
    JSON.stringify(zodOutputPath),
    '--skipValidation',
  ].join(' '),
  { stdio: 'inherit', cwd: workspaceRoot },
);

console.log('[strategy-c] Done ->', tsOutputPath, 'and', zodOutputPath);
