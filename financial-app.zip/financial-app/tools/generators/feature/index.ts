import {
  Tree,
  generateFiles,
  formatFiles,
  names,
  joinPathFragments,
} from '@nx/devkit';

interface FeatureGeneratorSchema {
  name: string;
  domain: string;
}

export default async function featureGenerator(
  tree: Tree,
  schema: FeatureGeneratorSchema,
) {
  const { name, domain } = schema;
  const substitutions = {
    ...names(name),
    domain,
    domainClassName: names(domain).className,
    template: '',
  };

  const targetDir = joinPathFragments(
    'apps/financial-app/src/app/features',
    domain,
    names(name).fileName,
  );

  generateFiles(
    tree,
    joinPathFragments(__dirname, 'files'),
    targetDir,
    substitutions,
  );

  const routesPath = joinPathFragments(targetDir, '..', `${domain}.routes.ts`);
  if (tree.exists(routesPath)) {
    const routesContent = tree.read(routesPath, 'utf-8')!;
    const routeEntry = `  { path: '${substitutions.fileName}', loadComponent: () => import('./${substitutions.fileName}/${substitutions.fileName}.component').then(m => m.${substitutions.className}Component) },`;

    if (!routesContent.includes(substitutions.fileName)) {
      const updated = routesContent.replace(
        /(\[\s*\n)/,
        `$1${routeEntry}\n`,
      );
      tree.write(routesPath, updated);
    }
  }

  await formatFiles(tree);
}
