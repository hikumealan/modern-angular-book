// See ch52-appendix-b0-backend-fastapi.md -- "Strategy D -- OpenAPI Generator's typescript-angular"
//
// Generates an Angular library (services + models + Configuration) from
// openapi.json into libs/shared/api-client-ng/src/lib/generated/.
//
// The Java runtime is auto-downloaded on first invocation by the
// @openapitools/openapi-generator-cli Node wrapper. CI therefore does not
// need a separate setup-java step -- only Node 22 is required.

import { execSync } from 'node:child_process';
import { existsSync, mkdirSync, rmSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { injectBanner } from './inject-chapter-banner.mjs';

const scriptDir = dirname(fileURLToPath(import.meta.url));
const workspaceRoot = resolve(scriptDir, '..');

const specPath = resolve(workspaceRoot, 'openapi.json');
const outputPath = resolve(workspaceRoot, 'libs/shared/api-client-ng/src/lib/generated');

if (!existsSync(specPath)) {
  console.error(`[strategy-d] Missing ${specPath}. Run "npm run backend:spec" first.`);
  process.exit(1);
}

// Clean stale output so removed operations/models disappear from disk.
if (existsSync(outputPath)) {
  rmSync(outputPath, { recursive: true, force: true });
}
mkdirSync(outputPath, { recursive: true });

const additionalProperties = [
  'ngVersion=21.0.0',
  'providedIn=root',
  'fileNaming=kebab-case',
  'stringEnums=true',
  'taggedUnions=true',
  'useSingleRequestParameter=true',
  'withInterfaces=true',
  'supportsES6=true',
  'enumPropertyNaming=PascalCase',
  'enumUnknownDefaultCase=true',
].join(',');

console.log('[strategy-d] Generating typescript-angular client ->', outputPath);

execSync(
  [
    'npx openapi-generator-cli generate',
    '-i',
    JSON.stringify(specPath),
    '-g',
    'typescript-angular',
    '-o',
    JSON.stringify(outputPath),
    `--additional-properties=${additionalProperties}`,
  ].join(' '),
  { stdio: 'inherit', cwd: workspaceRoot },
);

// Stamp every generated file with a chapter banner so the reverse-audit
// (see tools/audit-chapter-coverage.mjs) keeps finding tagged files after
// regeneration. Without this, openapi-generator-cli's output has no
// `See ch52-*.md` comment and the audit reports untagged_files > 0.
const stamped = await injectBanner(outputPath, {
  chapterRef: 'ch52-appendix-b0-backend-fastapi.md',
  extra: 'AUTO-GENERATED (OpenAPI Generator typescript-angular).',
});
console.log(`[strategy-d] Stamped ${stamped} generated files with chapter banner.`);

console.log('[strategy-d] Done.');
