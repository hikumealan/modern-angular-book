// See ch47-ai-in-angular.md
// Hashbrown-shaped tool definition. The production build depends on
// `@hashbrownai/angular` and `@hashbrownai/core`, which aren't in
// package.json for the companion repo. We define the matching shapes
// inline so the file type-checks standalone; when the Hashbrown
// packages are installed, replace the local `createTool`/`s` stubs
// with the real imports.

interface ToolDefinition<Input, Output> {
  readonly name: string;
  readonly description: string;
  readonly schema: unknown;
  readonly handler: (input: Input) => Promise<Output>;
}

function createTool<Input, Output>(
  def: ToolDefinition<Input, Output>,
): ToolDefinition<Input, Output> {
  return def;
}

interface SchemaBuilder {
  object<T>(description: string, shape: T): unknown;
  string(description: string): { optional(): unknown };
  number(description: string): unknown;
}

const s: SchemaBuilder = {
  object: (_d, shape) => shape,
  string: (_d) => ({ optional: () => undefined }),
  number: (_d) => undefined,
};

interface TransactionSearchInput {
  readonly accountId: number;
  readonly category?: string;
  readonly startDate?: string;
  readonly endDate?: string;
}

export const searchTransactionsTool = createTool<
  TransactionSearchInput,
  readonly unknown[]
>({
  name: 'searchTransactions',
  description: 'Searches for transactions matching the given filters.',
  schema: s.object('filters for the transaction search', {
    accountId: s.number('the account to search'),
    category: s.string('spending category, e.g. "groceries"').optional(),
    startDate: s.string('ISO date for range start').optional(),
    endDate: s.string('ISO date for range end').optional(),
  }),
  handler: async (input) => {
    const params: Record<string, string> = {
      accountId: String(input.accountId),
    };
    if (input.category) params['category'] = input.category;
    if (input.startDate) params['date_gte'] = input.startDate;
    if (input.endDate) params['date_lte'] = input.endDate;
    const qs = new URLSearchParams(params).toString();
    const res = await fetch(`/api/transactions?${qs}`);
    return (await res.json()) as readonly unknown[];
  },
});
