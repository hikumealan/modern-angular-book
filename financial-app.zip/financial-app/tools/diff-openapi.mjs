// See appendix-b-e2e-workflow.md -- "Strategy B -- Zod + Pydantic Co-Equal with CI Diff"
//
// Compares the backend's canonical openapi.json against the frontend's
// openapi-from-zod.json and fails on breaking differences. Non-breaking
// differences are logged as warnings and do not fail CI.

import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = dirname(fileURLToPath(import.meta.url));
const workspaceRoot = resolve(scriptDir, '..');

const backendSpecPath = resolve(workspaceRoot, 'openapi.json');
const frontendSpecPath = resolve(
  workspaceRoot,
  'libs/shared/validation/src/generated/openapi-from-zod.json',
);

const backend = JSON.parse(readFileSync(backendSpecPath, 'utf8'));
const frontend = JSON.parse(readFileSync(frontendSpecPath, 'utf8'));

/**
 * Minimal structural diff focused on the breaking-change classes that matter:
 * - Removed components/schemas (breaking)
 * - Removed required fields (breaking)
 * - Narrowed types (breaking)
 * - Added required fields (breaking for consumers)
 * - Added optional fields (non-breaking)
 *
 * For production use, prefer @redocly/openapi-diff or openapi-diff CLI,
 * which cover the full OpenAPI 3.x surface. We keep this script
 * dependency-light so the diff runs without a network install.
 */

const issues = { breaking: [], nonBreaking: [] };

const backendSchemas = backend.components?.schemas ?? {};
const frontendSchemas = frontend.components?.schemas ?? {};

for (const name of Object.keys(backendSchemas)) {
  const b = backendSchemas[name];
  const f = frontendSchemas[name];

  if (!f) {
    issues.breaking.push(`Schema "${name}" present on backend but missing on frontend.`);
    continue;
  }

  const bRequired = new Set(b.required ?? []);
  const fRequired = new Set(f.required ?? []);

  for (const field of bRequired) {
    if (!fRequired.has(field)) {
      issues.breaking.push(
        `Schema "${name}": field "${field}" required on backend but not on frontend.`,
      );
    }
  }

  for (const field of fRequired) {
    if (!bRequired.has(field)) {
      issues.breaking.push(
        `Schema "${name}": field "${field}" required on frontend but not on backend.`,
      );
    }
  }

  const bProps = b.properties ?? {};
  const fProps = f.properties ?? {};

  for (const field of Object.keys(bProps)) {
    if (!(field in fProps)) {
      if (bRequired.has(field)) {
        issues.breaking.push(`Schema "${name}": required field "${field}" missing on frontend.`);
      } else {
        issues.nonBreaking.push(
          `Schema "${name}": optional field "${field}" absent on frontend (ok for partial views).`,
        );
      }
      continue;
    }
    const bType = bProps[field].type ?? bProps[field].$ref;
    const fType = fProps[field].type ?? fProps[field].$ref;
    if (bType && fType && bType !== fType) {
      issues.breaking.push(
        `Schema "${name}": field "${field}" type mismatch (backend=${bType}, frontend=${fType}).`,
      );
    }
  }
}

if (issues.nonBreaking.length > 0) {
  console.warn(`[strategy-b] ${issues.nonBreaking.length} non-breaking difference(s):`);
  for (const note of issues.nonBreaking) console.warn(`  - ${note}`);
}

if (issues.breaking.length > 0) {
  console.error(`[strategy-b] ${issues.breaking.length} BREAKING difference(s):`);
  for (const note of issues.breaking) console.error(`  - ${note}`);
  console.error(
    '[strategy-b] Fix by updating Zod schemas in libs/shared/validation/ or ' +
      'Pydantic models in financial-app/backend/backend/models.py to agree.',
  );
  process.exit(1);
}

console.log('[strategy-b] Contracts are compatible. No breaking differences detected.');
