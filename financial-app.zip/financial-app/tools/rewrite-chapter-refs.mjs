#!/usr/bin/env node
// See ch16-style-guide-governance.md -- mechanical rewriter that updates
// every chapter filename reference across the companion codebase per the
// mapping in ../../chapter-mapping.md.
//
// Handles five comment/link syntaxes:
//   - TS / JS : // See chNN-*.md   |  // Ch NN
//   - SCSS   : // ...              |  /* ... */
//   - HTML   : <!-- See chNN-*.md -->
//   - YAML   : # See chNN-*.md
//   - Markdown: chNN-*.md links + "Chapter NN" prose
//
// Usage:
//   node tools/rewrite-chapter-refs.mjs --dry-run   (prints diffs)
//   node tools/rewrite-chapter-refs.mjs             (writes changes in place)
//
// Skips: node_modules, .git, .nx, dist, tmp, coverage, chapter-mapping.md.

import { readFile, writeFile, readdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { dirname, resolve, relative, extname, basename } from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(scriptDir, '..', '..');

// ----------------------------------------------------------------------------
// Mapping (Old filename -> New filename, and Old-# -> New-# for ordinals)

const FILE_RENAMES = [
  // Legacy mis-references to chapter filenames that never existed in the
  // book. These existed in old source comments that predate the final TOC.
  ['ch04-components.md', 'ch02-signal-components.md'],
  ['ch03-routing.md',    'ch04-router.md'],
  ['ch05-routing.md',    'ch04-router.md'],
  ['ch06-forms.md',      'ch06-signal-forms.md'],

  ['appendix-a-typescript-primer.md', 'ch51-appendix-a-typescript-primer.md'],
  ['appendix-b1-backend-express.md',  'ch53-appendix-b1-backend-express.md'],
  ['appendix-b2-backend-spring.md',   'ch54-appendix-b2-backend-spring.md'],
  ['appendix-b3-backend-go.md',       'ch55-appendix-b3-backend-go.md'],
  ['appendix-b-e2e-workflow.md',      'ch52-appendix-b0-backend-fastapi.md'],

  ['ch32-rxjs-deep-dive.md',          'ch08-rxjs-deep-dive.md'],
  ['ch08-architecture.md',            'ch09-architecture.md'],
  ['ch09-ngrx-signal-store.md',       'ch10-ngrx-signal-store.md'],
  ['ch10-signal-queries.md',          'ch11-signal-queries.md'],
  ['ch11-directives-templates.md',    'ch12-directives-templates.md'],
  ['ch12-initialization-routes.md',   'ch13-initialization-routes.md'],
  ['ch13-agentic-ui-hashbrown.md',    'ch47-ai-in-angular.md'],
  ['ch14-ai-assistant.md',            'ch47-ai-in-angular.md'], // legacy typo in the placeholder
  ['ch30-advanced-nx.md',             'ch15-advanced-nx.md'],
  ['ch20-style-guide-structure.md',   'ch16-style-guide-governance.md'],
  ['ch16-auth-patterns.md',           'ch17-auth-patterns.md'],
  ['ch21-security-owasp.md',          'ch18-security-owasp.md'],
  ['ch23-error-handling.md',          'ch19-error-handling.md'],
  ['ch42-observability.md',           'ch20-observability.md'],
  ['ch43-feature-flags.md',           'ch21-feature-flags.md'],
  ['ch27-material-design-system.md',  'ch22-material-design-system.md'],
  ['ch37-animations-deep-dive.md',    'ch23-animations.md'],
  ['ch22-accessibility-aria.md',      'ch24-accessibility.md'],
  ['ch49-screen-reader-testing.md',   'ch24-accessibility.md'],
  ['ch15-internationalization.md',    'ch25-internationalization.md'],
  ['ch28-storybook.md',               'ch26-storybook.md'],
  ['ch31-advanced-typescript-openapi.md', 'ch27-advanced-typescript-openapi.md'],
  ['ch33-websockets-realtime.md',     'ch28-websockets-realtime.md'],
  ['ch34-file-handling.md',           'ch29-file-handling.md'],
  ['ch29-ai-tooling-mcp-skills.md',   'ch47-ai-in-angular.md'],
  ['ch35-charts.md',                  'ch30-charts.md'],
  ['ch17-defer-ssr-hydration.md',     'ch31-defer-ssr-hydration.md'],
  ['ch24-performance.md',             'ch32-performance.md'],
  ['ch26-pwa-service-workers.md',     'ch33-pwa-service-workers.md'],
  ['ch44-optimistic-ui.md',           'ch34-optimistic-ui.md'],
  ['ch38-web-workers.md',             'ch35-web-workers.md'],
  ['ch41-cicd-deployment.md',         'ch36-cicd-deployment.md'],
  ['ch25-e2e-playwright.md',          'ch37-e2e-playwright.md'],
  ['ch18-micro-frontends.md',         'ch38-micro-frontends.md'],
  ['ch19-forensic-architecture.md',   'ch39-forensic-architecture.md'],
  ['ch39-angular-elements.md',        'ch40-angular-elements.md'],
  ['ch40-capacitor-mobile.md',        'ch41-capacitor-mobile.md'],
  ['ch46-compliance.md',              'ch42-compliance.md'],
  ['ch36-drag-and-drop.md',           'ch44-drag-and-drop.md'],
  ['ch50-command-palette.md',         'ch46-command-palette.md'],
  ['ch47-di-deep-dive.md',            'ch48-di-deep-dive.md'],
  ['ch48-debugging.md',               'ch49-debugging.md'],
  ['ch51-migrations.md',              'ch50-migrations.md'],
];

// "Ch NN" / "Chapter NN" prose mapping -- for the rare occurrence in a source
// comment like `// Ch 27 -- Design System`.
const ORD_MAP = {
  8: 9, 9: 10, 10: 11, 11: 12, 12: 13, 13: 47,
  15: 25, 16: 17, 17: 31, 18: 38, 19: 39, 20: 16, 21: 18, 22: 24, 23: 19,
  24: 32, 25: 37, 26: 33, 27: 22, 28: 26, 29: 47, 30: 15, 31: 27, 32: 8,
  33: 28, 34: 29, 35: 30, 36: 44, 37: 23, 38: 35, 39: 40, 40: 41, 41: 36,
  42: 20, 43: 21, 44: 34, 46: 42, 47: 48, 48: 49, 49: 24, 50: 46, 51: 50,
  // 0-7, 14, 45: unchanged (intentionally absent)
};

// "Appendix B" -> "Appendix B0"
// (B1/B2/B3 remain unchanged -- regex requires no-digit lookahead)

// ----------------------------------------------------------------------------
// Scanner

const IGNORED_DIRS = new Set([
  'node_modules', '.git', '.nx', 'dist', 'tmp', '.cache', 'coverage',
  '.angular', '.storybook-static', 'v1',
]);

const TOUCH_EXTS = new Set([
  '.ts', '.mts', '.cts', '.tsx', '.js', '.mjs', '.cjs',
  '.html', '.htm', '.scss', '.sass', '.css',
  '.py', '.yml', '.yaml', '.md', '.mdc', '.mdx',
  '.json', '.gitattributes',
]);

function shouldTouch(file) {
  if (/chapter-mapping\.md$/.test(file)) return false;
  if (/chapter-coverage\.(json|md)$/.test(file)) return false;
  // The rewriter's own source contains the old filenames as literals.
  if (/rewrite-chapter-refs\.mjs$/.test(file)) return false;
  // Do NOT touch generated files -- they are rebuilt by npm run generate:all.
  if (/\/generated\//.test(file)) return false;
  const ext = extname(file);
  if (TOUCH_EXTS.has(ext)) return true;
  // Special-case a few extensionless files
  if (basename(file) === '.gitattributes') return true;
  return false;
}

async function walk(dir) {
  const out = [];
  let entries;
  try { entries = await readdir(dir, { withFileTypes: true }); } catch { return out; }
  for (const entry of entries) {
    if (IGNORED_DIRS.has(entry.name)) continue;
    const full = resolve(dir, entry.name);
    if (entry.isDirectory()) out.push(...(await walk(full)));
    else if (entry.isFile() && shouldTouch(full)) out.push(full);
  }
  return out;
}

// ----------------------------------------------------------------------------
// Rewriter (two-phase tokenization)

function rewrite(content) {
  let subs = 0;

  // Phase 1: tokenize all old filename references (prevents cascade)
  for (let i = 0; i < FILE_RENAMES.length; i++) {
    const [old] = FILE_RENAMES[i];
    const token = `<<__RENAME_${i}__>>`;
    const re = new RegExp(old.replace(/\./g, '\\.'), 'g');
    let c = 0;
    content = content.replace(re, () => { c++; return token; });
    subs += c;
  }

  // Phase 2: tokenize Chapter N / Ch N prose (only if surrounded by prose, not
  // ordinary filenames). Use \b on both sides plus lookahead for digit.
  for (const old of Object.keys(ORD_MAP).sort((a, b) => b - a).map(Number)) {
    const token = `<<__ORD_${old}__>>`;
    let c = 0;
    content = content.replace(new RegExp(`\\bChapter ${old}\\b(?!\\d)`, 'g'), () => { c++; return token; });
    content = content.replace(new RegExp(`\\bCh ${old}\\b(?!\\d)`, 'g'), () => { c++; return `<<__CH_${old}__>>`; });
    subs += c;
  }

  // Phase 3: Appendix B (but not B1/B2/B3)
  content = content.replace(/\bAppendix B\b(?!\d)/g, () => { subs++; return '<<__APPX_B__>>'; });

  // Phase 4: detokenize
  for (let i = 0; i < FILE_RENAMES.length; i++) {
    const [, nw] = FILE_RENAMES[i];
    const token = `<<__RENAME_${i}__>>`;
    content = content.replaceAll(token, nw);
  }
  for (const [oldStr, nw] of Object.entries(ORD_MAP)) {
    content = content.replaceAll(`<<__ORD_${oldStr}__>>`, `Chapter ${nw}`);
    content = content.replaceAll(`<<__CH_${oldStr}__>>`, `Ch ${nw}`);
  }
  content = content.replaceAll('<<__APPX_B__>>', 'Appendix B0');

  return { content, subs };
}

// ----------------------------------------------------------------------------
// Main

async function main() {
  const dryRun = process.argv.includes('--dry-run');
  const files = await walk(repoRoot);

  let changedFiles = 0;
  let totalSubs = 0;

  for (const f of files) {
    let content;
    try { content = await readFile(f, 'utf8'); } catch { continue; }
    const out = rewrite(content);
    if (out.subs > 0 && out.content !== content) {
      if (!dryRun) await writeFile(f, out.content);
      changedFiles++;
      totalSubs += out.subs;
      console.log(`${dryRun ? '[dry] ' : ''}${relative(repoRoot, f)} (${out.subs} subs)`);
    }
  }

  console.log('---');
  console.log(`${dryRun ? '[DRY RUN] ' : ''}files changed: ${changedFiles}`);
  console.log(`${dryRun ? '[DRY RUN] ' : ''}total substitutions: ${totalSubs}`);
}

main().catch(e => { console.error(e); process.exit(1); });
